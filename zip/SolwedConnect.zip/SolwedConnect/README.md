# SolwedConnect

Plugin oficial de [Solwed](https://solwed.es) para FacturaScripts. Aplica el tema visual de Solwed al ERP y conecta la instalación con el ecosistema de plugins y actualizaciones.

## Qué incluye

- **Tema Solwed** — sidebar lateral, header personalizado, dark/light mode, tipografía IBM Plex Sans + Chakra Petch
- **Sistema de diseño** — tokens OKLCH, Bootstrap 5 + utilidades propias, compatible con todas las vistas de FacturaScripts
- **Tienda de plugins** — instala y actualiza plugins Solwed directamente desde el ERP
- **Actualizaciones remotas** — recibe notificaciones y actualizaciones desde el ecosistema Solwed

## Requisitos

- FacturaScripts 2026 o superior
- PHP 8.1 o superior

## Instalación

1. Descarga el ZIP desde [SolWed-es/SolwedPlugins-container](https://github.com/SolWed-es/SolwedPlugins-container)
2. En tu FacturaScripts, ve a **Plugins → Subir plugin**
3. Selecciona el ZIP y súbelo
4. Pulsa **Activar** en la lista de plugins
5. Visita `/deploy` o elimina `Dinamic/` para regenerar el tema

## Activar la suscripción

1. Accede a [app.solwed.es](https://app.solwed.es) → **Servicios → ERP**
2. Pulsa **Obtener código** en tu instalación (válido 24 h)
3. En tu FacturaScripts, abre el **Dashboard**
4. En el bloque **Suscripción Solwed**, introduce el código y pulsa **Activar licencia**

Al activar correctamente verás el plan asociado (`principiante`, `estándar` o `profesional`).

### Modo offline

Si el servidor no tiene acceso a internet o la API no responde:

- Si hay verificación previa en caché (< 72 h) → se usa esa, marcada como `grace`
- Si no hay caché → la instalación sigue funcionando con `plan: none`

El plugin **nunca bloquea el ERP** por falta de conexión.

### Revocar licencia

Dashboard → bloque **Suscripción Solwed** → **Quitar licencia**. La revocación es local — no cancela la suscripción en Solwed.

## Instalaciones managed (Solwed Cloud)

Las instalaciones gestionadas se configuran automáticamente mediante variables de entorno:

```env
FS_MIND_TOKEN=<token_asignado_por_solwed>
FS_INSTANCE_TYPE=managed
```

## Configuración

La URL de la API se puede cambiar desde **Configuración → SolwedConnect → mind_url** (por defecto `https://api.solwed.es`).

## Cron

Para recibir notificaciones y actualizaciones, el cron de FacturaScripts debe estar activo:

```bash
*/15 * * * * cd /ruta/facturascripts && php index.php -cron >> /dev/null 2>&1
```

## Soporte

- Portal clientes: [app.solwed.es](https://app.solwed.es)
- Email: soporte@solwed.es
