/**
 * This file is part of the DocumentosRecurrentes plugin for FacturaScripts.
 * FacturaScripts         Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * DocumentosRecurrentes  Copyright (C) 2020-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
"use strict";

/**
 * Add a hidden value into array code field.
 *
 * @param {Element} parent
 * @param {int} value
 */
function addInputID(parent, value) {
    const input = document.createElement('INPUT');
    input.type = 'hidden';
    input.name = 'code[]';
    input.value = value;
    parent.appendChild(input);
}

document.addEventListener("DOMContentLoaded", function () {
    const modal = document.getElementById("modalgenerate-recurring");
    if (!modal || !modal.parentElement) return;

    const form = modal.parentElement;
    form.onsubmit = function() {
        const listForm = "#form" + form.parentElement.id;
        const inputs = document.querySelectorAll(listForm + ' input[name="code[]"]');
        inputs.forEach(function (item) {
            if (item.checked) {
                addInputID(form, item.value);
            }
        });

        return true;
    };
});
