<?php
/**
 * This file is part of the DocumentosRecurrentes plugin for FacturaScripts.
 * FacturaScripts         Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * DocumentosRecurrentes  Copyright (C) 2020-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\DocumentosRecurrentes\Controller;

use Exception;
use FacturaScripts\Dinamic\Lib\DocumentosRecurrentes\DocRecurringDuplicate;
use FacturaScripts\Dinamic\Lib\DocumentosRecurrentes\DocRecurringManager;
use FacturaScripts\Plugins\DocumentosRecurrentes\Lib\DocumentosRecurrentes\EditDocRecurring;
use FacturaScripts\Plugins\DocumentosRecurrentes\Model\DocRecurringPurchase;

/**
 * Description of EditDocRecurringSale
 *
 * @author Jose Antonio Cuello  <yopli2000@gmail.com>
 */
class EditDocRecurringPurchase extends EditDocRecurring
{
    /**
     * Returns the class name of the model to use in the EditView.
     */
    public function getModelClassName(): string
    {
        return 'DocRecurringPurchase';
    }

    /**
     * Returns basic page attributes
     *
     * @return array
     */
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['menu'] = 'purchases';
        return $pageData;
    }

    /**
     * Duplicates a recurring document
     *
     * @return bool
     */
    protected function duplicateDocAction(): bool
    {
        $data = $this->request->request->all();
        $docDuplicate = new DocRecurringDuplicate();
        $docDuplicate->duplicatePurchaseDoc($data['id'], $data['target'], $data['name']);
        return true;
    }

    /**
     * Generates the documents that are due.
     *
     * @return bool
     * @throws Exception
     */
    protected function generateDocsAction(): bool
    {
        $code = $this->request->request->get('id');
        $recurringDoc = new DocRecurringPurchase();
        if (false === $recurringDoc->load($code)) {
            return true;
        }

        if (null === $recurringDoc->nextdate) {
            return true;
        }

        $docGenerator = new DocRecurringManager();
        $docGenerator->generatePurchaseDoc($code, ['date' => $recurringDoc->nextdate]);
        return true;
    }

    /**
     * Generates a document manually
     *
     * @return bool
     * @throws Exception
     */
    protected function generateManuallyAction(): bool
    {
        $iddoc = $this->request->request->get('id');
        $date = $this->request->request->get('generatedate');
        $target = $this->request->request->get('target');
        $docGenerator = new DocRecurringManager();
        $docGenerator->generatePurchaseDoc($iddoc, ['date' => $date, 'target' => $target]);
        return true;
    }
}
