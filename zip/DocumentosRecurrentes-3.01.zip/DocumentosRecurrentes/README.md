# FacturaScripts
Software de código abierto de facturación y contabilidad para pequeñas y medianas empresas.
Software ERP de código abierto. Construido sobre PHP, utilizando de componentes Symfony y Bootstrap 4.
Fácil y potente.


# DocumentosRecurrentes
Plugin para FacturaScripts que permite crear documentos de compra y de venta de manera automática
con base en un documento plantilla. La creación puede ser manual o automatizarse según
una configuración de tiempo: días, semanas o meses.

También es posible:
- utilizar patrones en la descripción de las líneas del documento para poder personalizar la descripción final de la línea una vez generado el documento.
- asignar una descripción fija, y/o precio por producto en vez de utilizar la descripción y precio del producto.
- asignar una serie concreta al documento generado
- asignar un estado concreto al documento generado


<strong>ESTE PLUGIN NO ES SOFTWARE LIBRE. NO SE PERMITE SU LIBRE DISTRIBUCIÓN.</strong>


## Nombre de carpeta
Como con todos los plugins, la carpeta se debe llamar igual que el plugin. En este caso **DocumentosRecurrentes**.


## Más información
<ul>
    <li>General info: https://www.facturascripts.com</li>
    <li>Plugin info:  https://www.facturascripts.com/plugins/documentosrecurrentes</li>
</ul>


## Documentación / Issues / Feedback
https://www.facturascripts.com


## Otros plugins del mismo autor
<ul>
    <li>Recursos Humanos: https://facturascripts.com/plugins/humanresources</li>
    <li>Producción:  https://facturascripts.com/plugins/produccion</li>
    <li>Producto Pack:  https://facturascripts.com/plugins/productopack</li>
    <li>Pagos Múltiples:  https://facturascripts.com/plugins/pagosmultiples</li>
    <li>Pagos Simplificados:  https://facturascripts.com/plugins/pagosimplificado</li>
    <li>LawFirm: Solución sectorial para despachos de abogacía</li>
    <li>CourseManagement: Solución sectorial para gestión de cursos de formación subvencionados</li>
    <li>GestionEmbarques: Solución sectorial para gestión de importación de contenedores con productos</li>
</ul>



## Enlaces de interés
- [Cómo instalar plugins en FacturaScripts](https://facturascripts.com/publicaciones/como-instalar-un-plugin-en-facturascripts)
- [Programa para hacer facturas gratis](https://facturascripts.com/programa-para-hacer-facturas)
- [Cómo instalar FacturaScripts en Windows](https://facturascripts.com/instalar-windows)
