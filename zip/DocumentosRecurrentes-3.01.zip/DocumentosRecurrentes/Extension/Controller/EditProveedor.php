<?php
/**
 * This file is part of the DocumentosRecurrentes plugin for FacturaScripts.
 * FacturaScripts         Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * DocumentosRecurrentes  Copyright (C) 2020-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\DocumentosRecurrentes\Extension\Controller;

use Closure;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;

/**
 * Description of EditProveedor
 *
 * @author Jose Antonio Cuello <yopli2000@gmail.com>
 *
 * @method addListView(string $viewName, string $modelName, string $viewTitle, string $viewIcon = 'fa-solid fa-list'): ListView
 * @method getModel(): Proveedor
 */
class EditProveedor
{
    public function createViews(): Closure
    {
        return function (): void {
            $viewName = 'ListDocRecurringPurchase';
            $this->addListView($viewName, 'DocRecurringPurchase', 'recurring', 'fa-solid fa-calendar-plus')
                ->disableColumn('supplier')
                ->addSearchFields(['name'])
                ->addOrderBy(['id'], 'code')
                ->addOrderBy(['name'], 'description')
                ->addOrderBy(['nextdate', 'name'], 'next-date', 1)
                ->addOrderBy(['lastdate', 'name'], 'last-date');
        };
    }

    public function loadData(): Closure
    {
        return function ($viewName, $view): void {
            if ($viewName === 'ListDocRecurringPurchase') {
                $code = $this->getModel()->codproveedor;
                $where = [new DataBaseWhere('codproveedor', $code)];
                $view->loadData('', $where);
            }
        };
    }
}
