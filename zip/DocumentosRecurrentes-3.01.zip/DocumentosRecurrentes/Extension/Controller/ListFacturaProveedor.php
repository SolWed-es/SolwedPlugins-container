<?php
/**
 * This file is part of the DocumentosRecurrentes plugin for FacturaScripts.
 * FacturaScripts         Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * DocumentosRecurrentes  Copyright (C) 2020-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\DocumentosRecurrentes\Extension\Controller;

use Closure;
use FacturaScripts\Dinamic\Model\FacturaProveedor;
use FacturaScripts\Plugins\DocumentosRecurrentes\Lib\DocumentosRecurrentes\DocRecurringFromDocTrait;

/**
 * Description of ListFacturaProveedor
 *
 * @author Jose Antonio Cuello <yopli2000@gmail.com>
 */
class ListFacturaProveedor
{
    use DocRecurringFromDocTrait;

    public function setDocModel(): Closure
    {
        return function (): void {
            $this->docModel = new FacturaProveedor();
        };
    }
}
