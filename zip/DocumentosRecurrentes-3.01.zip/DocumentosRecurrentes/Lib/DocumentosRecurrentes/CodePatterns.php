<?php
/**
 * This file is part of the DocumentosRecurrentes plugin for FacturaScripts.
 * FacturaScripts         Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * DocumentosRecurrentes  Copyright (C) 2020-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\DocumentosRecurrentes\Lib\DocumentosRecurrentes;

use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Lib\CodePatterns as CodePatternsParent;

/**
 * Class to apply patterns.
 *
 * @author Jose Antonio Cuello  <yopli2000@gmail.com>
 */
class CodePatterns extends CodePatternsParent
{
    const DATE_STYLE = 'd-m-Y';

    /**
     * Transform a text according to patterns and indicated format.
     * The options parameter can contain the name of the field to use for each pattern.
     * If not reported, field names will be used by default.
     * eg: ['date' => 'creationdate']
     *
     * @param string $text
     * @param object $model
     * @param array $options
     *
     * @return string
     */
    public static function trans(string $text, &$model, array $options = array()): string
    {
        $date = $model->{'fecha'} ?? date(self::DATE_STYLE);
        $newText = strtr($text, [
            '{NUMSEMANA}' => date('W', strtotime($date)),
            '{01FECHA}' => self::firstDayMonth($date),
            '{31FECHA}' => self::lastDayMonth($date),
            '{01FECHA+1}' => self::firstDayMonth(date(self::DATE_STYLE, self::nextMonth($date))),
            '{31FECHA+1}' => self::lastDayMonth(date(self::DATE_STYLE, self::nextMonth($date))),
            '{NOMBREMES+1}' => self::nextMonthName($date),
            '{NOMBREMES-1}' => self::nextMonthName($date, -1),
            '{NOMBREMESANYO+1}' => self::nextMonthYearName($date),
            '{NOMBREMESANYO-1}' => self::nextMonthYearName($date, -1),
            '{ANYO+1}' => (int)date('Y', strtotime($date)) + 1,
            '{ANYO-1}' => (int)date('Y', strtotime($date)) - 1,
        ]);
        return parent::trans($newText, $model, $options);
    }

    /**
     * Return the date located at first day of the month.
     *
     * @param string $date
     * @return string
     */
    private static function firstDayMonth(string $date): string
    {
        return date('01-m-Y', strtotime($date));
    }

    /**
     * Calculate last day for one month.
     *
     * @param string $date
     * @return string
     */
    private static function lastDayMonth(string $date): string
    {
        $year = (int)date('Y', strtotime($date));
        $month = (int)date('m', strtotime($date));
        $lastDay = date('d', mktime(0, 0, 0, $month+1, 1, $year)-1);
        return $lastDay . '-' . $month . '-' . $year;
    }

    /**
     * Add one month to date.
     *
     * @param string $date
     * @param int $offset
     * @return int|false
     */
    private static function nextMonth(string $date, int $offset = 1): bool|int
    {
        $sign = $offset >= 0 ? '+' : '-';
        return strtotime($sign . abs($offset) . ' month', strtotime($date));
    }

    /**
     * Return name of the next month of date.
     *
     * @param string $date
     * @param int $offset
     * @return string
     */
    private static function nextMonthName(string $date, int $offset = 1): string
    {
        $nextDate = self::nextMonth($date, $offset);
        return Tools::lang()->trans(strtolower(date('F', $nextDate)));
    }

    /**
     * Return period in formar month/year of the next month of date.
     *
     * @param string $date
     * @param int $offset
     * @return string
     */
    private static function nextMonthYearName(string $date, int $offset = 1): string
    {
        $nextDate = self::nextMonth($date, $offset);
        return Tools::lang()->trans(strtolower(date('F', $nextDate)))
            . '/'
            . date('Y', strtotime($nextDate));
    }
}
