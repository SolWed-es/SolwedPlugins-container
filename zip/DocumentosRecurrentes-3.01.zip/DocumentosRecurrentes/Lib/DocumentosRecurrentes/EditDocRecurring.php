<?php
/**
 * This file is part of the DocumentosRecurrentes plugin for FacturaScripts.
 * FacturaScripts         Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * DocumentosRecurrentes  Copyright (C) 2020-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\DocumentosRecurrentes\Lib\DocumentosRecurrentes;

use Exception;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Lib\ExtendedController\BaseView;
use FacturaScripts\Dinamic\Lib\ExtendedController\EditController;
use FacturaScripts\Dinamic\Model\Base\DocRecurring;
use FacturaScripts\Dinamic\Model\CodeModel;

/**
 * Description of EditDocRecurring
 *
 * @author Jose Antonio Cuello  <yopli2000@gmail.com>
 */
abstract class EditDocRecurring extends EditController
{
    abstract protected function duplicateDocAction(): bool;

    abstract protected function generateDocsAction(): bool;

    abstract protected function generateManuallyAction(): bool;

    /**
     * Returns basic page attributes
     *
     * @return array
     */
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['title'] = 'doc-recurring';
        $pageData['icon'] = 'fa-solid fa-calendar-plus';
        return $pageData;
    }

    /**
     * Create the view to display.
     */
    protected function createViews()
    {
        parent::createViews();
        $this->createViewsDocument();
        $this->createViewsPeriod();
        $this->createViewsLines();
        $this->createViewsChildren();
        $this->setTabsPosition('left-bottom');
    }

    /**
     * Run the actions that alter data before reading it.
     *
     * @param string $action
     *
     * @return bool
     */
    protected function execPreviousAction($action)
    {
        return match ($action) {
            'generate-docs' => $this->generateDocsAction(),
            'generate-manually' => $this->generateManuallyAction(),
            'duplicate-doc' => $this->duplicateDocAction(),
            default => parent::execPreviousAction($action),
        };
    }

    /**
     * Loads the data to display.
     *
     * @param string $viewName
     * @param BaseView $view
     * @throws Exception
     */
    protected function loadData($viewName, $view)
    {
        $mvn = $this->getMainViewName();
        $mainModel = $this->getModel();

        switch ($viewName) {
            case $this->getViewName('Data'):
                $this->loadPaymentMethods();
                $this->setStatusOptions(
                    $viewName,
                    $mainModel->generatedoc
                );
                $view->loadData($mainModel->id);
                $view->count = 0;
                break;


            case $this->getViewName('Period'):
                $view->loadData($mainModel->id);
                $view->count = 0;
                break;

            case $this->getViewName('Line'):
                $view->loadData('', $this->getMainWhere($mvn), ['id' => 'DESC']);
                break;

            case $this->getViewName('Children', 'List'):
                $where = [new DataBaseWhere('id', $mainModel->id)];
                $view->loadData('', $where);
                $view->count = count($view->cursor);
                break;

            case $mvn:
                parent::loadData($viewName, $view);
                if (empty($mainModel->nick)) {
                    $mainModel->nick = $this->user->nick;
                }
                $this->addActionButtons($viewName);
                $this->setGenerateModal($viewName);
                break;

            default:
                parent::loadData($viewName, $view);
                break;
        }
    }

    protected function createViewsChildren(): void
    {
        $viewName = $this->getViewName('Children', 'List');
        $modelName = 'Join\\' . $this->getModelClassName() . 'Children';
        $this->addListView($viewName, $modelName, 'documents', 'fa-solid fa-file-invoice')
            ->setSettings('btnNew', false)
            ->setSettings('btnDelete', false);
    }

    protected function createViewsDocument(): void
    {
        $viewName = $this->getViewName('Data');
        $view = $this->addEditView($viewName, $this->getModelClassName(), 'document', 'fa-solid fa-file-invoice')
            ->setSettings('btnDelete', false);

        $column = $view->columnForName('serie');
        if($column && $column->widget->getType() === 'select') {
            $where = [
                new DataBaseWhere('tipo', null, 'IS'),
                new DataBaseWhere('tipo', 'R,S', 'NOT IN', 'OR'),
            ];
            $customValues = $this->codeModel->all('series', 'codserie', 'descripcion', false, $where);
            $column->widget->setValuesFromCodeModel($customValues);
        }
    }

    /**
     * Add document lines view.
     */
    protected function createViewsLines(): void
    {
        $this->addEditListView(
            $this->getViewName('Line'),
            $this->getModelClassName() . 'Line',
            'lines',
            'fa-solid fa-tasks'
        );
    }

    protected function createViewsPeriod(): void
    {
        $viewName = $this->getViewName('Period');
        $this->addEditView($viewName, $this->getModelClassName(), 'period', 'fa-solid fa-clock')
            ->setSettings('btnDelete', false);
    }

    /**
     * Add actions buttons for:
     *   - manual generates a document from template.
     *   - close document
     *
     * @param string $viewName
     * @throws Exception
     */
    private function addActionButtons(string $viewName): void
    {
        $id = $this->getViewModelValue($viewName, 'id');
        if (false === empty($id)) {
            $this->addButton($viewName, [
                'action' => 'duplicate-doc',
                'color' => 'info',
                'icon' => 'fa-solid fa-clone',
                'label' => 'clone',
                'type' => 'modal'
            ]);
        }

        $termType = $this->getViewModelValue($viewName, 'termtype');
        if ($termType === DocRecurring::TERM_TYPE_MANUAL) {
            $this->addButton($viewName, [
                'action' => 'generate-manually',
                'color' => 'warning',
                'icon' => 'fa-solid fa-magic',
                'label' => 'generate',
                'type' => 'modal'
            ]);
            return;
        }

        $nextDate = $this->getViewModelValue($viewName, 'nextdate');
        if (!empty($nextDate)) {
            $this->addButton($viewName, [
                'action' => 'generate-docs',
                'color' => 'warning',
                'confirm' => true,
                'icon' => 'fa-solid fa-magic',
                'label' => 'generate'
            ]);
        }
    }

    /**
     *
     * @param string $suffix
     * @param string $prefix
     * @return string
     */
    private function getViewName(string $suffix = '', string $prefix = 'Edit'): string
    {
        return $prefix . $this->getModelClassName() . $suffix;
    }

    /**
     *
     * @param string $mainViewName
     *
     * @return DatabaseWhere[]
     */
    private function getMainWhere(string $mainViewName): array
    {
        $iddoc = $this->getViewModelValue($mainViewName, 'id');
        return [new DataBaseWhere('iddoc', $iddoc)];
    }

    /**
     * Get the list of payment methods for the selected company.
     *
     * @return void
     */
    private function loadPaymentMethods(): void
    {
        $mainViewName = $this->getMainViewName();
        $viewName = $this->getViewName('Data');
        $paymentColumn = $this->views[$viewName]->columnForName('payment');
        if (isset($paymentColumn) && $paymentColumn->widget->getType() === 'select') {
            $idwarehouse = $this->getViewModelValue($mainViewName, 'codalmacen');
            $idcompany = $this->codeModel->getDescription('almacenes', 'codalmacen', $idwarehouse, 'idempresa');
            $where = [ new DataBaseWhere('idempresa', $idcompany) ];
            $rows = CodeModel::all('formaspago', 'codpago', 'descripcion', false, $where);
            $paymentColumn->widget->setValuesFromCodeModel($rows);
        }
    }

    /**
     *
     * @param string $viewName
     */
    private function setGenerateModal(string $viewName): void
    {
        $this->views[$viewName]->model->generatedate = date(Tools::DATE_STYLE);
        if ($this->views[$viewName]->model->generatedoc == 'FacturaCliente') {
            $this->views[$viewName]->disableColumn('generatedate', false, 'true');
        }
    }

    /**
     *
     * @param string $viewName
     * @param string $doc
     */
    private function setStatusOptions(string $viewName, string $doc): void
    {
        $stateColumn = $this->views[$viewName]->columnForName('state');
        if (isset($stateColumn) && $stateColumn->widget->getType() === 'select') {
            $where = [ new DataBaseWhere('tipodoc', $doc) ];
            $rows = CodeModel::all('estados_documentos', 'idestado', 'nombre', true, $where);
            $stateColumn->widget->setValuesFromCodeModel($rows);
        }
    }
}
