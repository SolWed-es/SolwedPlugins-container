<?php
/**
 * This file is part of the DocumentosRecurrentes plugin for FacturaScripts.
 * FacturaScripts         Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * DocumentosRecurrentes  Copyright (C) 2020-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\DocumentosRecurrentes\Lib\DocumentosRecurrentes;

use Closure;
use FacturaScripts\Core\Base\DataBase;
use FacturaScripts\Core\Session;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Lib\ExtendedController\ListView;
use FacturaScripts\Dinamic\Model\DocRecurringPurchase;
use FacturaScripts\Dinamic\Model\DocRecurringSale;
use FacturaScripts\Plugins\DocumentosRecurrentes\Model\Base\DocRecurring;
use FacturaScripts\Core\Request;

/**
 * Auto generate recurring documents from a document.
 *
 * @property ListView[] $views
 * @property Request $request
 * @method addButton(string $viewName, array $btnArray): BaseView
 * @method getMainViewName(): string
 */
trait DocRecurringFromDocTrait
{
    public $docModel;

    public function createViews(): Closure
    {
        return function (): void {
            $viewName = $this->getMainViewName();
            if (isset($this->views[$viewName])) {
                $this->addButton($viewName, [
                    'action' => 'make-recurring',
                    'icon' => 'fa-solid fa-recycle',
                    'label' => 'recurring',
                    'type' => 'modal'
                ]);
            }
        };
    }

    public function execPreviousAction(): Closure
    {
        return function (string $action): bool {
            if ($action === 'make-recurring') {
                $this->makeRecurringAction();
            }
            return true;
        };
    }

    protected function makeRecurringAction(): Closure
    {
        return function (): void {
            $data = $this->request->request->all();
            if (empty($data['codes']) ) {
                Tools::log()->warning('no-document-selected');
                return;
            }

            if (empty($data['makeConfirm'])) {
                Tools::log()->warning('no-confirm-selected');
                return;
            }

            $dataBase = new DataBase();
            $this->setDocModel();
            $count = 0;
            foreach ($data['codes'] as $iddoc) {
                if (false === $this->docModel->load($iddoc)) {
                    continue;
                }

                $recurring = in_array($this->docModel->modelClassName(), ['FacturaProveedor', 'AlbaranProveedor', 'PedidoProveedor'])
                    ? new DocRecurringPurchase()
                    : new DocRecurringSale();

                $dataBase->beginTransaction();
                if (false === $this->setNewDocData($recurring, $data)
                    || false === $this->addNewLines($recurring)
                ) {
                    $dataBase->rollback();
                    continue;
                }
                $dataBase->commit();
                ++$count;
            }

            if ($count > 0) {
                Tools::log()->notice('recurring-created', ['%count%' => $count]);
            }
        };
    }

    protected function addNewLines(): Closure
    {
        return function (DocRecurring $recurring): bool {
            foreach ($this->docModel->getLines() as $line) {
                $newLine = $recurring->getNewLine([
                    'discount' => $line->dtopor,
                    'idproduct' => $line->idproducto,
                    'irpf' => $line->irpf,
                    'name' => $line->descripcion,
                    'price' => $line->pvpunitario,
                    'quantity' => $line->cantidad,
                    'reference' => $line->referencia,
                ]);
                if (false === $newLine->save()) {
                    return false;
                }
            }
            return true;
        };
    }

    protected function setNewDocData(): Closure
    {
        return function (DocRecurring $recurring, array $data): bool {
            if (property_exists($recurring, 'codcliente')) {
                $recurring->codcliente = $this->docModel->codcliente;
            }

            if (property_exists($recurring, 'codproveedor')) {
                $recurring->codproveedor = $this->docModel->codproveedor;
            }

            $recurring->name = Tools::lang()->trans('auto-recurring', ['%code%' => $this->docModel->codigo]);
            $recurring->generatedoc = $this->docModel->modelClassName();
            $recurring->termunits = (int)$data['termunits'] ?? 1;
            $recurring->termtype = (int)$data['termtype'] ?? DocRecurring::TERM_TYPE_MONTHS;

            $recurring->codalmacen = $this->docModel->codalmacen;
            $recurring->codagente = $this->docModel->codagente;
            $recurring->coddivisa = $this->docModel->coddivisa;
            $recurring->codpago = $this->docModel->codpago;
            $recurring->codserie = $this->docModel->codserie;
            $recurring->lastdate = $this->docModel->fecha;
            $recurring->notesdocument = $this->docModel->observaciones;
            $recurring->nick = Session::user()->nick;
            $recurring->startdate = $this->docModel->fecha;
            return $recurring->save();
        };
    }
}
