<?php
/**
 * This file is part of the DocumentosRecurrentes plugin for FacturaScripts.
 * FacturaScripts         Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * DocumentosRecurrentes  Copyright (C) 2020-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
* This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\DocumentosRecurrentes\Model;

use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Dinamic\Model\DocRecurringSaleLine;
use FacturaScripts\Plugins\DocumentosRecurrentes\Model\Base\DocRecurring;

/**
 * Class that manages the data model of the document recurring sale.
*
 * @author Jose Antonio Cuello  <yopli2000@gmail.com>
 */
class DocRecurringSale extends DocRecurring
{
    use ModelTrait;

    /**
     * Link with the agent model
     *
     * @var string
     */
    public $codagente;

    /**
     * Link with the customer model
     *
     * @var string
     */
    public $codcliente;

    /**
     * Returns a new line for the document.
     *
     * @param array $data
     * @param array $exclude
     * @return DocRecurringSaleLine
     */
    public function getNewLine(array $data = [], array $exclude = ['id', 'iddoc']): DocRecurringSaleLine
    {
        $newLine = new DocRecurringSaleLine();
        $newLine->iddoc = $this->id;
        $newLine->loadFromData($data, $exclude);
        return $newLine;
    }
    /**
     * Returns the lines associated with the document.
     *
     * @return DocRecurringSaleLine[]
     */
    public function getLines(): array
    {
        return DocRecurringSaleLine::all(
            [new DataBaseWhere('iddoc', $this->id)],
            ['id' => 'ASC']
        );
    }

    /**
     * Returns the name of the table that uses this model.
     *
     * @return string
     */
    public static function tableName(): string
    {
        return 'docrecurrentes_sale';
    }
}
