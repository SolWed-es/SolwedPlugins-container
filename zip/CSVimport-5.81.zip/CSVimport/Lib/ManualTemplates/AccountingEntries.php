<?php
/**
 * Copyright (C) 2020-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\CSVimport\Lib\ManualTemplates;

use FacturaScripts\Core\DataSrc\Empresas;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Lib\CsvFileTools;
use FacturaScripts\Dinamic\Model\Asiento;
use FacturaScripts\Dinamic\Model\Ejercicio;
use FacturaScripts\Dinamic\Model\Partida;
use FacturaScripts\Dinamic\Model\Subcuenta;
use FacturaScripts\Plugins\CSVimport\Contract\ManualTemplateInterface;

/**
 * @author Carlos Garcia Gomez      <carlos@facturascripts.com>
 * @author Daniel Fernandez Giménez <hola@danielfg.es>
 */
class AccountingEntries extends ManualTemplateClass implements ManualTemplateInterface
{
    public function getDataFields(): array
    {
        return [
            'asiento' => ['title' => 'accounting-entry'],
            'linea' => ['title' => 'line'],
            'fecha' => ['title' => 'date'],
            'concepto' => ['title' => 'concept'],
            'cuenta' => ['title' => 'account'],
            'debe' => ['title' => 'debit'],
            'haber' => ['title' => 'credit'],
            'idempresa' => ['title' => 'company-id'],
        ];
    }

    public function getFieldsToColumn(): array
    {
        return [];
    }

    public static function getProfile(): string
    {
        return 'accounting-entries';
    }

    public function getRequiredFieldsAnd(): array
    {
        return ['cuenta', 'debe', 'haber', 'fecha', 'concepto', 'asiento'];
    }

    public function getRequiredFieldsOr(): array
    {
        return [];
    }

    public function importItem(array $item): bool
    {
        // obtener año de la fecha de la partida
        $fecha = CsvFileTools::formatDate($item['fecha']);
        $year = date('Y', strtotime($fecha));

        // obtenemos la empresa
        $idempresa = false === empty($item['idempresa'])
            ? $item['idempresa']
            : Tools::settings('default', 'idempresa');

        // si la empresa no existe, paramos la ejecución
        if (empty(Empresas::get($idempresa)->id())) {
            Tools::log()->error('company-not-found', ['%companyId%' => $idempresa]);
            return false;
        }

        // busca si existe el ejercicio, si no existe lo crea
        $exercise = new Ejercicio();
        $whereExercise = [
            Where::column('fechainicio', $year . '-01-01'),
            Where::column('fechafin', $year . '-12-31'),
            Where::column('idempresa', $idempresa)
        ];

        if (false === $exercise->loadWhere($whereExercise)) {
            $exercise->codejercicio = $year;
            $exercise->nombre = $year;
            $exercise->fechainicio = $year . '-01-01';
            $exercise->fechafin = $year . '-12-31';
            $exercise->idempresa = $idempresa;
            if (false === $exercise->save()) {
                Tools::log()->error('error-when-creating-the-fiscal-year-for-the-year', ['%year%' => $year]);
                return false;
            }
        }

        // busca si existe la subcuenta, si no existe paramos la ejecución
        $subaccount = new Subcuenta();
        $whereAccount = [
            Where::column('codsubcuenta', $item['cuenta']),
            Where::column('codejercicio', $exercise->codejercicio)
        ];
        if (false === $subaccount->loadWhere($whereAccount)) {
            Tools::log()->error('subaccount-not-found', ['%subAccountCode%' => $item['cuenta']]);
            return false;
        }

        // busca si existe el asiento
        $entry = new Asiento();
        $where = [
            Where::column('codejercicio', $exercise->codejercicio),
            Where::column('fecha', $fecha),
            Where::column('documento', $item['asiento']),
            Where::column('idempresa', $exercise->idempresa),
        ];

        // no existe, lo creamos
        if (false === $entry->loadWhere($where)) {
            $entry->idempresa = $exercise->idempresa;
            $entry->codejercicio = $exercise->codejercicio;
            $entry->concepto = Tools::noHtml($item['concepto']);
            if ($item['concepto'] === 'ASIENTO DE APERTURA') {
                $entry->operacion = $entry::OPERATION_OPENING;
            }
            $entry->documento = $item['asiento'];
            $entry->fecha = $fecha;
            $entry->importe = max([CsvFileTools::formatFloat($item['debe']), CsvFileTools::formatFloat($item['haber'])]);
            if (false === $entry->save()) {
                Tools::log()->error('error-creating-entry', ['%entry%' => $item['asiento']]);
                return false;
            }
        }

        // busca si existe la partida dentro del asiento
        $line = new Partida();
        $where = [Where::column('idasiento', $entry->idasiento),];

        if (isset($item['linea']) && false === empty($item['linea'])) {
            $where[] = Where::column('documento', $item['linea']);
        } else {
            $where[] = Where::column('codsubcuenta', $item['cuenta']);
            $where[] = Where::column('debe', CsvFileTools::formatFloat($item['debe']));
            $where[] = Where::column('haber', CsvFileTools::formatFloat($item['haber']));
        }

        if ($line->loadWhere($where) && $this->model->mode === CsvFileTools::INSERT_MODE
            || false === $line->loadWhere($where) && $this->model->mode === CsvFileTools::UPDATE_MODE) {
            return false;
        }

        $line->idasiento = $entry->idasiento;
        $line->concepto = Tools::noHtml($item['concepto']);
        $line->codsubcuenta = Tools::noHtml($item['cuenta']);
        $line->idsubcuenta = $subaccount->idsubcuenta;
        $line->debe = CsvFileTools::formatFloat($item['debe']);
        $line->haber = CsvFileTools::formatFloat($item['haber']);
        $line->documento = $item['linea'] ?? '';
        if (false === $line->save()) {
            Tools::log()->error('accounting-lines-error', ['%entry%' => $item['asiento']]);
            return false;
        }

        return true;
    }
}
