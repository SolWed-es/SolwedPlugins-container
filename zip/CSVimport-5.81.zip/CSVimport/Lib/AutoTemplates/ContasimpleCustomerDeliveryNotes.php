<?php
/**
 * Copyright (C) 2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\CSVimport\Lib\AutoTemplates;

use FacturaScripts\Core\Lib\Calculator;
use FacturaScripts\Core\DataSrc\Impuestos;
use FacturaScripts\Core\DataSrc\Paises;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Lib\BusinessDocumentCode;
use FacturaScripts\Dinamic\Lib\CsvFileTools;
use FacturaScripts\Dinamic\Model\AlbaranCliente;
use FacturaScripts\Dinamic\Model\Cliente;
use FacturaScripts\Dinamic\Model\Ejercicio;
use FacturaScripts\Plugins\CSVimport\Contract\AutoTemplateInterface;

class ContasimpleCustomerDeliveryNotes implements AutoTemplateInterface
{
    const LIMIT_IMPORT = 10;

    /** @var bool */
    private $continue = false;

    /** @var int */
    private $start = 0;

    /** @var int */
    private $total_lines = 0;

    public function continue(): bool
    {
        return $this->continue;
    }

    public function getTotalLines(): int
    {
        return $this->total_lines;
    }

    public function isValid(string $filePath, string $profile): bool
    {
        if ($profile !== 'customer-delivery-notes') {
            return false;
        }

        $expectedColumns = [
            'NÚM. REG.',
            'TIPO LINEA',
            'NÚMERO',
            'FECHA',
            'FECHA VALIDEZ',
            'ESTADO',
            'INICIO SERVICIO',
            'FIN SERVICIO',
            'CONCEPTO LINEA',
            'B.I. UNITARIA LINEA',
            'CANTIDAD LINEA',
            '% DESCUENTO LINEA',
            'B.I. TOTAL LINEA',
            'TIPO IVA',
            'TOTAL IVA LINEA',
            'DESCRIPCION DETALLADA LINEA',
            'BASE IMPONIBLE',
            'RET. %',
            'TOTAL RET.',
            'TOTAL ALBARÁN',
            'NOMBRE O RAZÓN SOCIAL',
            'NIF',
            'DIRECCIÓN',
            'CÓDIGO POSTAL',
            'POBLACIÓN',
            'PROVINCIA',
            'PAÍS',
            'TELÉFONO',
            'NOMBRE O RAZÓN SOCIAL_1',
            'NIF_1',
            'DIRECCIÓN_1',
            'CÓDIGO POSTAL_1',
            'POBLACIÓN_1',
            'PROVINCIA_1',
            'PAÍS_1',
            'TELÉFONO_1',
            'NOTAS EN EL ALBARÁN',
            'NOTAS PRIVADAS'
        ];

        // probamos empezando desde las líneas 0 a la 6
        foreach (range(0, 6) as $start) {
            $this->start = $start;
            $csv = CsvFileTools::read($filePath, $start, 0, 1);
            $this->total_lines = CsvFileTools::getTotalLines();

            if (isset($csv['titles'])) {
                $headers = array_map('trim', $csv['titles']);
                // Comprobar que todas las columnas esperadas están presentes
                if (empty(array_diff($expectedColumns, $headers))) {
                    return true;
                }
            }
        }

        return false;
    }

    public function run(string $filePath, string $profile, string $mode, int &$offset, int &$saveLines): bool
    {
        $csv = CsvFileTools::read($filePath, $this->start);
        $delivery_notes = $this->readDeliveryNotes($csv['data']);
        $this->total_lines = count($delivery_notes);
        $this->continue = false;

        // recorremos los albaranes empezando por el offset y terminando por el limit
        for ($i = $offset; $i < min($this->total_lines, $offset + static::LIMIT_IMPORT); $i++) {
            $row = $delivery_notes[$i]['note'];

            $this->continue = true;

            // si el estado es Facturado, Rechazado o Cerrado, lo ignoramos
            if (in_array($row['ESTADO'], ['Facturado', 'Rechazado', 'Cerrado'])) {
                continue;
            }

            // obtenemos el ejercicio para la fecha del albarán
            $exercise = new Ejercicio();
            $exercise->idempresa = Tools::settings('default', 'idempresa');
            $exercise->loadFromDate(CsvFileTools::formatDate($row['FECHA']));
            if (empty($exercise->id())) {
                Tools::log()->warning('exercise-not-found', ['%date%' => $row['FECHA']]);
                continue;
            }

            // buscamos si ya existe el albarán
            $old = new AlbaranCliente();
            $where = [
                Where::column('codigo', $row['NÚMERO']),
                Where::column('codejercicio', $exercise->codejercicio),
            ];
            if ($old->loadWhere($where)) {
                continue;
            }

            // creamos el albarán
            $delivery_note = new AlbaranCliente();
            $delivery_note->setSubject(static::getCustomer($row));
            $delivery_note->idempresa = $exercise->idempresa;
            $delivery_note->codejercicio = $exercise->codejercicio;
            $delivery_note->fecha = CsvFileTools::formatDate($row['FECHA']);
            $delivery_note->hora = date('H:i:s');
            $delivery_note->codigo = $row['NÚMERO'];
            BusinessDocumentCode::setNewNumber($delivery_note);

            $delivery_note->direccion = mb_substr(Tools::noHtml($row['DIRECCIÓN']), 0, 100);
            $delivery_note->codpostal = mb_substr(Tools::noHtml($row['CÓDIGO POSTAL']), 0, 10);
            $delivery_note->ciudad = mb_substr(Tools::noHtml($row['POBLACIÓN']), 0, 50);
            $delivery_note->provincia = mb_substr(Tools::noHtml($row['PROVINCIA']), 0, 50);
            foreach (Paises::all() as $pais) {
                if (strtolower($pais->nombre) === strtolower($row['PAÍS'])) {
                    $delivery_note->codpais = $pais->codpais;
                    break;
                }
            }

            $delivery_note->observaciones = $row['NOTAS EN EL ALBARÁN'];
            if (false === $delivery_note->save()) {
                return false;
            }

            $saveLines++;

            // añadimos las líneas
            foreach ($delivery_notes[$i]['lines'] as $line) {
                $newLine = $delivery_note->getNewLine();
                $newLine->descripcion = $line['CONCEPTO LINEA'];
                $newLine->cantidad = (float)$line['CANTIDAD LINEA'];
                $newLine->pvpunitario = CsvFileTools::formatFloat($line['B.I. UNITARIA LINEA']);
                $newLine->dtopor = CsvFileTools::formatFloat($line['% DESCUENTO LINEA']);

                $iva = CsvFileTools::formatFloat($line['TIPO IVA']);
                foreach (Impuestos::all() as $impuesto) {
                    if (abs($impuesto->iva - $iva) < 0.01) {
                        $newLine->codimpuesto = $impuesto->codimpuesto;
                        $newLine->iva = $impuesto->iva;
                        $newLine->recargo = 0;
                        break;
                    }
                }

                $newLine->irpf = CsvFileTools::formatFloat($row['RET. %']);
                $newLine->save();
            }

            // actualizamos los totales
            $lines = $delivery_note->getLines();
            Calculator::calculate($delivery_note, $lines, true);
            if (abs($delivery_note->total - CsvFileTools::formatFloat($row['TOTAL ALBARÁN'])) > 0.02) {
                Tools::log()->warning('total-value-error', [
                    '%docType%' => $delivery_note->modelClassName(),
                    '%docCode%' => $delivery_note->codigo,
                    '%docTotal%' => $delivery_note->total,
                    '%calcTotal%' => CsvFileTools::formatFloat($row['TOTAL ALBARÁN'])
                ]);
            }
        }

        $offset += static::LIMIT_IMPORT;

        return true;
    }

    protected static function getCustomer(array $line): Cliente
    {
        // buscamos por NIF
        $customer = new Cliente();
        $where = [Where::column('cifnif', $line['NIF_1'])];
        if ($customer->loadWhere($where)) {
            return $customer;
        }

        // no existe, lo creamos
        $customer->nombre = $line['NOMBRE O RAZÓN SOCIAL_1'];
        $customer->cifnif = $line['NIF_1'];
        $customer->telefono1 = $line['TELÉFONO'];
        $customer->save();

        return $customer;
    }

    protected function readDeliveryNotes(array $data): array
    {
        // Inicializar el array para almacenar los albaranes
        $delivery_notes = [];
        $current = [];

        foreach ($data as $row) {
            // Comprobación para detectar el inicio de un nuevo albarán
            if ($row['TIPO LINEA'] == 'Cabecera') {
                if (!empty($current)) {
                    // Si ya tenemos un albarán acumulado, lo añadimos a la lista de albaranes
                    $delivery_notes[] = $current;
                }
                $current = ['date' => $row['FECHA'], 'note' => $row, 'lines' => []];
            } elseif ($row['TIPO LINEA'] == 'Detalle') {
                // Si estamos en una línea de detalle, la añadimos al albarán actual
                $current['lines'][] = $row;
            }
        }

        // Añadir el último albarán leído, si existe
        if (!empty($current)) {
            $delivery_notes[] = $current;
        }

        // ordenamos por fecha, de menor a mayor
        usort($delivery_notes, function ($a, $b) {
            $date_a = CsvFileTools::formatDate($a['date']);
            $date_b = CsvFileTools::formatDate($b['date']);
            return strtotime($date_a) <=> strtotime($date_b);
        });

        return $delivery_notes;
    }
}
