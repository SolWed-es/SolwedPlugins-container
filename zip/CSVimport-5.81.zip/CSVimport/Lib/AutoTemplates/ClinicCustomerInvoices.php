<?php
/**
 * Copyright (C) 2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\CSVimport\Lib\AutoTemplates;

use FacturaScripts\Core\Lib\Calculator;
use FacturaScripts\Core\DataSrc\FormasPago;
use FacturaScripts\Core\DataSrc\Impuestos;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Lib\BusinessDocumentCode;
use FacturaScripts\Dinamic\Lib\CsvFileTools;
use FacturaScripts\Dinamic\Model\Cliente;
use FacturaScripts\Dinamic\Model\Ejercicio;
use FacturaScripts\Dinamic\Model\FacturaCliente;
use FacturaScripts\Plugins\CSVimport\Contract\AutoTemplateInterface;

class ClinicCustomerInvoices implements AutoTemplateInterface
{
    const LIMIT_IMPORT = 10;

    /** @var bool */
    private $continue = false;

    /** @var int */
    private $start = 0;

    /** @var int */
    private $total_lines = 0;

    public function continue(): bool
    {
        return $this->continue;
    }

    public function getTotalLines(): int
    {
        return $this->total_lines;
    }

    public function isValid(string $filePath, string $profile): bool
    {
        if ($profile !== 'customer-invoices') {
            return false;
        }

        // probamos empezando desde las líneas 0 a la 6
        foreach (range(0, 6) as $start) {
            $this->start = $start;
            $csv = CsvFileTools::read($filePath, $start);

            if (count($csv['titles']) < 2) {
                continue;
            }

            if ($csv['titles'][0] === 'Nº de Factura' &&
                $csv['titles'][1] === 'Nº de Fact. Simplificada' &&
                $csv['titles'][2] === 'Fecha de Factura' &&
                $csv['titles'][5] === 'Código de Cliente' &&
                $csv['titles'][9] === 'Base Imponible (0%)' &&
                $csv['titles'][13] === 'IVA (0%)' &&
                $csv['titles'][22] === 'Total') {
                $invoices = $this->readInvoices($csv['data']);
                $this->total_lines = count($invoices);
                return true;
            }
        }

        return false;
    }

    public function run(string $filePath, string $profile, string $mode, int &$offset, int &$saveLines): bool
    {
        $csv = CsvFileTools::read($filePath, $this->start);
        $invoices = $this->readInvoices($csv['data']);
        $this->total_lines = count($invoices);
        $this->continue = false;

        // recorremos las facturas empezando por el offset y terminando por el limit
        for ($i = $offset; $i < min($this->total_lines, $offset + static::LIMIT_IMPORT); $i++) {
            $row = $invoices[$i]['invoice'];

            $this->continue = true;

            // obtenemos el ejercicio para la fecha de la factura
            $exercise = new Ejercicio();
            $exercise->idempresa = Tools::settings('default', 'idempresa');
            $exercise->loadFromDate(CsvFileTools::formatDate($row['Fecha de Factura']));
            if (empty($exercise->id())) {
                Tools::log()->warning('exercise-not-found', ['%date%' => $row['Fecha de Factura']]);
                continue;
            }

            // buscamos si ya existe la factura
            $oldInvoice = new FacturaCliente();
            $where = [
                Where::column('codigo', $row['Nº de Factura']),
                Where::column('codejercicio', $exercise->codejercicio)
            ];
            if ($oldInvoice->loadWhere($where)) {
                continue;
            }

            // creamos la factura
            $newInvoice = new FacturaCliente();
            $newInvoice->setSubject(static::getCustomer($row));
            $newInvoice->idempresa = $exercise->idempresa;
            $newInvoice->codejercicio = $exercise->codejercicio;
            $newInvoice->fecha = CsvFileTools::formatDate($row['Fecha de Factura']);
            $newInvoice->hora = date('H:i:s');
            $newInvoice->codigo = $row['Nº de Factura'];
            BusinessDocumentCode::setNewNumber($newInvoice);
            $newInvoice->codpago = static::getCodpago($row, $newInvoice->codpago);
            if (false === $newInvoice->save()) {
                break;
            }

            $saveLines++;

            // añadimos las líneas
            $tax_types = [
                'Base Imponible (0%)' => 0,
                'Base Imponible (4%)' => 4,
                'Base Imponible (10%)' => 10,
                'Base Imponible (21%)' => 21,
            ];
            foreach ($tax_types as $tax_type => $tax_value) {
                if (floatval($row[$tax_type]) != 0) {
                    $newLine = $newInvoice->getNewLine();
                    $newLine->descripcion = $tax_type;
                    $newLine->cantidad = 1;
                    $newLine->pvpunitario = CsvFileTools::formatFloat($row[$tax_type]);
                    foreach (Impuestos::all() as $imp) {
                        if ($imp->iva == $tax_value) {
                            $newLine->codimpuesto = $imp->codimpuesto;
                            $newLine->iva = $imp->iva;
                            $newLine->recargo = 0;
                            break;
                        }
                    }
                    if (false === $newLine->save()) {
                        break 2;
                    }
                }
            }

            // actualizamos los totales
            $lines = $newInvoice->getLines();
            Calculator::calculate($newInvoice, $lines, true);
            if (abs($newInvoice->total - CsvFileTools::formatFloat($row['Total'])) > 0.02) {
                Tools::log()->warning('total-value-error', [
                    '%docType%' => $newInvoice->modelClassName(),
                    '%docCode%' => $newInvoice->codigo,
                    '%docTotal%' => $newInvoice->total,
                    '%calcTotal%' => CsvFileTools::formatFloat($row['Total'])
                ]);
            }

            // ¿La factura está pagada?
            if (isset($row['Pendiente']) && empty($row['Pendiente'])) {
                foreach ($newInvoice->getReceipts() as $receipt) {
                    $receipt->fechapago = $newInvoice->fecha;
                    $receipt->pagado = true;
                    $receipt->save();
                }
            }
        }

        $offset += static::LIMIT_IMPORT;

        return true;
    }

    protected static function getCodpago(array $line, ?string $default): ?string
    {
        if (floatval($line['Efectivo']) != 0) {
            foreach (FormasPago::all() as $forma) {
                if (strtolower($forma->codpago) === 'efectivo') {
                    return $forma->codpago;
                }
            }
        }

        if (floatval($line['Tarjeta']) != 0) {
            foreach (FormasPago::all() as $forma) {
                if (strtolower($forma->codpago) === 'tarjeta') {
                    return $forma->codpago;
                }
            }
        }

        if (floatval($line['Transferencia']) != 0) {
            foreach (FormasPago::all() as $forma) {
                if (strtolower($forma->codpago) === 'transferen') {
                    return $forma->codpago;
                }
            }
        }

        return $default;
    }

    protected static function getCustomer(array $line): Cliente
    {
        $customer = new Cliente();
        if ($customer->load($line['Código de Cliente'])) {
            return $customer;
        }

        // buscamos por DNI
        $where = [Where::column('cifnif', $line['DNI'])];
        if ($customer->loadWhere($where)) {
            return $customer;
        }

        // no existe el cliente, lo creamos
        $customer->codcliente = $line['Código de Cliente'];
        $customer->nombre = $line['Nombre de Cliente'];
        $customer->cifnif = $line['DNI'];
        $customer->save();

        return $customer;
    }

    protected function readInvoices(array $data): array
    {
        // Inicializar el array para almacenar las facturas
        $invoices = [];

        foreach ($data as $row) {
            if (empty($row['Fecha de Factura'] ?? '')) {
                continue; // saltamos filas sin fecha de factura
            }

            $invoices[] = ['date' => $row['Fecha de Factura'], 'invoice' => $row];
        }

        // ordenamos por fecha, de menor a mayor
        usort($invoices, function ($a, $b) {
            $date_a = CsvFileTools::formatDate($a['date']);
            $date_b = CsvFileTools::formatDate($b['date']);
            return strtotime($date_a) <=> strtotime($date_b);
        });

        return $invoices;
    }
}
