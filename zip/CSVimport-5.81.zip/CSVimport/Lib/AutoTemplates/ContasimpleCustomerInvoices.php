<?php
/**
 * Copyright (C) 2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\CSVimport\Lib\AutoTemplates;

use FacturaScripts\Core\Lib\Calculator;
use FacturaScripts\Core\DataSrc\Impuestos;
use FacturaScripts\Core\DataSrc\Paises;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Lib\BusinessDocumentCode;
use FacturaScripts\Dinamic\Lib\CsvFileTools;
use FacturaScripts\Dinamic\Model\Cliente;
use FacturaScripts\Dinamic\Model\Ejercicio;
use FacturaScripts\Dinamic\Model\FacturaCliente;
use FacturaScripts\Plugins\CSVimport\Contract\AutoTemplateInterface;

class ContasimpleCustomerInvoices implements AutoTemplateInterface
{
    const LIMIT_IMPORT = 10;

    /** @var bool */
    private $continue = false;

    /** @var int */
    private $start = 0;

    /** @var int */
    private $total_lines = 0;

    public function continue(): bool
    {
        return $this->continue;
    }

    public function getTotalLines(): int
    {
        return $this->total_lines;
    }

    public function isValid(string $filePath, string $profile): bool
    {
        if ($profile !== 'customer-invoices') {
            return false;
        }

        $expectedColumns = [
            'NÚM. REG.',
            'TIPO LINEA',
            'NÚMERO',
            'FECHA',
            'FECHA VENCIMIENTO',
            'ESTADO',
            'INICIO SERVICIO',
            'FIN SERVICIO',
            'CONCEPTO LINEA',
            'B.I. UNITARIA LINEA',
            'CANTIDAD LINEA',
            '% DESCUENTO LINEA',
            'B.I. TOTAL LINEA',
            'TIPO IVA',
            'TOTAL IVA LINEA',
            'DESCRIPCION DETALLADA LINEA',
            'BASE IMPONIBLE',
            'RET. %',
            'TOTAL RET.',
            'TOTAL FACTURA',
            'TIPO INGRESO',
            'DESC. TIPO INGRESO',
            'TIPO OPERACIÓN',
            'NOMBRE O RAZÓN SOCIAL',
            'NIF',
            'DIRECCIÓN',
            'CÓDIGO POSTAL',
            'POBLACIÓN',
            'PROVINCIA',
            'PAÍS',
            'TELÉFONO',
            'CRITERIO DE CAJA',
            'NOMBRE O RAZÓN SOCIAL_1',
            'NIF_1',
            'DIRECCIÓN_1',
            'CÓDIGO POSTAL_1',
            'POBLACIÓN_1',
            'PROVINCIA_1',
            'PAÍS_1',
            'TELÉFONO_1',
            'NOTAS EN FACTURA',
            'NOTAS PRIVADAS',
            'FECHA PAGO',
            'IMPORTE',
            'MÉTODO DE PAGO',
            'TIPO DE MÉTODO DE PAGO',
            'NÚMERO CUENTA/TARJETA'
        ];

        // probamos empezando desde las líneas 0 a la 6
        foreach (range(0, 6) as $start) {
            $this->start = $start;
            $csv = CsvFileTools::read($filePath, $start, 0, 1);
            $this->total_lines = CsvFileTools::getTotalLines();

            if (isset($csv['titles'])) {
                $headers = array_map('trim', $csv['titles']);
                // Comprobar que todas las columnas esperadas están presentes
                if (empty(array_diff($expectedColumns, $headers))) {
                    return true;
                }
            }
        }

        return false;
    }

    public function run(string $filePath, string $profile, string $mode, int &$offset, int &$saveLines): bool
    {
        $csv = CsvFileTools::read($filePath, $this->start);
        $invoices = $this->readInvoices($csv['data']);
        $this->total_lines = count($invoices);
        $this->continue = false;

        // recorremos las facturas empezando por el offset y terminando por el limit
        for ($i = $offset; $i < min($this->total_lines, $offset + static::LIMIT_IMPORT); $i++) {
            $row = $invoices[$i]['invoice'];

            $this->continue = true;

            // obtenemos el ejercicio para la fecha de la factura
            $exercise = new Ejercicio();
            $exercise->idempresa = Tools::settings('default', 'idempresa');
            $exercise->loadFromDate(CsvFileTools::formatDate($row['FECHA']));
            if (empty($exercise->id())) {
                Tools::log()->warning('exercise-not-found', ['%date%' => $row['FECHA']]);
                continue;
            }

            // buscamos si ya existe la factura
            $oldInvoice = new FacturaCliente();
            $where = [
                Where::column('codigo', $row['NÚMERO']),
                Where::column('codejercicio', $exercise->codejercicio),
            ];
            if ($oldInvoice->loadWhere($where)) {
                continue;
            }

            // creamos la factura
            $newInvoice = new FacturaCliente();
            $newInvoice->setSubject(static::getCustomer($row));
            $newInvoice->idempresa = $exercise->idempresa;
            $newInvoice->codejercicio = $exercise->codejercicio;
            $newInvoice->fecha = CsvFileTools::formatDate($row['FECHA']);
            $newInvoice->hora = date('H:i:s');
            $newInvoice->codigo = $row['NÚMERO'];
            BusinessDocumentCode::setNewNumber($newInvoice);

            $newInvoice->direccion = mb_substr(Tools::noHtml($row['DIRECCIÓN']), 0, 100);
            $newInvoice->codpostal = mb_substr(Tools::noHtml($row['CÓDIGO POSTAL']), 0, 10);
            $newInvoice->ciudad = mb_substr(Tools::noHtml($row['POBLACIÓN']), 0, 50);
            $newInvoice->provincia = mb_substr(Tools::noHtml($row['PROVINCIA']), 0, 50);
            foreach (Paises::all() as $pais) {
                if (strtolower($pais->nombre) === strtolower($row['PAÍS'])) {
                    $newInvoice->codpais = $pais->codpais;
                    break;
                }
            }

            $newInvoice->observaciones = $row['NOTAS EN FACTURA'];
            if (false === $newInvoice->save()) {
                return false;
            }

            $saveLines++;

            // añadimos las líneas
            foreach ($invoices[$i]['lines'] as $line) {
                $newLine = $newInvoice->getNewLine();
                $newLine->descripcion = $line['CONCEPTO LINEA'];
                $newLine->cantidad = (float)$line['CANTIDAD LINEA'];
                $newLine->pvpunitario = CsvFileTools::formatFloat($line['B.I. UNITARIA LINEA']);
                $newLine->dtopor = CsvFileTools::formatFloat($line['% DESCUENTO LINEA']);

                $iva = CsvFileTools::formatFloat($line['TIPO IVA']);
                foreach (Impuestos::all() as $impuesto) {
                    if (abs($impuesto->iva - $iva) < 0.01) {
                        $newLine->codimpuesto = $impuesto->codimpuesto;
                        $newLine->iva = $impuesto->iva;
                        $newLine->recargo = 0;
                        break;
                    }
                }

                $newLine->irpf = CsvFileTools::formatFloat($row['RET. %']);
                $newLine->save();
            }

            // actualizamos los totales
            $lines = $newInvoice->getLines();
            Calculator::calculate($newInvoice, $lines, true);
            if (abs($newInvoice->total - CsvFileTools::formatFloat($row['TOTAL FACTURA'])) > 0.02) {
                Tools::log()->warning('total-value-error', [
                    '%docType%' => $newInvoice->modelClassName(),
                    '%docCode%' => $newInvoice->codigo,
                    '%docTotal%' => $newInvoice->total,
                    '%calcTotal%' => CsvFileTools::formatFloat($row['TOTAL FACTURA'])
                ]);
            }

            // ¿La factura está pagada?
            if ($row['ESTADO'] === 'Pagado') {
                foreach ($newInvoice->getReceipts() as $receipt) {
                    $receipt->fechapago = CsvFileTools::formatDate($row['FECHA PAGO']);
                    $receipt->pagado = true;
                    $receipt->save();
                }
            }
        }

        $offset += static::LIMIT_IMPORT;

        return true;
    }

    protected static function getCustomer(array $line): Cliente
    {
        // buscamos por NIF
        $customer = new Cliente();
        $where = [Where::column('cifnif', $line['NIF_1'])];
        if ($customer->loadWhere($where)) {
            return $customer;
        }

        // no existe, lo creamos
        $customer->nombre = $line['NOMBRE O RAZÓN SOCIAL_1'];
        $customer->cifnif = $line['NIF_1'];
        $customer->telefono1 = $line['TELÉFONO'];
        $customer->save();

        return $customer;
    }

    protected function readInvoices(array $data): array
    {
        // Inicializar el array para almacenar las facturas
        $invoices = [];
        $currentInvoice = [];

        foreach ($data as $row) {
            // Comprobación para detectar el inicio de una nueva factura
            if ($row['TIPO LINEA'] == 'Cabecera') {
                if (!empty($currentInvoice)) {
                    // Si ya tenemos una factura acumulada, la añadimos a la lista de invoices
                    $invoices[] = $currentInvoice;
                }
                $currentInvoice = ['date' => $row['FECHA'], 'invoice' => $row, 'lines' => []];
            } elseif ($row['TIPO LINEA'] == 'Detalle') {
                // Si estamos en una línea de detalle, la añadimos a la factura actual
                $currentInvoice['lines'][] = $row;
            }
        }

        // Añadir la última factura leída, si existe
        if (!empty($currentInvoice)) {
            $invoices[] = $currentInvoice;
        }

        // ordenamos por fecha, de menor a mayor
        usort($invoices, function ($a, $b) {
            $date_a = CsvFileTools::formatDate($a['date']);
            $date_b = CsvFileTools::formatDate($b['date']);
            return strtotime($date_a) <=> strtotime($date_b);
        });

        return $invoices;
    }
}
