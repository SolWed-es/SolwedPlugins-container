# Proyectos
Plugin para gestionar proyectos en FacturaScripts.
- https://facturascripts.com/plugins/proyectos

## Carpeta
La carpeta debe llamarse igual que el plugin: **Proyectos**.