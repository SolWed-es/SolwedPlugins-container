<?php
/**
 * This file is part of Textos plugin for FacturaScripts
 * Copyright (C) 2023 Carlos Garcia Gomez <carlos@facturascripts.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace FacturaScripts\Plugins\Textos\Mod;

use FacturaScripts\Core\Contract\SalesModInterface;
//use FacturaScripts\Core\Base\Translator;
use FacturaScripts\Core\Model\Base\SalesDocument;
//use FacturaScripts\Core\Model\User;
use FacturaScripts\Core\Tools;

use FacturaScripts\Dinamic\Model\GrupoTexto;

/**
 * Description of SalesHeaderHTMLModTextos
 *
 * @author Jorge-Prebac <info@smartcuines.com>
 */
class SalesHeaderHTMLModTextos implements SalesModInterface
{
    public function apply(SalesDocument &$model, array $formData): void
    {
    }

    public function applyBefore(SalesDocument &$model, array $formData): void
    {
    }

    public function assets(): void
    {
    }

	public function newBtnFields(): array
	{
		return ['texto'];
	}

	public function newFields(): array
	{
		return [];
	}

	public function newModalFields(): array
	{
		return [];
	}

    public function renderField(SalesDocument $model, string $field): ?string
    {
		if ($field === 'texto') {
			return self::textGroup($model);
		}
        return null;
    }

	private static function textGroup(SalesDocument $model): string
    {
        $html = '<div class="col-sm-auto">'
            . '<div class="mb-2">'
			. '<button class="btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#ModalTextGroups">'
            . '<i class="fa-solid fa-spell-check"></i> ' . Tools::trans('texts') . '</button>'
            . '</div>'
            . '</div>'
			 . self::groupsTextModal($model);
		return $html;
	}

	private static function groupsTextModal(SalesDocument $model): string
    {
        $gruposTextoModel = new GrupoTexto();
		$grupostextos = $gruposTextoModel->all([], ['nombregrupo' => 'ASC'], 0, 0);
		$html = '<div class="modal fade" id="ModalTextGroups" tabindex="-1" aria-labelledby="ModalTextGroupsLabel" aria-hidden="true">'
						. '<div class="modal-dialog modal-dialog-centered">'
						. '<div class="modal-content">'
						. '<div class="modal-header">'
						. '<i class="fa-solid fa-layer-group fa-2x"></i>'
						. '<h5 class="modal-title">' . Tools::trans('text-groups') . '</h5>'
						. '<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">'
						. ''
						. '</button>'
						. '</div>'
						. '<div class="modal-body">'
						. '<div class="col-md-auto">'
						. '<ul>';
		if (count($grupostextos) > 0) {
			foreach ($grupostextos as $grupotexto) {
				$html .= '<li><a href= "' . $grupotexto->url() . '" target=_blank>' . $grupotexto->nombregrupo . '</a></li>';
			}
		} else {
			$html .= '<li><a href= "' . $gruposTextoModel->url() . '" target=_blank>' . Tools::trans('create-new-record') . '</a></li>';
		}
		$html .= '</ul>'
						. '</div>'
						. '</div>'
						. '<div class="modal-footer">'
						. '<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">' . Tools::trans('close') . '</button>'
						. '<button type="button" class="btn btn-primary" data-bs-dismiss="modal">' . Tools::trans('accept') . '</button>'
						. '</div>'
						. '</div>'
						. '</div>'
						. '</div>';
		return $html;
	}
}