<?php
/**
 * @author Carlos García Gómez <carlos@facturascripts.com>
 * @copyright 2020-2025, Carlos García Gómez. All Rights Reserved.
 */

namespace FacturaScripts\Plugins\Shopeame;

use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Model\ApiKey;
use FacturaScripts\Core\Template\InitClass;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\FacturaCliente;
use FacturaScripts\Dinamic\Model\PedidoCliente;
use FacturaScripts\Plugins\Shopeame\Lib\Shopeame\ApiClient;

/**
 * Description of Init
 *
 * @author Carlos García Gómez <carlos@facturascripts.com>
 */
final class Init extends InitClass
{
    public function init(): void
    {
        $this->loadExtension(new Extension\Controller\EditFacturaCliente());
    }

    public function uninstall(): void
    {
        $this->disabledApi();
    }

    public function update(): void
    {
        new Model\Shopeame();
        new Model\ShopeameOrder();
        new FacturaCliente();
        new PedidoCliente();

        $this->enabledApi();
    }

    private function disabledApi(): void
    {
        // buscamos la clave de la api
        $api = new ApiKey();
        $where = [new DataBaseWhere('description', 'shopea.me')];
        if (false === $api->loadWhere($where)) {
            // no hay, no hacemos nada
            return;
        }

        $api->enabled = false;
        $api->save();
    }

    private function enabledApi(): void
    {
        // buscamos la clave de la api
        $api = new ApiKey();
        $where = [new DataBaseWhere('description', 'shopea.me')];
        if (false === $api->loadWhere($where)) {
            // no hay, no hacemos nada
            return;
        }

        // la habilitamos
        $api->enabled = true;
        $api->fullaccess = true;
        $api->save();

        // actualizamos los datos de conexión
        ApiClient::update(
            Tools::settings('shopeame', 'connid', ''),
            Tools::settings('shopeame', 'signkey', '')
        );
    }
}
