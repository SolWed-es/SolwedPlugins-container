<?php
/**
 * @author Carlos García Gómez <carlos@facturascripts.com>
 * @copyright 2020-2025, Carlos García Gómez. All Rights Reserved.
 */

namespace FacturaScripts\Plugins\Shopeame\Model;

use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Model\Base;
use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Lib\Shopeame\DeployOrder;
use FacturaScripts\Dinamic\Model\FacturaCliente;
use FacturaScripts\Dinamic\Model\PedidoCliente;

/**
 * Description of ShopeameOrder
 *
 * @author Carlos García Gómez <carlos@facturascripts.com>
 */
class ShopeameOrder extends ModelClass
{
    use ModelTrait;

    const STATUS_CANCELLED = 'cancelled';
    const STATUS_INVOICED = 'invoiced';
    const STATUS_PENDING = 'pending';
    const STATUS_REFUNDED = 'refunded';

    /** @var string */
    public $address;

    /** @var string */
    public $cifnif;

    /** @var string */
    public $city;

    /** @var string */
    public $codalmacen;

    /** @var string */
    public $codserie;

    /** @var string */
    public $company;

    /** @var string */
    public $country;

    /** @var string */
    public $creationdate;

    /** @var float */
    public $discountaxex;

    /** @var float */
    public $discountaxin;

    /** @var string */
    public $email;

    /** @var string */
    public $firstname;

    /** @var int */
    public $id;

    /** @var int */
    public $idorder;

    /** @var int */
    public $idshop;

    /** @var string */
    public $lastmod;

    /** @var string */
    public $lastname;

    /** @var string */
    public $observations;

    /** @var bool */
    public $paid;

    /** @var string */
    public $paymethod;

    /** @var string */
    public $phone;

    /** @var string */
    public $postcode;

    /** @var string */
    public $reference;

    /** @var float */
    public $shippingpcttax;

    /** @var float */
    public $shippingtaxex;

    /** @var float */
    public $shippingtaxin;

    /** @var string */
    public $state;

    /** @var string */
    public $status;

    /** @var float */
    public $totaltaxex;

    /** @var float */
    public $totaltaxin;

    /** @var float */
    public $total_wrapping;

    /** @var float */
    public $total_wrapping_tax_incl;

    /** @var float */
    public $total_wrapping_tax_excl;

    /** @var bool */
    public $unbalanced;

    public function clear(): void
    {
        parent::clear();
        $this->creationdate = Tools::dateTime();
        $this->discountaxex = 0.0;
        $this->discountaxin = 0.0;
        $this->lastmod = Tools::dateTime();
        $this->paid = false;
        $this->shippingpcttax = 0.0;
        $this->shippingtaxex = 0.0;
        $this->shippingtaxin = 0.0;
        $this->status = self::STATUS_PENDING;
        $this->totaltaxex = 0.0;
        $this->totaltaxin = 0.0;
        $this->total_wrapping = 0.0;
        $this->total_wrapping_tax_incl = 0.0;
        $this->total_wrapping_tax_excl = 0.0;
        $this->unbalanced = false;
    }

    public function getNativeOrder(): PedidoCliente
    {
        $natOrder = new PedidoCliente();
        $where = [
            new DataBaseWhere('idshopeameorder', $this->id),
            new DataBaseWhere('idshopeameorder', null, 'IS NOT')
        ];
        if (false === $natOrder->loadWhere($where)) {
            return $natOrder;
        }

        // si el estado es pendiente, lo cambiamos
        if ($this->status === self::STATUS_PENDING) {
            $this->status = self::STATUS_INVOICED;
            $this->save();
        }

        return $natOrder;
    }

    public function getInvoice(bool $refund = false): FacturaCliente
    {
        $invoice = new FacturaCliente();
        $operator = $refund ? 'IS NOT' : 'IS';
        $where = [
            new DataBaseWhere('idshopeameorder', $this->id),
            new DataBaseWhere('idshopeameorder', null, 'IS NOT'),
            new DataBaseWhere('idfacturarect', null, $operator)
        ];
        if (false === $invoice->loadWhere($where)) {
            return $invoice;
        }

        // si el estado es pendiente, lo cambiamos
        if ($this->status === self::STATUS_PENDING) {
            $this->status = self::STATUS_INVOICED;
            $this->save();
        }

        return $invoice;
    }

    /**
     * @return ShopeameOrderLine[]
     */
    public function getLines(): array
    {
        $where = [new DataBaseWhere('idorder', $this->id)];
        return ShopeameOrderLine::all($where, ['id' => 'ASC'], 0, 0);
    }

    public function getShop(): Shopeame
    {
        $shop = new Shopeame();
        $shop->load($this->idshop);
        return $shop;
    }

    public function install(): string
    {
        // dependencias
        new Shopeame();

        return parent::install();
    }

    public static function primaryColumn(): string
    {
        return 'id';
    }

    public static function tableName(): string
    {
        return 'shopeame_orders';
    }

    public function test(): bool
    {
        $stringFields = [
            'address', 'cifnif', 'city', 'company', 'country', 'email', 'firstname', 'lastname',
            'observations', 'paymethod', 'phone', 'postcode', 'reference', 'state'
        ];
        foreach ($stringFields as $field) {
            $this->{$field} = Tools::noHtml($this->{$field});
        }

        if (mb_strlen($this->address) > 100) {
            $this->address = mb_substr($this->address, 0, 90);
        }

        return parent::test();
    }

    private function deployOrder(): bool
    {
        switch ($this->status) {
            case self::STATUS_INVOICED:
                return DeployOrder::invoice($this);

            case self::STATUS_CANCELLED:
            case self::STATUS_REFUNDED:
                return DeployOrder::invoice($this) && DeployOrder::refund($this);
        }

        return true;
    }

    protected function saveUpdate(array $values = []): bool
    {
        return isset($this->deploy) && $this->deploy ?
            $this->deployOrder() :
            parent::saveUpdate($values);
    }
}
