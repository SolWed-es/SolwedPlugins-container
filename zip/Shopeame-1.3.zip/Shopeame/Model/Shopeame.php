<?php
/**
 * @author Carlos García Gómez <carlos@facturascripts.com>
 * @copyright 2020-2024, Carlos García Gómez. All Rights Reserved.
 */

namespace FacturaScripts\Plugins\Shopeame\Model;

use FacturaScripts\Core\Model\Base;
use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Core\Tools;

/**
 * Description of Shopeame
 *
 * @author Carlos García Gómez <carlos@facturascripts.com>
 */
class Shopeame extends ModelClass
{
    use ModelTrait;

    /** @var int */
    public $idshop;

    /** @var string */
    public $shopurl;

    /** @var string */
    public $title;

    public static function primaryColumn(): string
    {
        return 'idshop';
    }

    public static function tableName(): string
    {
        return 'shopeame_shops';
    }

    public function test(): bool
    {
        // escapamos el html
        $this->shopurl = Tools::noHtml($this->shopurl);
        $this->title = Tools::noHtml($this->title);

        return parent::test();
    }
}
