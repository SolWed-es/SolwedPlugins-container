<?php
/**
 * @author Carlos García Gómez <carlos@facturascripts.com>
 * @copyright 2022, Carlos García Gómez. All Rights Reserved.
 */

namespace FacturaScripts\Plugins\Shopeame\Extension\Controller;

use Closure;

class EditFacturaCliente
{
    protected function createViews(): Closure
    {
        return function () {
            $viewName = 'EditShopeameOrder';
            $this->addHtmlView($viewName, 'Tab/' . $viewName, 'ShopeameOrder', 'shop', 'fa-solid fa-store');
        };
    }

    protected function loadData(): Closure
    {
        return function ($viewName, $view) {
            if ('EditShopeameOrder' != $viewName) {
                return;
            }

            $mvn = $this->getMainViewName();
            if (empty($this->getViewModelValue($mvn, 'idshopeameorder'))) {
                $this->setSettings($viewName, 'active', false);
                return;
            }

            $view->model->loadFromCode($this->getViewModelValue($mvn, 'idshopeameorder'));
        };
    }
}
