<?php
/**
 * @author Carlos García Gómez <carlos@facturascripts.com>
 * @copyright 2020-2025, Carlos García Gómez. All Rights Reserved.
 */

namespace FacturaScripts\Plugins\Shopeame\Lib\Shopeame;

use FacturaScripts\Core\Lib\Calculator;
use FacturaScripts\Core\Base\DataBase;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\DataSrc\Impuestos;
use FacturaScripts\Core\Model\Base\ModelCore;
use FacturaScripts\Core\Model\Base\SalesDocument;
use FacturaScripts\Core\Model\Base\SalesDocumentLine;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\Cliente;
use FacturaScripts\Dinamic\Model\FacturaCliente;
use FacturaScripts\Dinamic\Model\FormaPago;
use FacturaScripts\Dinamic\Model\Pais;
use FacturaScripts\Dinamic\Model\PedidoCliente;
use FacturaScripts\Plugins\Shopeame\Model\ShopeameOrder;

/**
 * Description of DeployOrder
 *
 * @author Carlos García Gómez <carlos@facturascripts.com>
 */
class DeployOrder
{
    public static function invoice(ShopeameOrder $order, ?string $nick = null): bool
    {
        $natOrder = $order->getNativeOrder();
        if ($natOrder->exists()) {
            return true;
        }

        $invoice = $order->getInvoice();
        if ($invoice->exists()) {
            return true;
        }

        $db = new DataBase();
        $db->beginTransaction();

        $customer = static::getCustomer($order);
        $invoice->setSubject($customer);
        $invoice->cifnif = $order->cifnif;
        $invoice->ciudad = $order->city;
        $invoice->codalmacen = $order->codalmacen;
        $invoice->codpago = static::getPayment($order->paymethod)->codpago;
        $invoice->codpais = static::getCountry($order->country)->codpais;
        $invoice->codpostal = $order->postcode;
        $invoice->codserie = $order->codserie;
        $invoice->direccion = $order->address;
        $invoice->nick = $nick;
        $invoice->nombrecliente = static::getBusinessName($order);
        $invoice->numero2 = $order->reference;
        $invoice->observaciones = $order->observations;
        $invoice->provincia = $order->state;

        // enlazamos con el pedido original, a través de la extensión
        $invoice->idshopeameorder = $order->id;

        if (false === $invoice->save()) {
            $db->rollback();
            return false;
        }
        if (false === static::invoiceLines($order, $invoice)) {
            $db->rollback();
            return false;
        }

        if ($order->paid || $order->state == ShopeameOrder::STATUS_REFUNDED) {
            foreach ($invoice->getReceipts() as $receipt) {
                $receipt->pagado = true;
                if (false === $receipt->save()) {
                    return false;
                }
            }
        }

        // cambiamos el estado de la factura si su estado actual es editable
        $status = $invoice->getStatus();
        if ($status->editable) {
            foreach ($invoice->getAvailableStatus() as $stat) {
                if (false === $stat->editable) {
                    $invoice->idestado = $stat->idestado;
                    break;
                }
            }
        }
        if (false === $invoice->save()) {
            $db->rollback();
            return false;
        }

        $db->commit();
        return true;
    }

    public static function nativeOrder(ShopeameOrder $order, ?string $nick = null): bool
    {
        $invoice = $order->getInvoice();
        if ($invoice->exists()) {
            return true;
        }

        $natOrder = $order->getNativeOrder();
        if ($natOrder->exists()) {
            return true;
        }

        $db = new DataBase();
        $db->beginTransaction();

        $customer = static::getCustomer($order);
        $natOrder->setSubject($customer);
        $natOrder->cifnif = $order->cifnif;
        $natOrder->ciudad = $order->city;
        $natOrder->codalmacen = $order->codalmacen;
        $natOrder->codpago = static::getPayment($order->paymethod)->codpago;
        $natOrder->codpais = static::getCountry($order->country)->codpais;
        $natOrder->codpostal = $order->postcode;
        $natOrder->codserie = $order->codserie;
        $natOrder->direccion = $order->address;
        $natOrder->nick = $nick;
        $natOrder->nombrecliente = static::getBusinessName($order);
        $natOrder->numero2 = $order->reference;
        $natOrder->observaciones = $order->observations;
        $natOrder->provincia = $order->state;

        // enlazamos con el pedido original, a través de la extensión
        $natOrder->idshopeameorder = $order->id;

        if (false === $natOrder->save()) {
            $db->rollback();
            return false;
        }
        if (false === static::nativeOrderLines($order, $natOrder)) {
            $db->rollback();
            return false;
        }

        $db->commit();
        return true;
    }

    public static function refund(ShopeameOrder $order): bool
    {
        // obtenemos la factura original
        $invoice = $order->getInvoice();
        if (false === $invoice->exists()) {
            return false;
        }

        // comprobamos la factura rectificativa
        $invoiceRefund = $order->getInvoice(true);
        if ($invoiceRefund->exists()) {
            return true;
        }

        $db = new DataBase();
        $db->beginTransaction();

        if ($invoice->editable) {
            foreach ($invoice->getAvailableStatus() as $status) {
                if ($status->editable || !$status->activo) {
                    continue;
                }

                $invoice->idestado = $status->idestado;
                if (false === $invoice->save()) {
                    $db->rollback();
                    return false;
                }
            }
        }

        $invoiceRefund->loadFromData($invoice->toArray(), $invoice::dontCopyFields());
        $invoiceRefund->codigorect = $invoice->codigo;
        $invoiceRefund->codserie = Tools::settings('default', 'codserierec');
        $invoiceRefund->idfacturarect = $invoice->idfactura;
        $invoiceRefund->setDate(Tools::date(), Tools::hour());

        // enlazamos con el pedido original, a través de la extensión
        $invoiceRefund->idshopeameorder = $order->id;

        if (false === $invoiceRefund->save()) {
            $db->rollback();
            return false;
        }

        foreach ($invoice->getLines() as $line) {
            $newLine = $invoiceRefund->getNewLine($line->toArray());
            $newLine->idlinearect = $line->idlinea;
            if (false === $newLine->save()) {
                $db->rollback();
                return false;
            }
        }

        $newLines = $invoiceRefund->getLines();
        $invoiceRefund->idestado = $invoice->idestado;
        if (false === Calculator::calculate($invoiceRefund, $newLines, true)) {
            $db->rollback();
            return false;
        }

        // si la factura estaba pagada, marcamos los recibos de la nueva como pagados
        if ($invoice->pagada) {
            foreach ($invoiceRefund->getReceipts() as $receipt) {
                $receipt->pagado = true;
                $receipt->save();
            }
        }

        $db->commit();
        return true;
    }

    protected static function calculateTax(SalesDocumentLine &$line, float $totalTaxEx, float $totalTaxIn): void
    {
        // si el precio sin IVA es igual al precio con IVA, no hay IVA
        if (abs($totalTaxEx - $totalTaxIn) < 0.01) {
            $line->codimpuesto = null;
            $line->iva = 0.0;
            return;
        }

        // si el precio con IVA es cero, no hay IVA
        if (empty($totalTaxIn)) {
            $line->codimpuesto = null;
            $line->iva = 0.0;
            return;
        }

        // calculamos el porcentaje de IVA
        $subtotalTax = $totalTaxIn - $totalTaxEx;
        $pctTax = round(($subtotalTax / $totalTaxEx) * 100, 2);
        static::setTax($line, $pctTax);
    }

    protected static function disableUpdateStock(SalesDocumentLine &$line, SalesDocument $doc): void
    {
        // actualización de stock activada por defecto
        $line->disableUpdateStock(false);

        // no hay producto
        if (empty($line->referencia)) {
            return;
        }

        // no se encuentra el producto
        $product = $line->getProducto();
        if (empty($product->id())) {
            return;
        }

        // desactivamos solamente si el documento es anterior a la fecha de creación del producto
        if (strtotime($doc->fecha) < strtotime($product->fechaalta)) {
            $line->disableUpdateStock(true);
        }
    }

    protected static function getBusinessName($order): string
    {
        if (false === empty($order->company)) {
            return $order->company;
        } elseif (empty($order->lastname)) {
            return $order->firstname;
        }

        return $order->firstname . ' ' . $order->lastname;
    }

    protected static function getCountry(string $iso): Pais
    {
        $country = new Pais();
        $country->loadWhere([new DataBaseWhere('codiso', $iso)]);
        return $country;
    }

    protected static function getCustomer(ShopeameOrder $order): Cliente
    {
        $customer = new Cliente();
        $where = [new DataBaseWhere('email', strtolower($order->email))];
        if ($customer->loadWhere($where)) {
            return $customer;
        }

        // no hemos encontrado al cliente, así que lo creamos
        $customer->cifnif = $order->cifnif;
        $customer->email = $order->email;
        $customer->nombre = empty($order->lastname) ? $order->firstname : $order->firstname . ' ' . $order->lastname;
        $customer->personafisica = empty($order->company);
        $customer->razonsocial = empty($order->company) ? $customer->nombre : $order->company;
        $customer->telefono1 = $order->phone;

        // el nombre está vacío
        if (empty($customer->nombre)) {
            $customer->nombre = '-';
        }

        if ($customer->save()) {
            // guardamos la dirección
            foreach ($customer->getAddresses() as $address) {
                $address->apellidos = $order->lastname;
                $address->ciudad = $order->city;
                $address->codpais = static::getCountry($order->country)->codpais;
                $address->codpostal = $order->postcode;
                $address->direccion = $order->address;
                $address->nombre = $order->firstname;
                $address->provincia = $order->state;
                $address->telefono1 = $order->phone;
                $address->save();
                break;
            }
        }

        return $customer;
    }

    protected static function getPayment($payment): FormaPago
    {
        $paymentMethod = new FormaPago();
        if ($paymentMethod->load($payment)) {
            return $paymentMethod;
        }

        $paymentMethod->load(Tools::settings('default', 'codpago'));
        return $paymentMethod;
    }

    protected static function invoiceLines(ShopeameOrder $order, FacturaCliente $invoice): bool
    {
        foreach ($order->getLines() as $line) {
            $newLine = empty($line->reference) ? $invoice->getNewLine() : $invoice->getNewProductLine($line->reference);
            $newLine->cantidad = $line->quantity;
            $newLine->descripcion = $line->description;
            $newLine->pvpunitario = $line->price;
            static::setTax($newLine, $line->pcttax);

            // decide si hay que actualizar el stock o no
            static::disableUpdateStock($newLine, $invoice);

            if (false === $newLine->save()) {
                return false;
            }
        }

        if ($order->shippingtaxex > 0) {
            $shippingLine = $invoice->getNewLine();
            $shippingLine->cantidad = 1;
            $shippingLine->descripcion = Tools::lang()->trans('shipping-costs');
            $shippingLine->pvpunitario = $order->shippingtaxex;
            static::setTax($shippingLine, $order->shippingpcttax);
            if (false === $shippingLine->save()) {
                return false;
            }
        }

        if ($order->discountaxex > 0) {
            $discountLine = $invoice->getNewLine();
            $discountLine->cantidad = 1;
            $discountLine->descripcion = Tools::lang()->trans('discount');
            $discountLine->pvpunitario = 0 - $order->discountaxex;
            static::calculateTax($discountLine, $order->discountaxex, $order->discountaxin);
            if (false === $discountLine->save()) {
                return false;
            }
        }

        if ($order->total_wrapping_tax_excl > 0) {
            $wrappingLine = $invoice->getNewLine();
            $wrappingLine->cantidad = 1;
            $wrappingLine->descripcion = Tools::lang()->trans('packaging');
            $wrappingLine->pvpunitario = 0 - $order->total_wrapping_tax_excl;
            static::calculateTax($wrappingLine, $order->total_wrapping_tax_excl, $order->total_wrapping_tax_incl);
            if (false === $wrappingLine->save()) {
                return false;
            }
        }

        $lines = $invoice->getLines();
        return Calculator::calculate($invoice, $lines, true);
    }

    protected static function nativeOrderLines(ShopeameOrder $order, PedidoCliente $natOrder): bool
    {
        foreach ($order->getLines() as $line) {
            $newLine = empty($line->reference) ? $natOrder->getNewLine() : $natOrder->getNewProductLine($line->reference);
            $newLine->cantidad = $line->quantity;
            $newLine->descripcion = $line->description;
            $newLine->pvpunitario = $line->price;
            static::setTax($newLine, $line->pcttax);

            // decide si hay que actualizar el stock o no
            static::disableUpdateStock($newLine, $natOrder);

            if (false === $newLine->save()) {
                return false;
            }
        }

        if ($order->shippingtaxex > 0) {
            $shippingLine = $natOrder->getNewLine();
            $shippingLine->cantidad = 1;
            $shippingLine->descripcion = Tools::lang()->trans('shipping-costs');
            $shippingLine->pvpunitario = $order->shippingtaxex;
            static::setTax($shippingLine, $order->shippingpcttax);
            if (false === $shippingLine->save()) {
                return false;
            }
        }

        if ($order->discountaxex > 0) {
            $discountLine = $natOrder->getNewLine();
            $discountLine->cantidad = 1;
            $discountLine->descripcion = Tools::lang()->trans('discount');
            $discountLine->pvpunitario = 0 - $order->discountaxex;
            static::calculateTax($discountLine, $order->discountaxex, $order->discountaxin);
            if (false === $discountLine->save()) {
                return false;
            }
        }

        if ($order->total_wrapping_tax_excl > 0) {
            $wrappingLine = $natOrder->getNewLine();
            $wrappingLine->cantidad = 1;
            $wrappingLine->descripcion = Tools::lang()->trans('packaging');
            $wrappingLine->pvpunitario = 0 - $order->total_wrapping_tax_excl;
            static::calculateTax($wrappingLine, $order->total_wrapping_tax_excl, $order->total_wrapping_tax_incl);
            if (false === $wrappingLine->save()) {
                return false;
            }
        }

        $lines = $natOrder->getLines();
        return Calculator::calculate($natOrder, $lines, true);
    }

    protected static function setTax(SalesDocumentLine &$newLine, float $pctTax): void
    {
        // si el impuesto de la línea ya es similar al porcentaje, mejor no tocamos nada
        if (abs($newLine->iva - $pctTax) < 0.01) {
            return;
        }

        // buscamos un impuesto similar
        foreach (Impuestos::all() as $tax) {
            if ($tax->iva === $pctTax) {
                $newLine->codimpuesto = $tax->codimpuesto;
                $newLine->iva = $tax->iva;
                return;
            }
        }
    }
}
