<?php
/**
 * @author Carlos García Gómez <carlos@facturascripts.com>
 * @copyright 2020-2024, Carlos García Gómez. All Rights Reserved.
 */

namespace FacturaScripts\Plugins\Shopeame\Controller;

use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Lib\ExtendedController\BaseView;
use FacturaScripts\Core\Lib\ExtendedController\ListController;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Lib\Shopeame\DeployOrder;
use FacturaScripts\Plugins\Shopeame\Model\Shopeame;
use FacturaScripts\Plugins\Shopeame\Model\ShopeameOrder;

/**
 * Description of ListShopeameOrder
 *
 * @author Carlos García Gómez <carlos@facturascripts.com>
 */
class ListShopeameOrder extends ListController
{
    const SHOP_VIEWNAME_PREFIX = 'ListShopeameOrder-';

    /** @var Shopeame[] */
    private $shops = [];

    public function getPageData(): array
    {
        $data = parent::getPageData();
        $data['menu'] = 'sales';
        $data['title'] = 'shopea.me';
        $data['icon'] = 'fa-solid fa-store';
        return $data;
    }

    protected function createViews()
    {
        $shopModel = new Shopeame();
        $this->shops = $shopModel->all();
        if (empty($this->shops)) {
            $this->setTemplate($this->getClassName());
            return;
        }

        foreach ($this->shops as $shop) {
            $this->createViewsShop(self::SHOP_VIEWNAME_PREFIX . $shop->idshop, $shop);
        }
    }

    private function createViewsShop(string $viewName, Shopeame $shop): void
    {
        $this->addView($viewName, 'ShopeameOrder', $shop->title, 'fa-solid fa-store')
            ->addOrderBy(['creationdate', 'idorder'], 'date', 2)
            ->addOrderBy(['lastmod', 'idorder'], 'last-update')
            ->addOrderBy(['total'], 'total')
            ->addSearchFields(['email', 'firstname', 'idorder', 'lastname', 'observations', 'reference']);

        // filtros
        $this->addFilterPeriod($viewName, 'creationdate', 'date', 'creationdate');
        $this->addFilterSelect($viewName, 'status', 'status', 'status', $this->getAllOrderStatus());

        $payMethods = $this->codeModel->all('shopeame_orders', 'paymethod', 'paymethod',
            true, [new DataBaseWhere('idshop', $shop->idshop)]);
        $this->addFilterSelect($viewName, 'paymethod', 'payment-method', 'paymethod', $payMethods);

        // filtro de pagado o impagado
        $i18n = Tools::lang();
        $this->addFilterSelectWhere($viewName, 'paid', [
            ['label' => $i18n->trans('all'), 'where' => []],
            ['label' => $i18n->trans('paid'), 'where' => [new DataBaseWhere('paid', true)]],
            ['label' => $i18n->trans('unpaid'), 'where' => [new DataBaseWhere('paid', false)]]
        ]);

        $this->addFilterNumber($viewName, 'shipping-min', 'shipping-costs', 'shippingtaxex', '>=');
        $this->addFilterNumber($viewName, 'discount-min', 'discount', 'discountaxex', '>=');
        $this->addFilterNumber($viewName, 'total-min', 'total', 'total', '>=');
        $this->addFilterNumber($viewName, 'total-max', 'total', 'total', '<=');
        $this->addFilterCheckbox($viewName, 'unbalanced', 'unbalance', 'unbalanced');

        // desactivamos los botones nuevo y eliminar
        $this->setSettings($viewName, 'btnDelete', false);
        $this->setSettings($viewName, 'btnNew', false);

        // añadimos un botón
        $this->addButton($viewName, [
            'action' => 'invoice-order',
            'color' => 'warning',
            'icon' => 'fa-solid fa-file-invoice-dollar ',
            'label' => 'invoice-order',
            'type' => 'action'
        ]);
    }

    protected function execPreviousAction($action)
    {
        if ($action === 'invoice-order') {
            return $this->invoiceOrderAction();
        }

        return parent::execPreviousAction($action);
    }

    private function getAllOrderStatus(): array
    {
        $status = $this->codeModel->all('shopeame_orders', 'status', 'status');
        foreach ($status as $key => $value) {
            if ($value->code) {
                $status[$key]->description = Tools::lang()->trans($value->description);
            }
        }

        return $status;
    }

    protected function invoiceOrderAction(): bool
    {
        $codes = $this->request->request->getArray('codes');
        if (empty($codes)) {
            Tools::log()->warning('no-selected-item');
            return true;
        }

        foreach ($codes as $code) {
            // obtenemos el pedido
            $orderModel = new ShopeameOrder();
            if (false === $orderModel->load($code) || $orderModel->getInvoice()->exists()) {
                continue;
            }

            if (false === DeployOrder::invoice($orderModel, $this->user->nick)) {
                Tools::log()->warning('error-creating-invoice-for-order', [
                    '%reference%' => $orderModel->reference
                ]);
                return false;
            }

            // force order status check
            $orderModel->save();
        }

        Tools::log()->notice('record-updated-correctly');
        return true;
    }

    /**
     * @param string $viewName
     * @param BaseView $view
     */
    protected function loadData($viewName, $view)
    {
        foreach ($this->shops as $shop) {
            if ($viewName === self::SHOP_VIEWNAME_PREFIX . $shop->idshop) {
                $where = [new DataBaseWhere('idshop', $shop->idshop)];
                $view->loadData('', $where);
            }
        }
    }
}
