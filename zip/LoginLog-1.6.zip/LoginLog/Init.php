<?php
namespace FacturaScripts\Plugins\LoginLog;

use FacturaScripts\Core\Template\InitClass;

class Init extends InitClass
{
    public function init(): void
    {
        // Se ejecuta en cada carga si el plugin está activo.
    }

    public function update(): void
    {
        // Se ejecuta al instalar o actualizar el plugin.
    }

    public function uninstall(): void
    {
        // Se ejecuta al desinstalar el plugin.
        // Déjalo vacío si no hay nada que limpiar.
    }
}
