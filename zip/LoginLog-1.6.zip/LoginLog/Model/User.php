<?php
namespace FacturaScripts\Plugins\LoginLog\Model;

use FacturaScripts\Core\Model\User as UserCoreModel;
use FacturaScripts\Dinamic\Model\LogMessage;

class User extends UserCoreModel
{
    public function updateActivity(string $ipAddress, string $browser = ''): void
    {
        // Fecha/hora actual en formato MySQL
        $this->lastactivity = date('Y-m-d H:i:s');
        $this->lastip = $ipAddress;
        $this->lastbrowser = $browser;

        // Guardamos el log
        $log = new LogMessage();
        $log->channel = 'audit';
        $log->level = 'info';
        $log->message = 'Login successful';
        $log->nick = $this->nick;
        $log->uri = '/';
        $log->model = 'Login';
        $log->ip = $this->lastip;
        $log->save();
    }
}
