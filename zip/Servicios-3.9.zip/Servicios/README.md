# Servicios
Plugin para gestionar servicios en FacturaScripts.
- https://facturascripts.com/plugins/servicios

## Issues / Feedback
https://facturascripts.com/contacto

## Carpeta
La carpeta debe llamarse igual que el plugin: **Servicios**.

## Enlaces de interés
- [Programa para hacer facturas gratis](https://facturascripts.com/programa-para-hacer-facturas)
- [Cómo instalar FacturaScripts en Windows](https://facturascripts.com/instalar-windows)
- [Cómo instalar plugins en FacturaScripts](https://facturascripts.com/publicaciones/como-instalar-un-plugin-en-facturascripts)
- [Programa para imprimir tickets gratis](https://facturascripts.com/remote-printer)
- [Curso de FacturaScripts](https://youtube.com/playlist?list=PLNxcJ5CWZ8V6nfeVu6vieKI_d8a_ObLfY)
