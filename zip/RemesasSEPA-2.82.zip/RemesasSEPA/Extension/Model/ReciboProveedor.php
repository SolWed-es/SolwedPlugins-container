<?php
/**
 * Copyright (C) 2021-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\RemesasSEPA\Extension\Model;

use Closure;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Model\CuentaBancoProveedor;
use FacturaScripts\Dinamic\Model\RemesaSEPAprov;

/**
 * @author Carlos Garcia Gomez <carlos@facturascripts.com>
 */
class ReciboProveedor
{
    /**
     * Prevents remove receipts inside a remittance.
     */
    public function deleteBefore(): Closure
    {
        return function () {
            if (!empty($this->idremesa)) {
                Tools::log()->warning('receipt-inside-remittance');
                return false;
            }

            return true;
        };
    }

    /**
     * Returns the supplier bank account.
     */
    public function getBankAccount(): Closure
    {
        return function () {
            $bankAccount = new CuentaBancoProveedor();
            $where = [Where::column('codproveedor', $this->codproveedor)];
            foreach ($bankAccount->all($where) as $cuenta) {
                if ($cuenta->iban == $this->iban) {
                    return $cuenta;
                }

                if ($cuenta->principal) {
                    $bankAccount->load($cuenta->id());
                }
            }

            return $bankAccount;
        };
    }

    public function getRemittance(): Closure
    {
        return function () {
            $model = new RemesaSEPAprov();
            $model->load($this->idremesa);
            return $model;
        };
    }

    public function onChange(): Closure
    {
        return function ($field) {
            if ($field !== 'pagado' || empty($this->idremesa)) {
                return;
            }

            // obtenemos la remesa
            $remittance = $this->getRemittance();
            if (false === $remittance->exists()) {
                return;
            }

            // si la remesa no está pagada y el recibo se marca como pagado, terminamos
            if ($remittance->estado !== RemesaSEPAprov::STATUS_DONE
                && $this->pagado) {
                Tools::log()->warning('cannot-be-marked-as-paid-because-the-remittance-has-not-been-paid');
                return false;
            } elseif ($remittance->estado === RemesaSEPAprov::STATUS_DONE
                && false === $this->pagado) {
                // si la remesa está pagada y el recibo se marca como no pagado, terminamos
                Tools::log()->warning('could-not-uncheck-as-paid-because-the-remittance-is-paid');
                return false;
            }
        };
    }

    /**
     * Sets IBAN and swift before insert.
     */
    public function saveInsertBefore(): Closure
    {
        return function () {
            if (empty($this->iban) && !$this->pagado) {
                $paymentMethod = $this->getPaymentMethod();
                if ($paymentMethod->codcuentabanco || $paymentMethod->domiciliado) {
                    $this->updateBankAccount();
                }
            }

            return true;
        };
    }

    /**
     * Updated IBAN and swift values.
     */
    public function updateBankAccount(): Closure
    {
        return function () {
            $bankAccount = $this->getBankAccount();
            $this->iban = $bankAccount->exists() ? $bankAccount->iban : null;
            $this->swift = $bankAccount->exists() ? $bankAccount->swift : null;
        };
    }
}
