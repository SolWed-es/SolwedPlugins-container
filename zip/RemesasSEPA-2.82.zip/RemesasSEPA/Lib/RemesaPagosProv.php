<?php
/**
 * Copyright (C) 2019-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\RemesasSEPA\Lib;

use FacturaScripts\Dinamic\Model\ReciboProveedor;
use FacturaScripts\Plugins\RemesasSEPA\Model\RemesaSEPAprov;

/**
 * @author Carlos Garcia Gomez <carlos@facturascripts.com>
 */
class RemesaPagosProv
{
    public static function getXML(RemesaSEPAprov $remesa): string
    {
        $creDtTm = date('Y-m-d\TH:i:s');
        $msgId = md5($remesa->id() . $creDtTm);
        $recibos = $remesa->getReceipts();
        $empresa = $remesa->getCompany();
        $banco = $remesa->getBankAccount();

        $xml = '<?xml version="1.0" encoding="UTF-8"?>
<Document xmlns="urn:iso:std:iso:20022:tech:xsd:pain.001.001.03" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"'
            . ' xsi:schemaLocation="urn:iso:std:iso:20022:tech:xsd:pain.001.001.03 pain.001.001.03.xsd">
  <CstmrCdtTrfInitn>
    <GrpHdr>
      <MsgId>' . $msgId . '</MsgId>
      <CreDtTm>' . $creDtTm . '</CreDtTm>
      <NbOfTxs>' . count($recibos) . '</NbOfTxs>
      <CtrlSum>' . number_format($remesa->total, 2, '.', '') . '</CtrlSum>
      <InitgPty>
        <Nm>' . self::sanitizeName($empresa->nombre) . '</Nm>
        <Id><OrgId><Othr><Id>' . $remesa->creditorid . '</Id></Othr></OrgId></Id>
      </InitgPty>
    </GrpHdr>
    <PmtInf>
      <PmtInfId>' . $msgId . '/1</PmtInfId>
      <PmtMtd>TRF</PmtMtd>
      <BtchBookg>false</BtchBookg>
      <NbOfTxs>' . count($recibos) . '</NbOfTxs>
      <CtrlSum>' . number_format($remesa->total, 2, '.', '') . '</CtrlSum>
      <PmtTpInf><SvcLvl><Cd>SEPA</Cd></SvcLvl></PmtTpInf>
      <ReqdExctnDt>' . date('Y-m-d', strtotime($remesa->fechacargo)) . '</ReqdExctnDt>
      <Dbtr><Nm>' . self::sanitizeName($empresa->nombre) . '</Nm></Dbtr>
      <DbtrAcct><Id><IBAN>' . $banco->getIban() . "</IBAN></Id></DbtrAcct>\n";

        if ($banco->swift) {
            $xml .= '<DbtrAgt><FinInstnId><BIC>' . $banco->swift . "</BIC></FinInstnId></DbtrAgt>\n";
        }

        $xml .= "<ChrgBr>SLEV</ChrgBr>\n"
            . self::getTransactionsXML($remesa, $recibos)
            . "</PmtInf>\n</CstmrCdtTrfInitn>\n</Document>";
        return $xml;
    }

    /**
     * @param RemesaSEPAprov $remesa
     * @param ReciboProveedor[] $recibos
     *
     * @return string
     */
    protected static function getTransactionsXML(RemesaSEPAprov $remesa, array $recibos): string
    {
        $xml = '';
        foreach ($recibos as $recibo) {
            $factura = $recibo->getInvoice();
            $numfactura = empty($factura->numproveedor) ? $factura->codigo : $factura->numproveedor;

            $xml .= '<CdtTrfTxInf>'
                . '<PmtId><EndToEndId>' . $numfactura . "</EndToEndId></PmtId>\n"
                . '<Amt><InstdAmt Ccy="EUR">' . number_format($recibo->importe, 2, '.', '') . "</InstdAmt></Amt>\n";

            if ($recibo->swift) {
                $xml .= '<CdtrAgt><FinInstnId><BIC>' . $recibo->swift . "</BIC></FinInstnId></CdtrAgt>\n";
            }

            $xml .= '<Cdtr><Nm>' . self::sanitizeName($recibo->getSubject()->razonsocial) . "</Nm></Cdtr>\n"
                . '<CdtrAcct><Id><IBAN>' . $recibo->iban . "</IBAN></Id></CdtrAcct>\n"
                . '<RmtInf><Ustrd>' . $numfactura . "</Ustrd></RmtInf>\n"
                . "</CdtTrfTxInf>\n";
        }

        return $xml;
    }

    protected static function sanitizeName(string $name): string
    {
        $changes = ['à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a',
            'å' => 'a', 'æ' => 'ae', 'ç' => 'c', 'è' => 'e', 'é' => 'e', 'ê' => 'e',
            'ë' => 'e', 'ì' => 'i', 'í' => 'i', 'î' => 'i', 'ï' => 'i', 'ð' => 'd',
            'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o', 'ö' => 'o',
            'ő' => 'o', 'ø' => 'o', 'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ü' => 'u',
            'ű' => 'u', 'ý' => 'y', 'þ' => 'th', 'ÿ' => 'y', 'Ç' => 'C',
            '&' => '&amp;', 'À' => 'A', 'Á' => 'A', 'È' => 'E', 'É' => 'E', 'Ì' => 'I',
            'Í' => 'I', 'Ò' => 'O', 'Ó' => 'O', 'Ù' => 'U', 'Ú' => 'U', 'Ü' => 'U',
        ];

        $newName = str_replace(array_keys($changes), $changes, $name);
        return substr($newName, 0, 70);
    }
}
