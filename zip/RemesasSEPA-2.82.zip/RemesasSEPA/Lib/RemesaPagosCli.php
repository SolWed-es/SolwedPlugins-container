<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\RemesasSEPA\Lib;

use DateTime;
use Digitick\Sepa\Exception\InvalidArgumentException;
use Digitick\Sepa\GroupHeader;
use Digitick\Sepa\PaymentInformation;
use Digitick\Sepa\TransferFile\Facade\CustomerDirectDebitFacade;
use Digitick\Sepa\TransferFile\Factory\TransferFileFacadeFactory;
use Exception;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Lib\Accounting\CalculateSwift;
use FacturaScripts\Plugins\RemesasSEPA\Model\RemesaSEPA;

/**
 * @author Carlos Garcia Gomez <carlos@facturascripts.com>
 */
class RemesaPagosCli
{
    public static function getXML(RemesaSEPA $remesa): string
    {
        try {
            $header = new GroupHeader(date('Y-m-d-H-i-s'), static::sanitizeName($remesa->getNombre()));
            $header->setInitiatingPartyId($remesa->creditorid);
            $directDebit = TransferFileFacadeFactory::createDirectDebitWithGroupHeader($header, 'pain.008.001.02');

            // obtener la opción de cargo
            $chargeOption = empty($remesa->charge_option) || !in_array($remesa->charge_option, [RemesaSEPA::CHARGE_OPTION_REMITTANCE, RemesaSEPA::CHARGE_OPTION_RECEIPT])
                ? RemesaSEPA::CHARGE_OPTION_REMITTANCE
                : $remesa->charge_option;

            // Usamos la fecha de vencimiento de cada recibo
            if ($chargeOption === 'receipt') {
                // Agrupamos por fecha de vencimiento de los recibos
                $groupedByDueDate = static::getReceiptsByDueDate($remesa);
                foreach ($groupedByDueDate as $dueDate => $receiptGroup) {
                    // Añadimos el pago para esta fecha de vencimiento
                    $payInfoId = static::getPaymentInfoId($remesa) . '-' . str_replace('-', '', $dueDate);
                    $paymentInfo = static::createPaymentInfo($remesa, $payInfoId, $dueDate);
                    $directDebit->addPaymentInfo($payInfoId, $paymentInfo);

                    // Añadimos los cobros para esta fecha
                    static::setTransfer($receiptGroup, $directDebit, $payInfoId);
                }
            } else {
                // Una sola fecha de cargo (la de la remesa)
                $payInfoId = static::getPaymentInfoId($remesa);
                $fechaCargo = date('Y-m-d', strtotime($remesa->fechacargo));
                $paymentInfo = static::createPaymentInfo($remesa, $payInfoId, $fechaCargo);
                $directDebit->addPaymentInfo($payInfoId, $paymentInfo);

                // añadimos los cobros de los recibos
                $groupedReceipts = static::getGroupedReceipts($remesa);
                static::setTransfer($groupedReceipts, $directDebit, $payInfoId);
            }

            return $directDebit->asXML();
        } catch (Exception $e) {
            Tools::log()->error('Error generating SEPA payment remittance XML: ' . $e->getMessage());
            return '';
        }
    }

    protected static function createPaymentInfo(RemesaSEPA $remesa, string $payInfoId, string $fechaCargo): array
    {
        $bankAccount = $remesa->getBankAccount();
        $paymentInfo = [
            'id' => $payInfoId,
            'dueDate' => new DateTime($fechaCargo),
            'creditorName' => static::sanitizeName($remesa->getNombre()),
            'creditorAccountIBAN' => $bankAccount->getIban(),
            'creditorAgentBIC' => CalculateSwift::getSwift($bankAccount->getIban(), $bankAccount->swift),
            'seqType' => PaymentInformation::S_RECURRING,
            'creditorId' => $remesa->creditorid,
            'localInstrumentCode' => $remesa->tipo
        ];
        if (empty($paymentInfo['creditorAgentBIC'])) {
            unset($paymentInfo['creditorAgentBIC']);
        }

        return $paymentInfo;
    }

    protected static function getGroupedReceipts(RemesaSEPA $remittance): array
    {
        $items = [];
        foreach ($remittance->getReceipts() as $receipt) {
            $bankAccount = $receipt->getBankAccount();
            $fmandato = date('Y-m-d', strtotime($bankAccount->fmandato));
            $invoice = $receipt->getInvoice();

            // convertimos el importe en euros a centimos, ya que la librería lo requiere así
            $cents = round($receipt->importe * 100);

            if (!$remittance->agrupar) {
                $items[] = [
                    'amount' => $cents,
                    'debtorIban' => $receipt->iban,
                    'debtorBic' => $receipt->swift,
                    'debtorName' => static::sanitizeName($receipt->getSubject()->razonsocial),
                    'debtorMandate' => $bankAccount->mandato ?? $bankAccount->id(),
                    'debtorMandateSignDate' => new DateTime($fmandato),
                    'remittanceInformation' => [$invoice->codigo . '-' . $receipt->numero],
                    'endToEndId' => [$invoice->codigo . '-' . $receipt->numero]
                ];
                continue;
            }

            if (!isset($items[$receipt->codcliente])) {
                $items[$receipt->codcliente] = [
                    'amount' => 0,
                    'debtorIban' => $receipt->iban,
                    'debtorBic' => $receipt->swift,
                    'debtorName' => static::sanitizeName($receipt->getSubject()->razonsocial),
                    'debtorMandate' => $bankAccount->mandato ?? $bankAccount->id(),
                    'debtorMandateSignDate' => new DateTime($fmandato),
                    'remittanceInformation' => [],
                    'endToEndId' => []
                ];
            }

            $items[$receipt->codcliente]['amount'] += $cents;
            $items[$receipt->codcliente]['remittanceInformation'][] = $invoice->codigo . '-' . $receipt->numero;
            $items[$receipt->codcliente]['endToEndId'][] = $invoice->codigo . '-' . $receipt->numero;
        }

        return $items;
    }

    protected static function getPaymentInfoId(RemesaSEPA $remesa): string
    {
        // obtenemos el ID de la remesa
        $id = $remesa->id();

        // si tiene menos de 5 caracteres, le concatenamos ceros por delante
        while (strlen($id) < 5) {
            $id = '0' . $id;
        }

        // si es una remesa de financiación, le añadimos el prefijo FSDD
        if ($remesa->fsdd) {
            $id = 'FSDD' . $id;
        }

        return $id;
    }

    /**
     * Agrupa los recibos por fecha de vencimiento
     * @throws Exception
     */
    protected static function getReceiptsByDueDate(RemesaSEPA $remittance): array
    {
        $itemsByDueDate = [];
        $receipts = $remittance->getReceipts();

        foreach ($receipts as $receipt) {
            $dueDate = date('Y-m-d', strtotime($receipt->vencimiento));

            $bankAccount = $receipt->getBankAccount();
            $fmandato = date('Y-m-d', strtotime($bankAccount->fmandato));
            $invoice = $receipt->getInvoice();

            if (!isset($itemsByDueDate[$dueDate])) {
                $itemsByDueDate[$dueDate] = [];
            }

            if (!$remittance->agrupar) {
                // Si no hay que agrupar, cada recibo va por separado
                $itemsByDueDate[$dueDate][] = [
                    'amount' => round($receipt->importe * 100),
                    'debtorIban' => $receipt->iban,
                    'debtorBic' => $receipt->swift,
                    'debtorName' => static::sanitizeName($receipt->getSubject()->razonsocial),
                    'debtorMandate' => $bankAccount->mandato ?? $bankAccount->id(),
                    'debtorMandateSignDate' => new DateTime($fmandato),
                    'remittanceInformation' => [$invoice->codigo . '-' . $receipt->numero],
                    'endToEndId' => [$invoice->codigo . '-' . $receipt->numero]
                ];
            } else {
                // Si hay que agrupar, agrupamos por cliente dentro de cada fecha

                $clientKey = $dueDate . '-' . $receipt->codcliente;
                if (!isset($itemsByDueDate[$dueDate][$clientKey])) {
                    $itemsByDueDate[$dueDate][$clientKey] = [
                        'amount' => 0,
                        'debtorIban' => $receipt->iban,
                        'debtorBic' => $receipt->swift,
                        'debtorName' => static::sanitizeName($receipt->getSubject()->razonsocial),
                        'debtorMandate' => $bankAccount->mandato ?? $bankAccount->id(),
                        'debtorMandateSignDate' => new DateTime($fmandato),
                        'remittanceInformation' => [],
                        'endToEndId' => []
                    ];
                }

                $itemsByDueDate[$dueDate][$clientKey]['amount'] += round($receipt->importe * 100);
                $itemsByDueDate[$dueDate][$clientKey]['remittanceInformation'][] = $invoice->codigo . '-' . $receipt->numero;
                $itemsByDueDate[$dueDate][$clientKey]['endToEndId'][] = $invoice->codigo . '-' . $receipt->numero;
            }
        }

        // Convertir los arrays asociativos a arrays indexados
        foreach ($itemsByDueDate as $dueDate => $items) {
            if ($remittance->agrupar) {
                $itemsByDueDate[$dueDate] = array_values($items);
            }
        }

        return $itemsByDueDate;
    }

    protected static function sanitizeName(string $name): string
    {
        $changes = ['à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a',
            'å' => 'a', 'æ' => 'ae', 'ç' => 'c', 'è' => 'e', 'é' => 'e', 'ê' => 'e',
            'ë' => 'e', 'ì' => 'i', 'í' => 'i', 'î' => 'i', 'ï' => 'i', 'ð' => 'd',
            'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o', 'ö' => 'o',
            'ő' => 'o', 'ø' => 'o', 'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ü' => 'u',
            'ű' => 'u', 'ý' => 'y', 'þ' => 'th', 'ÿ' => 'y', 'Ç' => 'C',
            '&' => '&amp;', 'À' => 'A', 'Á' => 'A', 'È' => 'E', 'É' => 'E', 'Ì' => 'I',
            'Í' => 'I', 'Ò' => 'O', 'Ó' => 'O', 'Ù' => 'U', 'Ú' => 'U', 'Ü' => 'U',
        ];

        $newName = str_replace(array_keys($changes), $changes, $name);
        return substr($newName, 0, 70);
    }

    /**
     * @param array $groupedReceipts
     * @param CustomerDirectDebitFacade $directDebit
     * @param string $payInfoId
     * @return void
     * @throws InvalidArgumentException
     */
    protected static function setTransfer(array $groupedReceipts, CustomerDirectDebitFacade $directDebit, string $payInfoId): void
    {
        foreach ($groupedReceipts as $item) {
            $transfer = [
                'amount' => $item['amount'],
                'debtorIban' => str_replace(' ', '', $item['debtorIban'] ?? ''),
                'debtorBic' => $item['debtorBic'],
                'debtorName' => $item['debtorName'],
                'debtorMandate' => $item['debtorMandate'],
                'debtorMandateSignDate' => $item['debtorMandateSignDate'],
                'remittanceInformation' => Tools::trans('invoice') . ' ' . implode(', ', $item['remittanceInformation']),
                'endToEndId' => end($item['endToEndId'])
            ];
            if (empty($transfer['debtorBic'])) {
                unset($transfer['debtorBic']);
            }
            $directDebit->addTransfer($payInfoId, $transfer);
        }
    }
}
