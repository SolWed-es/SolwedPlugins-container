<?php
/**
 * Copyright (C) 2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\RemesasSEPA\Model;

use FacturaScripts\Core\Session;
use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\FacturaProveedor;
use FacturaScripts\Dinamic\Model\ReciboProveedor;
use FacturaScripts\Dinamic\Model\RemesaSEPAprov;
use FacturaScripts\Dinamic\Model\User;

/**
 * @author Carlos Garcia Gomez <carlos@facturascripts.com>
 */
class RemesaSEPArefundprov extends ModelClass
{
    use ModelTrait;

    /** @var string */
    public $creation_date;

    /** @var int */
    public $id;

    /** @var int */
    public $idrecibo;

    /** @var int */
    public $idremesa;

    /** @var string */
    public $last_nick;

    /** @var string */
    public $last_update;

    /** @var string */
    public $nick;

    public function getRemittance(): RemesaSEPAprov
    {
        $remittance = new RemesaSEPAprov();
        $remittance->load($this->idremesa);
        return $remittance;
    }

    public function getReceipt(): ReciboProveedor
    {
        $receipt = new ReciboProveedor();
        $receipt->load($this->idrecibo);
        return $receipt;
    }

    public function install(): string
    {
        new User();
        new ReciboProveedor();
        new FacturaProveedor();

        return parent::install();
    }

    public static function tableName(): string
    {
        return "remesas_sepa_refunds_prov";
    }

    public function test(): bool
    {
        $this->creation_date = $this->creation_date ?? Tools::dateTime();
        $this->nick = $this->nick ?? Session::user()->nick;

        return parent::test();
    }

    public function url(string $type = 'auto', string $list = 'List'): string
    {
        if ($type === 'auto') {
            return $this->getRemittance()->url();
        }

        return parent::url($type, $list);
    }

    protected function saveUpdate(): bool
    {
        $this->last_nick = Session::user()->nick;
        $this->last_update = Tools::dateTime();

        return parent::saveUpdate();
    }
}
