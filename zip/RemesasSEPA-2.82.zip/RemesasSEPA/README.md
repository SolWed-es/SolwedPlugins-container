# RemesasSEPA
Plugin RemesasSEPA para FacturaScripts: permite hacer remesas bancarias SEPA para cobrar los recibos de facturas de venta.
- https://facturascripts.com/plugins/remesassepa

## No es software libre
Este plugin no es software libre, no se permite su uso libre y/o distribución. Consultar el archivo **LICENSE** para más detalles.

## Instalación
Es necesario descargar las dependencias mediante composer:
```
composer install
```

### Nombre de carpeta
Como con todos los plugins, la carpeta se debe llamar igual que el plugin. En este caso **RemesasSEPA**.