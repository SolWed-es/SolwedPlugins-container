<?php
/**
 * Copyright (C) 2023-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\TPVneo\Mod;

use FacturaScripts\Core\Contract\SalesModInterface;
use FacturaScripts\Core\Model\Base\SalesDocument;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Lib\AssetManager;
use FacturaScripts\Dinamic\Model\TpvCaja;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class SalesHeaderHTMLMod implements SalesModInterface
{
    public function apply(SalesDocument &$model, array $formData): void
    {
        $box = new TpvCaja();
        $box->load($formData['idcaja'] ?? null);

        $model->idcaja = $box->idcaja;
        $model->idtpv = $box->idtpv;

        if (in_array($model->modelClassName(), ['AlbaranCliente', 'FacturaCliente'])) {
            $model->tpv_cambio = floatval($formData['tpv_cambio'] ?? $model->tpv_cambio);
            $model->tpv_efectivo = floatval($formData['tpv_efectivo'] ?? $model->tpv_efectivo);
        }
    }

    public function applyBefore(SalesDocument &$model, array $formData): void
    {
    }

    public function assets(): void
    {
        AssetManager::add('js', FS_ROUTE . '/Dinamic/Assets/JS/AutocompleteTPVneo.js');
    }

    public function newBtnFields(): array
    {
        return [];
    }

    public function newFields(): array
    {
        return [];
    }

    public function newModalFields(): array
    {
        return ['tpv'];
    }

    public function renderField(SalesDocument $model, string $field): ?string
    {
        if ($field === 'tpv') {
            return self::tpv($model);
        }

        return null;
    }

    private static function tpv(SalesDocument $model): string
    {
        // si no es uno de los documentos aceptados,
        // o no el documento no existe, terminamos
        if (false === $model->exists()
            || false === in_array($model->modelClassName(), ['PresupuestoCliente', 'AlbaranCliente', 'FacturaCliente'])) {
            return '';
        }

        $value = '';
        $box = new TpvCaja();
        if ($model->idcaja && $box->load($model->idcaja)) {
            $value = $box->idcaja . ' | ' . $box->fechaini;

            if ($box->fechafin) {
                $value .= ' - ' . $box->fechafin;
            }
        }

        $html = '<div class="col-sm-6">'
            . '<a href="EditTpvCaja?code=' . $model->idcaja . '">'
            . Tools::trans('pos-terminal') . ' - ' . Tools::trans('box')
            . '</a>'
            . '<div class="input-group">';

        if ($model->editable && $model->idcaja) {
            $html .= '<button type="button" id="deleteTPVneoBox" class="btn btn-warning">'
                . '<i class="fa-solid fa-times" aria-hidden="true"></i>'
                . '</button>';
        } else {
            $html .= '<span id="searchTPVneoBox" class="input-group-text">'
                . '<i class="fa-solid fa-search fa-fw"></i>'
                . '</span>';
        }

        $disabled = $model->editable ? '' : 'disabled';
        $html .= '<input type="hidden" name="idcaja" value="' . $model->idcaja . '">'
            . '<input type="text" id="findTPVneoBoxInput" class="form-control" value="' . $value . '" ' . $disabled . '/>'
            . '</div>'
            . '</div>';

        if (in_array($model->modelClassName(), ['AlbaranCliente', 'FacturaCliente'])) {
            $html = '<div class="col-12">'
                . '<div class="row">'
                . $html;

            $html .= '<div class="col-sm-3">'
                . Tools::trans('pos-terminal') . ' - ' . Tools::trans('cash')
                . '<div class="input-group">'
                . '<input type="number" class="form-control" name="tpv_efectivo" value="' . $model->tpv_efectivo . '" ' . $disabled . '>'
                . '</div>'
                . '</div>'
                . '<div class="col-sm-3">'
                . Tools::trans('pos-terminal') . ' - ' . Tools::trans('money-change')
                . '<div class="input-group">'
                . '<input type="number" class="form-control" name="tpv_cambio" value="' . $model->tpv_cambio . '" ' . $disabled . '>'
                . '</div>'
                . '</div>'
                . '</div>'
                . '</div>';
        }

        return $html;
    }
}
