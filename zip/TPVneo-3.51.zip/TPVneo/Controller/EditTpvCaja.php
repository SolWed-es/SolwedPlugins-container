<?php
/**
 * Copyright (C) 2023-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\TPVneo\Controller;

use FacturaScripts\Core\DataSrc\Agentes;
use FacturaScripts\Core\DataSrc\FormasPago;
use FacturaScripts\Core\Lib\AssetManager;
use FacturaScripts\Core\Lib\ExtendedController\EditController;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Plugins\TPVneo\Lib\Tickets\BoxClosure;
use FacturaScripts\Plugins\TPVneo\Model\TpvCaja;

class EditTpvCaja extends EditController
{
    public function getModelClassName(): string
    {
        return "TpvCaja";
    }

    public function getPageData(): array
    {
        $data = parent::getPageData();
        $data["menu"] = "admin";
        $data["title"] = "box";
        $data["icon"] = "fa-solid fa-box";
        return $data;
    }

    protected function closeBoxAction(): bool
    {
        if (false === $this->validateFormToken()) {
            return true;
        }

        $caja = new TpvCaja();
        if (false === $caja->load($this->request->query->get('code'))
            || $caja->fechafin !== null) {
            return true;
        }

        $caja->close(0);
        if (false === $caja->save()) {
            Tools::log()->warning('record-save-error');
            return true;
        }

        Tools::log()->notice('record-updated-correctly');
        return true;
    }

    protected function createViews()
    {
        parent::createViews();
        $this->setTabsPosition('bottom');

        // leemos todas las columnas y las desactivamos
        $mvn = $this->getMainViewName();
        foreach ($this->views[$mvn]->getColumns() as $group) {
            foreach ($group->columns as $key => $item) {
                $this->views[$mvn]->disableColumn($key, false, 'true');
            }
        }

        AssetManager::add('js', '/Dinamic/Assets/JS/iframePrint.js');

        // desactivamos opciones
        $this->setSettings($mvn, 'btnNew', false);
        $this->setSettings($mvn, 'btnSave', false);
        $this->setSettings($mvn, 'btnDelete', false);
        $this->setSettings($mvn, 'btnUndo', false);

        $this->createViewsDocs();
        $this->createViewsMovements();
    }

    protected function createViewsDocs(string $viewName = 'ListTpvDoc'): void
    {
        foreach (['FacturaCliente', 'AlbaranCliente'] as $num => $doctype) {
            // añadimos la pestaña del modelo que corresponda
            $title = $doctype === 'FacturaCliente' ? 'invoices' : 'delivery-notes';
            $icon = $doctype === 'FacturaCliente' ? 'fa-solid fa-file-invoice-dollar fa-fw' : 'fa-solid fa-dolly-flatbed';
            $this->addListView($viewName . '-' . $num, $doctype, $title, $icon)
                ->addSearchFields(['codigo', 'nombrecliente', 'numero2', 'observaciones'])
                ->addOrderBy(['fecha', 'hora'], 'date', 2)
                ->addOrderBy(['codigo'], 'code')
                ->addOrderBy(['total'], 'total')
                ->addFilterSelect('codagente', 'agent', 'codagente', Agentes::codeModel())
                ->addFilterSelect('codpago', 'payment-method', 'codpago', FormasPago::codeModel())
                ->setSettings('btnNew', false);
        }
    }

    protected function createViewsMovements(string $viewName = 'ListTpvMovimiento'): void
    {
        $this->addListView($viewName, 'TpvMovimiento', 'movements', 'fa-solid fa-coins')
            ->addSearchFields(['motive'])
            ->addOrderBy(['creationdate'], 'date', 2)
            ->addOrderBy(['amount'], 'amount')
            ->setSettings('btnNew', false)
            ->setSettings('btnDelete', false)
            ->setSettings('clickable', false)
            ->setSettings('checkBoxes', false);
    }

    protected function execPreviousAction($action)
    {
        return match ($action) {
            'close-box' => $this->closeBoxAction(),
            'recalculate-box' => $this->recalculateBoxAction(),
            'print-box-closure' => $this->printBoxClosureAction(),
            default => parent::execPreviousAction($action),
        };
    }

    protected function loadData($viewName, $view)
    {
        $mvn = $this->getMainViewName();

        switch ($viewName) {
            case 'ListTpvDoc-0':
            case 'ListTpvDoc-1':
            case 'ListTpvMovimiento':
                $where = [Where::column('idcaja', $this->request->query->get('code'))];
                $view->loadData('', $where);
                break;

            case $mvn:
                parent::loadData($viewName, $view);

                // si la caja no está cerrada y es administrador
                // añadimos el botón cerrar caja
                if (empty($this->views[$viewName]->model->fechafin)
                    && $this->user->admin) {
                    if ($this->user->admin) {
                        $this->addButton($viewName, [
                            'action' => 'close-box',
                            'color' => 'warning',
                            'confirm' => true,
                            'icon' => 'fa-solid fa-lock',
                            'label' => 'close-box'
                        ]);
                    }
                }

                // si la caja está cerrada
                // añadimos el botón para imprimir el cierre de caja
                if (!empty($this->views[$viewName]->model->fechafin)) {
                    $this->addButton($viewName, [
                        'action' => 'print-box-closure',
                        'color' => 'light',
                        'icon' => 'fa-solid fa-print',
                        'id' => 'iframe-print',
                        'label' => 'print-box-closure',
                        'type' => 'action'
                    ]);
                }

                // si es administrador añadimos el botón para recalcular la caja
                if ($this->user->admin) {
                    $this->addButton($viewName, [
                        'action' => 'recalculate-box',
                        'color' => 'info',
                        'icon' => 'fa-solid fa-calculator',
                        'label' => 'recalculate-box'
                    ]);
                }
                break;
        }
    }

    protected function recalculateBoxAction(): bool
    {
        if (false === $this->validateFormToken()) {
            return true;
        }

        $box = new TpvCaja();
        if (false === $box->load($this->request->query->get('code'))) {
            return true;
        }

        if ($box->save()) {
            Tools::log()->notice('record-updated-correctly');
        } else {
            Tools::log()->warning('record-save-error');
        }

        return true;
    }

    protected function printBoxClosureAction(): bool
    {
        if (false === $this->validateFormToken()) {
            return true;
        }

        $box = new TpvCaja();
        if (false === $box->load($this->request->query->get('code'))
            || empty($box->fechafin)) {
            return true;
        }

        $printer = $box->getTerminal()->getPrinter();
        if (false === $printer->exists()) {
            return true;
        }

        BoxClosure::print($box, $printer, $this->user);
        return true;
    }
}
