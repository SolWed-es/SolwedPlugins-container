$(function(){
    $(document).on("keydown.autocomplete","#findTPVneoBoxInput",function(e){
        $(this).autocomplete({
            source: function (request, response) {
                $.ajax({
                    method: "POST",
                    url: window.location.href,
                    data: {action: "autocomplete-tpvneo-box", term: request.term},
                    dataType: "json",
                    success: function (results) {
                        let values = [];
                        results.forEach(function (element) {
                            if (element.key === null || element.key === element.value) {
                                values.push(element);
                            } else {
                                values.push({key: element.key, value: element.key + " | " + element.value});
                            }
                        });
                        response(values);
                    },
                    error: function (msg) {
                        alert(msg.status + " " + msg.responseText);
                    }
                });
            },
            select: function (event, ui) {
                if (ui.item.key !== null) {
                    const value = ui.item.value.split(" | ");
                    $("input[name=\"idcaja\"]").val(value[0]);
                }
            },
            open: function (event, ui) {
                $(this).autocomplete('widget').css('z-index', 1500);
                return false;
            }
        });
    });

    $('button#deleteTPVneoBox').on('click', function(){
        $('input[name="idcaja"]').val('');
        $('input#findTPVneoBoxInput').val('');
        $(this).parent().html('<span id="searchTPVneoBox" class="input-group-text"><i class="fas fa-search fa-fw"></i></span>');
    });
});