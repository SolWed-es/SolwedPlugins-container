// añadimos un iframe al body
$(document).ready(function () {
    $('body').append('<iframe class="d-none" src="http://localhost:8089"></iframe>');
});