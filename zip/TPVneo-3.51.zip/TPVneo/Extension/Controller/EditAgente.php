<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\TPVneo\Extension\Controller;

use Closure;
use FacturaScripts\Core\Where;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class EditAgente
{
    public function createViews(): Closure
    {
        return function () {
            $this->createViewsTpv();
        };
    }

    protected function createViewsTpv(): Closure
    {
        return function (string $viewName = 'EditTpvAgente') {
            $this->addEditListView($viewName, 'TpvAgente', 'pos-terminal', 'fa-solid fa-cash-register')
                ->disableColumn('agent')
                ->setInLine(true);
        };
    }

    protected function loadData(): Closure
    {
        return function ($viewName, $view) {
            if ($viewName == 'EditTpvAgente') {
                $where = [Where::column('codagente', $this->request->query->get('code'))];
                $view->loadData('', $where);
            }
        };
    }
}
