<?php

namespace FacturaScripts\Plugins\Rdgarantia;

use FacturaScripts\Core\Template\InitClass;

/**
 * Los plugins pueden contener un archivo Init.php en el que se definen procesos a ejecutar
 * cada vez que carga FacturaScripts o cuando se instala o actualiza el plugin.
 *
 * https://facturascripts.com/publicaciones/el-archivo-init-php-307
 */
class Init extends InitClass
{
    public function init(): void
    {
        // Load model extension for payment sync (catches changes from anywhere: edit page, bulk operations, recibos, etc.)
        $this->loadExtension(new Extension\Model\FacturaCliente());
        // se ejecuta cada vez que carga FacturaScripts (si este plugin está activado).
    }

    public function uninstall(): void
    {
        // se ejecuta cada vez que se desinstale el plugin. Primero desinstala y luego ejecuta el uninstall.
    }

    public function update(): void
    {
        // se ejecuta cada vez que se instala o actualiza el plugin
    }
}
