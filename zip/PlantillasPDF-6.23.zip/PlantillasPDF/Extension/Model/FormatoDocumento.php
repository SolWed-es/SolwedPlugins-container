<?php
/**
 * Copyright (C) 2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\PlantillasPDF\Extension\Model;

use Closure;
use FacturaScripts\Core\Tools;

class FormatoDocumento
{
    public function clear(): Closure
    {
        return function () {
            $settingsName = 'plantillaspdf';

            $this->autoaplicar = true;
            $this->hideobservations = false;
            $this->hidetotals = false;
            $this->hide_breakdowns = false;
            $this->hide_vat_breakdown = false;
            $this->primarynumero2 = false;
            $this->hide_attachment_document = false;
            $this->texto = Tools::settings($settingsName, 'endtext');

            $fields = ['color1', 'linecolalignments', 'linecols', 'linecoltypes', 'linesheight'];
            foreach ($fields as $field) {
                $this->{$field} = Tools::settings($settingsName, $field);
            }
        };
    }

    public function test(): Closure
    {
        return function () {
            $this->nombre = empty($this->nombre) ? Tools::noHtml($this->titulo) : Tools::noHtml($this->nombre);

            $fields = [
                'color1', 'footertext', 'linecolalignments', 'linecols', 'linecoltypes', 'orientation', 'size',
                'texto', 'thankstext', 'thankstitle', 'titulo'
            ];
            foreach ($fields as $field) {
                $this->{$field} = Tools::noHtml($this->{$field});
            }

            if (empty($this->idempresa)) {
                $this->idempresa = Tools::settings('default', 'idempresa');
            }

            $bottomMargin = (int)Tools::settings('plantillaspdf', 'bottommargin', 0);
            if ($this->footertext && strlen($this->footertext) > 200 && $bottomMargin <= 20) {
                Tools::log()->warning('footer-text-long');
            }
        };
    }

    public function url(): Closure
    {
        return function (string $type, string $list) {
            if ($type === 'list') {
                return 'AdminPlantillasPDF?activetab=ListFormatoDocumento';
            }
        };
    }
}