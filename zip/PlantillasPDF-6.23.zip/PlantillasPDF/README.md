# PlantillasPDF
Plugin para FacturaScripts que permite configurar o personalizar los diseños PDF de facturas, albaranes, pedidos y presupuestos.
- https://facturascripts.com/plugins/plantillaspdf

## No es software libre
Este plugin no es software libre, y, por tanto, no se permite su copia o distribución.

## Despliegue
- Instalar dependencias mediante composer.
- Desplegar sobre la carpeta Plugins/**PlantillasPDF**
