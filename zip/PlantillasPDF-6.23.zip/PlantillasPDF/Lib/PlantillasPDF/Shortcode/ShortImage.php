<?php
/**
 * Copyright (C) 2024-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\PlantillasPDF\Lib\PlantillasPDF\Shortcode;

use FacturaScripts\Dinamic\Model\AttachedFile;
use FacturaScripts\Dinamic\Model\FormatoDocumento;
use Mpdf\Mpdf;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class ShortImage extends Shortcode
{
    public static function replace(?string $content, $model, FormatoDocumento $format, MPDF &$mpdf): ?string
    {
        $shorts = static::searchCode($content, "/\[ShortImage(.*?)\]/");

        if (count($shorts[0]) <= 0) {
            return $content;
        }

        for ($x = 0; $x < count($shorts[1]); $x++) {
            $params = static::getAttributes($shorts[1][$x]);

            $cssclass = $params['class'] ?? '';
            $cssid = $params['id'] ?? '';
            $width = $params['width'] ?? '';
            $height = $params['height'] ?? '';
            $title = $params['title'] ?? '';
            $alt = $params['alt'] ?? '';
            $onlyUrl = isset($params['onlyUrl']) && $params['onlyUrl'] == 'yes';

            if (isset($params['idfile'])) {
                $file = new AttachedFile();
                $file->load($params['idfile']);
                $url = $file->url('download-permanent');
            } else if (isset($params['src'])) {
                $url = $params['src'];
            }

            if ($onlyUrl) {
                $content = str_replace($shorts[0][$x], $url, $content);
            } else {
                $img = '<img 
                    src="' . $url . '"
                    class="' . $cssclass . '"
                    id="' . $cssid . '"
                    title="' . $title . '"
                    alt="' . $alt . '"
                    width="' . $width . '"
                    height="' . $height . '"
                >';

                $content = str_replace($shorts[0][$x], $img, $content);
            }
        }

        return $content;
    }
}