<?php
/**
 * Copyright (C) 2024-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\PlantillasPDF\Lib\PlantillasPDF\Shortcode;

use DateTime;
use DateTimeZone;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\FormatoDocumento;
use Mpdf\Mpdf;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class ShortDateHour extends Shortcode
{
    public static function replace(?string $content, $model, FormatoDocumento $format, MPDF &$mpdf): ?string
    {
        $shorts = static::searchCode($content, "/\[ShortDateHour(.*?)\]/");

        if (count($shorts[0]) <= 0) {
            return $content;
        }

        for ($x = 0; $x < count($shorts[1]); $x++) {
            $params = static::getAttributes($shorts[1][$x]);

            $datehour = new DateTime();

            if (isset($params['zone'])) {
                $datehour->setTimezone(new DateTimeZone($params['zone']));
            }

            $format = $params['format'] ?? Tools::DATETIME_STYLE;
            $content = str_replace($shorts[0][$x], $datehour->format($format), $content);
        }

        return $content;
    }
}