<?php
/**
 * Copyright (C) 2024-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\PlantillasPDF\Lib\PlantillasPDF\Shortcode;

use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\FormatoDocumento;
use Mpdf\Mpdf;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class ShortLink extends Shortcode
{
    public static function replace(?string $content, $model, FormatoDocumento $format, MPDF &$mpdf): ?string
    {
        $shorts = static::searchCode($content, "/\[ShortLink(.*?)\][\r\n|\n]*(.*?)[\r\n|\n]*\[\/ShortLink\]/");

        if (count($shorts[0]) <= 0) {
            return $content;
        }

        for ($x = 0; $x < count($shorts[1]); $x++) {
            $params = static::getAttributes($shorts[1][$x]);

            $class = $params['class'] ?? '';
            $id = $params['id'] ?? '';
            $target = $params['target'] ?? '';
            $link = $params['href'] ?? '';

            if (isset($params['siteUrl']) && $params['siteUrl'] == 'yes') {
                $link = Tools::siteUrl() . $link;
            }

            $html = '<a href="' . $link . '" target="' . $target . '" class="' . $class . '" id="' . $id . '">' . $shorts[2][$x] . '</a>';

            $content = str_replace($shorts[0][$x], $html, $content);
        }

        return $content;
    }
}