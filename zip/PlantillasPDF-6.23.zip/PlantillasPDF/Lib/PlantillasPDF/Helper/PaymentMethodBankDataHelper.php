<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\PlantillasPDF\Lib\PlantillasPDF\Helper;

use FacturaScripts\Core\Template\ExtensionsTrait;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Model\Base\BusinessDocument;
use FacturaScripts\Dinamic\Model\CuentaBanco;
use FacturaScripts\Dinamic\Model\CuentaBancoCliente;
use FacturaScripts\Dinamic\Model\FacturaCliente;
use FacturaScripts\Dinamic\Model\FormaPago;

/**
 * @author Carlos Garcia Gomez      <carlos@facturascripts.com>
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class PaymentMethodBankDataHelper
{
    use ExtensionsTrait;

    /**
     * @param BusinessDocument|FacturaCliente $model
     */
    public static function get($model): string
    {
        $payMethod = new FormaPago();
        if (false === $payMethod->load($model->codpago)) {
            return '-';
        }

        $pipe = new self();
        $return = $pipe->pipe('get', $model, $payMethod);
        if (null !== $return) {
            return $return;
        }

        $cuentaBcoCli = new CuentaBancoCliente();
        $where = [Where::eq('codcliente', $model->codcliente)];
        if ($payMethod->domiciliado && $cuentaBcoCli->loadWhere($where, ['principal' => 'DESC'])) {
            $bankClient = $payMethod->descripcion
                . '<br/>' . $cuentaBcoCli->getIban(true, true);

            if (false === empty($cuentaBcoCli->swift)) {
                $bankClient .= '<br/>' . Tools::trans('swift') . ': ' . $cuentaBcoCli->swift;
            }

            return $bankClient;
        }

        $cuentaBco = new CuentaBanco();
        if (empty($payMethod->codcuentabanco) ||
            false === $cuentaBco->load($payMethod->codcuentabanco) ||
            empty($cuentaBco->iban)) {
            return $payMethod->descripcion;
        }

        $bank = $payMethod->descripcion
            . '<br/>' . Tools::trans('iban') . ': ' . $cuentaBco->getIban(true);

        if (false === empty($cuentaBco->swift)) {
            $bank .= '<br/>' . Tools::trans('swift') . ': ' . $cuentaBco->swift;
        }

        return $bank;
    }
}
