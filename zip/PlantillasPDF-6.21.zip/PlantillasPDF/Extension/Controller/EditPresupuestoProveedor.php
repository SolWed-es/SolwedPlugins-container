<?php
/**
 * Copyright (C) 2024 Daniel Fernández Giménez <hola@danielfg.es>
 */

namespace FacturaScripts\Plugins\PlantillasPDF\Extension\Controller;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class EditPresupuestoProveedor
{
    use CommonFileTrait;
}