<?php
/**
 * Copyright (C) 2024 Daniel Fernández Giménez <hola@danielfg.es>
 */

namespace FacturaScripts\Plugins\PlantillasPDF\Extension\Controller;

use Closure;

trait CommonFileTrait
{
    public function addFileAction(): Closure
    {
        return function ($fileRelation, $request) {
            $fileRelation->pp_print_pdf = (bool)$request->request->get('pp_print_pdf', false);
            $fileRelation->pp_print_desc_pdf = (bool)$request->request->get('pp_print_desc_pdf', false);
        };
    }

    public function editFileAction(): Closure
    {
        return function ($fileRelation, $request) {
            $fileRelation->pp_print_pdf = (bool)$request->request->get('pp_print_pdf', false);
            $fileRelation->pp_print_desc_pdf = (bool)$request->request->get('pp_print_desc_pdf', false);
        };
    }
}