<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\PlantillasPDF\Lib\PlantillasPDF\Helper;

use FacturaScripts\Core\Template\ExtensionsTrait;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Model\CuentaBanco;
use FacturaScripts\Dinamic\Model\CuentaBancoCliente;
use FacturaScripts\Dinamic\Model\CuentaBancoProveedor;
use FacturaScripts\Dinamic\Model\FormaPago;
use FacturaScripts\Dinamic\Model\ReciboCliente;
use FacturaScripts\Dinamic\Model\ReciboProveedor;

/**
 * @author Carlos Garcia Gomez      <carlos@facturascripts.com>
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class ReceiptBankDataHelper
{
    use ExtensionsTrait;

    public static function get(ReciboCliente|ReciboProveedor $receipt, array $receipts): string
    {
        // Si la forma de pago es igual en todos los recibos, solo la mostramos en el primero
        if (false === self::shouldShowPaymentMethod($receipt, $receipts)) {
            return '';
        }

        // Cargamos la forma de pago
        $payMethod = new FormaPago();
        if (false === $payMethod->load($receipt->codpago)) {
            return '-';
        }

        // Permitimos extensiones
        $pipe = new self();
        $return = $pipe->pipe('get', $payMethod, $receipt, $receipts);
        if (null !== $return) {
            return $return;
        }

        // Cargamos la cuenta bancaria por defecto
        $cuentaBco = new CuentaBanco();
        $cuentaBco->load($payMethod->codcuentabanco);

        // Si no está domiciliado, usamos la cuenta bancaria de la empresa
        if (false === $payMethod->domiciliado) {
            return self::formatBankData($payMethod, $cuentaBco);
        }

        // Si está domiciliado, intentamos obtener la cuenta domiciliada del cliente/proveedor
        $cuentaDomiciliada = self::getDomiciledBankAccount($receipt, $payMethod);
        if ($cuentaDomiciliada) {
            return self::formatBankData($payMethod, $cuentaDomiciliada);
        }

        // Si no hay cuenta domiciliada, usamos la cuenta por defecto
        return self::formatBankData($payMethod, $cuentaBco);
    }

    private static function shouldShowPaymentMethod(ReciboCliente|ReciboProveedor $receipt, array $receipts): bool
    {
        if (empty($receipts)) {
            return true;
        }

        // Contamos cuántos recibos tienen la misma forma de pago
        $paymentEqual = 0;
        foreach ($receipts as $r) {
            if ($receipt->codpago == $r->codpago && $receipt->idrecibo != $receipts[0]->idrecibo) {
                $paymentEqual++;
            }
        }

        // Si todos tienen la misma forma de pago, solo la mostramos en el primero
        return count($receipts) !== $paymentEqual;
    }

    private static function formatBankData(FormaPago $payMethod, CuentaBanco|CuentaBancoCliente|CuentaBancoProveedor $bankAccount): string
    {
        $bank = $payMethod->descripcion;

        if (false === $payMethod->imprimir) {
            return $bank;
        }

        // Añadimos el IBAN según el tipo de cuenta
        if ($bankAccount instanceof CuentaBancoCliente) {
            $bank .= '<br/>' . $bankAccount->getIban(true, true);
        } elseif ($bankAccount instanceof CuentaBancoProveedor) {
            $bank .= '<br/>' . $bankAccount->getIban(true, false);
        } else {
            $bank .= '<br/>' . $bankAccount->getIban(true);
        }

        // Añadimos el SWIFT si existe
        if (!empty($bankAccount->swift)) {
            $bank .= '<br/>' . Tools::trans('swift') . ': ' . $bankAccount->swift;
        }

        return $bank;
    }

    private static function getDomiciledBankAccount(
        ReciboCliente|ReciboProveedor $receipt,
        FormaPago $payMethod
    ): CuentaBancoCliente|CuentaBancoProveedor|null {
        if (false === $payMethod->domiciliado) {
            return null;
        }

        // Recibo de proveedor
        if ($receipt->modelClassName() === 'ReciboProveedor') {
            $cuentaDom = new CuentaBancoProveedor();
            $whereDom = [Where::eq('codproveedor', $receipt->codproveedor)];

            if ($cuentaDom->loadWhere($whereDom, ['principal' => 'DESC'])) {
                return $cuentaDom;
            }
        }

        // Recibo de cliente
        if ($receipt->modelClassName() === 'ReciboCliente') {
            $cuentaDom = new CuentaBancoCliente();
            $whereDom = [Where::eq('codcliente', $receipt->codcliente)];

            if ($cuentaDom->loadWhere($whereDom, ['principal' => 'DESC'])) {
                return $cuentaDom;
            }
        }

        return null;
    }
}
