<?php
/**
 * Copyright (C) 2024-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\PlantillasPDF\Lib\PlantillasPDF\Shortcode;

use FacturaScripts\Dinamic\Model\FormatoDocumento;
use Mpdf\Mpdf;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class ShortNewPage extends Shortcode
{
    public static function replace(?string $content, $model, FormatoDocumento $format, MPDF &$mpdf): ?string
    {
        $shorts = static::searchCode($content, "/\[ShortNewPage(.*?)\]/");

        if (count($shorts[0]) <= 0) {
            return $content;
        }

        // reemplazamos los shortcodes por el contenido que queramos
        for ($x = 0; $x < count($shorts[0]); $x++) {
            $content = str_replace($shorts[0][$x], '<pagebreak>', $content);
        }

        return $content;
    }
}