<?php
/**
 * Copyright (C) 2024-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\PlantillasPDF\Lib\PlantillasPDF\Shortcode;

use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\FormatoDocumento;
use Mpdf\Mpdf;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
abstract class Shortcode
{
    /** @var array */
    private static $codes = [];

    abstract public static function replace(?string $content, $model, FormatoDocumento $format, MPDF &$mpdf): ?string;

    public static function addCode(string $code): void
    {
        $className = '\\FacturaScripts\\Dinamic\\Lib\\PlantillasPDF\\Shortcode\\' . $code;
        if (false === isset(self::$codes[$code]) && class_exists($className)) {
            self::$codes[$code] = $className;
        }
    }

    public static function render(?string $content, $model, FormatoDocumento $format, MPDF &$mpdf): ?string
    {
        foreach (self::$codes as $code => $className) {
            if (class_exists($className)) {
                $content = $className::replace($content, $model, $format, $mpdf);
            }
        }

        return $content;
    }

    protected static function getAttributes(string $short): array
    {
        $short = Tools::fixHtml($short);
        preg_match_all('/[\S]*=["\'][^"\']*["\']/', $short, $matches);

        $params = [];

        if (count($matches[0]) > 0) {
            foreach ($matches[0] as $a) {
                $a = str_replace(['&#39;', "'"], "", $a);
                $a = str_replace(['&quot;', '&#34;', '"'], "", $a);
                $param = explode('=', $a);
                $params[$param[0]] = $param[1];
            }
        }

        return $params;
    }

    protected static function searchCode(?string $content, string $search): ?array
    {
        preg_match_all($search, $content, $matches);
        return (count($matches) > 0) ? $matches : null;
    }
}