<?php
/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\HumanResources\Model\Report\Data;

/**
 * Class to manage employee attendance data
 *
* @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class AttendanceData
{
    /**
     * indicates if the input record is authorized.
     *
     * @var bool
     */
    public bool $authorized_input = false;

    /**
     * indicates if the exit record is authorized.
     *
     * @var bool
     */
    public bool $authorized_exit = false;

    /**
     * Indicates if the attendance can be deleted.
     *
     * @var bool
     */
    public bool $canDelete = false;

    /**
     * Day that is being processed
     *
     * @var ?string
     */
    public ?string $date = null;

    /**
     * Time of departure of assistance
     *
     * @var ?string
     */
    public ?string $exit = null;

    /**
     * Employee record identifier
     *
     * @var int
     */
    public int $idemployee = 0;

    /**
     * Attendance departure record identifier
     *
     * @var int
     */
    public int $idexit = 0;

    /**
     * Attendance entry record identifier
     *
     * @var int
     */
    public int $idinput = 0;

    /**
     * The Incident code Indicates if the day registers any incidence
     *
     * @var string
     */
    public string $incidence = '';

    /**
     *
     * @var bool
     */
    public bool $incidenceError = false;

    /**
     * Time of attendance entry
     *
     * @var ?string
     */
    public ?string $input = null;

    /**
     * Input delay in minutes.
     *
     * @var int
     */
    public int $inputdelay = 0;

    /**
     * Employee name
     *
     * @var string
     */
    public string $name = '';

    /**
     * Total hours of attendance (in a decimal system)
     *
     * @var float
     */
    public float $total = 0.0;

    /**
     * Carried balance of hours per day (in a decimal system)
     *
     * @var float
     */
    public float $totalday = 0.0;

    /**
     * Translated incident code
     *
     * @var string
     */
    public string $translatedIncidence = '';

    /**
     * Translated incident description
     *
     * @var string
     */
    public string $translatedIncidenceDesc = '';
}
