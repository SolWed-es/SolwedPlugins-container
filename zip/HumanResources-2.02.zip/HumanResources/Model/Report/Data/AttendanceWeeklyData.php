<?php
/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\HumanResources\Model\Report\Data;

/**
 * Class to manage employee attendance weekly data
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class AttendanceWeeklyData
{
    const ATT_MAXDAYS = 7;

    /**
     * Employee record identifier
     *
     * @var int
     */
    public int $idemployee = 0;

    /**
     * Employee description
     *
     * @var string
     */
    public string $name = '';

    /**
     * List of theoretical hours to work per day according to the work shift
     *
     * @var float[]
     */
    public array $hours = [];

    /**
     * List of actual hours worked per day
     *
     * @var float[]
     */
    public array $worked;

    /**
     * Difference between theoretical and actual hours worked per day
     *
     * @var float[]
     */
    public array $difference;

    /**
     * Indicates if the employee has an impact on any of the days processed
     *
     * @var bool
     */
    public bool $hasIncidence = false;

    /**
     * List of incidence codes per day
     *
     * @var string[]
     */
    public array $incidence = [];

    /**
     * Total number of days with input delay
     *
     * @var int
     */
    public int $totalInputDelay = 0;

    /**
     * Total number of holiday days
     *
     * @var int
     */
    public int $totalHoliday = 0;

    /**
     * Total number of theoretical hours to work
     *
     * @var float
     */
    public float $totalHours = 0.00;

    /**
     * Total number of hours worked
     *
     * @var float
     */
    public float $totalWorked = 0.00;

    /**
     * Difference between theoretical and actual hours worked
     *
     * @var float
     */
    public float $totalDifference = 0.00;

    /**
     * Date from start period calculated
     *
     * @var ?string
     */
    public ?string $startdate = null;

    /**
     * List of work periods per day
     *
     * @var array
     */
    public array $workperiods = [];

    /**
     * Class constructor
     *
     * @param int $idemployee
     * @param string $name
     * @param string $startdate
     */
    public function __construct(int $idemployee, string $name, string $startdate)
    {
        $this->idemployee = $idemployee;
        $this->name = $name;
        $this->startdate = $startdate;

        $this->hours = array_pad([], self::ATT_MAXDAYS, 0.0000);
        $this->worked = array_pad([], self::ATT_MAXDAYS, 0.0000);
        $this->difference = array_pad([], self::ATT_MAXDAYS, 0.0000);
        $this->incidence = array_pad([], self::ATT_MAXDAYS, '');
        $this->workperiods = array_pad([], self::ATT_MAXDAYS, []);

        $this->hasIncidence = false;
        $this->totalInputDelay = 0;
        $this->totalHoliday = 0;
        $this->totalHours = 0.00;
        $this->totalWorked = 0.00;
        $this->totalDifference = 0.00;
    }
}
