<?php
/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\HumanResources\Model;

use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Plugins\HumanResources\Lib\HumanResources\ModelExtended;

/**
 * List of max days of holidays for employee/year
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class EmployeeHolidayMax extends ModelExtended
{
    use ModelTrait;

    /**
     * Year to which the max holiday applies.
     *
     * @var string
     */
    public $applyto;

    /**
     * Employee relation field
     *
     * @var integer
     */
    public $idemployee;

    /**
     * Total days can be taken as holiday in the year.
     *
     * @var integer
     */
    public $maxdays;

    /**
     * This function is called when creating the model table. Returns the SQL
     * that will be executed after the creation of the table. Useful to insert values
     * default.
     *
     * @return string
     */
    public function install(): string
    {
        new Employee();
        return parent::install();
    }

    /**
     * Returns the maximum holidays for an employee in a given year.
     *
     * @param $idemployee
     * @param $year
     * @return int
     */
    public static function maxForEmployee($idemployee, $year): int
    {
        $where = [
            new DataBaseWhere('idemployee', $idemployee),
            new DataBaseWhere('applyto', $year),
        ];
        $maxHoliday = new self();
        $maxHoliday->loadWhere($where);
        return $maxHoliday->maxdays;
    }

    /**
     * Returns the name of the table that uses this model.
     *
     * @return string
     */
    public static function tableName(): string
    {
        return 'rrhh_employeesholidaysmax';
    }

    /**
     * Reset the values of all model properties.
     */
    public function clear(): void
    {
        parent::clear();
        $this->maxdays = 30;
    }

    /**
     * Returns the url where to see / modify the data.
     *
     * @param string $type
     * @param string $list
     * @return string
     */
    public function url(string $type = 'auto', string $list = 'List'): string
    {
        return parent::url($type, 'EditEmployee?code=' . $this->idemployee . '&activetab=ListEmployeeHoliday2');
    }
}
