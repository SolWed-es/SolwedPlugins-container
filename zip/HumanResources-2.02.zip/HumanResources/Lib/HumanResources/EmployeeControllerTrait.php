<?php
/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\HumanResources\Lib\HumanResources;

use FacturaScripts\Core\Lib\ExtendedController\EditListView;
use FacturaScripts\Core\Lib\ExtendedController\ListView;

/**
 * Auxiliar Method for edit Employee.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
trait EmployeeControllerTrait
{
    /**
     * Create and return a EditListView for Employee.
     * If you want to disable columns, add the column key to $disableColumns array.
     *
     * @param string $viewName
     * @param string $modelName
     * @param string $viewTitle
     * @param string $viewIcon
     * @param array $disableColumns
     * @return EditListView
     */
    protected function createViewEdit(string $viewName, string $modelName, string $viewTitle, string $viewIcon, array $disableColumns = ['code', 'employee']): EditListView
    {
        $view = $this->addEditListView($viewName, $modelName, $viewTitle, $viewIcon)
            ->setInLine(false);

        foreach ($disableColumns as $keyColumn) {
            $view->disableColumn($keyColumn, true);
        }

        return $view;
    }

    /**
     * Create and return a ListView for Employee.
     *
     * @param string $viewName
     * @param string $modelName
     * @param string $viewTitle
     * @param string $viewIcon
     * @param array $disableColumns
     * @return ListView
     */
    protected function createViewList(string $viewName, string $modelName, string $viewTitle, string $viewIcon, array $disableColumns = ['code', 'employee']): ListView
    {
        $view = $this->addListView($viewName, $modelName, $viewTitle, $viewIcon);
        foreach ($disableColumns as $keyColumn) {
            $this->views[$viewName]->disableColumn($keyColumn, true);
        }
        return $view;
    }

    /**
     * Return the orderBy array for each view.
     *
     * @param string $viewName
     * @return array
     */
    protected function orderByForView(string $viewName)
    {
        return match ($viewName) {
            'EditEmployeeSalary' => ['channel' => 'ASC', 'calculation' => 'ASC', 'idsalaryconcept' => 'ASC'],
            'EditEmployeeContract',
            'ListEmployeeHoliday',
            'EditEmployeeLeave',
            'EditEmployeeSanction',
            'EditEmployeeWorkShift' => ['startdate' => 'DESC'],
            default => [],
        };
    }
}
