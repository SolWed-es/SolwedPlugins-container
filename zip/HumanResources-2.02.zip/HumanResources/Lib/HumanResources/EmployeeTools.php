<?php
/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\HumanResources\Lib\HumanResources;

use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\DataSrc\Paises;
use FacturaScripts\Core\Lib\Vies;
use FacturaScripts\Dinamic\Model\CodeModel;
use FacturaScripts\Dinamic\Model\Employee;

/**
 * Class with tools for Employee management.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class EmployeeTools
{
    /**
     * Check the VAT number of the employee using VIES service.
     *
     * @param string $idcountry
     * @param string $cifnif
     * @return bool
     */
    public static function checkVies(string $idcountry, string $cifnif): bool
    {
        $codIso = Paises::get($idcountry)->codiso ?? '';
        return Vies::check($cifnif ?? '', $codIso) === 1;
    }

    /**
     * Allows using this model as a source in CodeModel special model.
     *
     * @param string $query
     * @param string $fieldCode
     * @param array  $where
     *
     * @return CodeModel[]
     */
    public static function codeModelSearch(string $query, string $fieldCode = '', array $where = []): array
    {
        $field = empty($fieldCode) ? Employee::primaryColumn() : $fieldCode;
        $fields = 'id|credentialid|nombre|cifnif|insuranceid';
        $where[] = new DataBaseWhere($fields, mb_strtolower($query, 'UTF8'), 'LIKE');
        return CodeModel::all(
            Employee::tableName(), $field, 'nombre', false, $where
        );
    }

    /**
     * Search id Employee from credential
     *
     * @param int $idEmployee
     * @return int|null
     */
    public static function getCredentialFromIdEmployee(int $idEmployee): ?int
    {
        $model = new CodeModel();
        $value = $model->getDescription(Employee::tableName(), Employee::primaryColumn(), $idEmployee, 'credentialid');
        return empty($value) ? null : (int)$value;
    }

    /**
     * Search credential from id Employee
     *
     * @param int $credential
     * @return int|null
     */
    public static function getIdEmployeeFromCredential(int $credential): ?int
    {
        $model = new CodeModel();
        $value = $model->getDescription(Employee::tableName(), 'credentialid', $credential, Employee::primaryColumn());
        return empty($value) ? null : (int) $value;
    }

    /**
     * Get an Ids list for employee where list
     *
     * @param DataBaseWhere[] $where
     * @return int[]
     */
    public static function getIdFromDataBaseWhere(array $where): array
    {
        $result = [];
        foreach (Employee::all($where) as $employee) {
            $result[] = $employee->id;
        }
        return $result;
    }
}
