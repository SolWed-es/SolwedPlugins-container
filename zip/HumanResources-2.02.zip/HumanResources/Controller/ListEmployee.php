<?php
/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\HumanResources\Controller;

use Exception;
use FacturaScripts\Core\Lib\ExtendedController\BaseView;
use FacturaScripts\Core\Lib\ExtendedController\ListController;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Model\CodeModel;
use FacturaScripts\Dinamic\Model\EmployeeHoliday;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\Empresa;
use FacturaScripts\Dinamic\Model\Employee;
use FacturaScripts\Dinamic\Model\Department;
use FacturaScripts\Plugins\HumanResources\Lib\DateTimeTools;

/**
 * Controller to list the items in the Employee model
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class ListEmployee extends ListController
{
    private const VIEW_EXPIRE_DOCUMENTS = 'ListEmployeeDocument';

    /**
     *
     * @var CodeModel[]
     */
    private array $companyList = [];

    /**
     * Returns basic page attributes
     *
     * @return array
     */
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['title'] = 'employees';
        $pageData['icon'] = 'fa-solid fa-id-card';
        $pageData['menu'] = 'rrhh';
        return $pageData;
    }

    /**
     * Runs the actions that alter the data before reading it.
     *
     * @param string $action
     * @return bool
     */
    protected function execPreviousAction($action)
    {
        return match ($action) {
            'authorized-holidays' => $this->execActionAuthorized(),
            'discharge' => $this->execActionDischargeEmployee(),
            default => parent::execPreviousAction($action),
        };
    }

    /**
     * Load views
     *
     * @throws Exception
     */
    protected function createViews()
    {
        $this->companyList = $this->codeModel->all(Empresa::tableName(), Empresa::primaryColumn(), 'nombrecorto');
        $this->createViewEmployee();
        $this->createViewPayRoll();
        $this->createViewEmployeeVoucher();
        $this->createViewEmployeeHoliday();
        $this->createViewEmployeeExpireDocs();
    }

    /**
     * @param string $viewName
     * @param BaseView $view
     */
    protected function loadData($viewName, $view)
    {
        if ($viewName === self::VIEW_EXPIRE_DOCUMENTS) {
            $where = [
                new DataBaseWhere('expires', null, 'IS NOT'),
                new DataBaseWhere('expires', DateTimeTools::dateFromCurrent('+7 day'), '<='),
            ];
            $view->loadData('', $where);
            if ($view->count === 0) {
                unset($this->views[$viewName]);
                return;
            }
            Tools::log()->info('there-are-expired-docs');
            return;
        }

        parent::loadData($viewName, $view);
        if ($viewName === 'ListEmployee') {
            $view->model->discharge_date = date(Tools::DATE_STYLE);
        }
    }

    /**
     * Authorizes the selected employee holidays.
     *
     * @return bool
     */
    private function execActionAuthorized(): bool
    {
        $ids = $this->request->request->getArray('codes');
        if (empty($ids)
            || false === $this->validateFormToken()
        ) {
            return true;
        }

        $employeeHoliday = new EmployeeHoliday();
        $count = 0;
        foreach($ids as $id){
            if (false === $employeeHoliday->load($id)
                || $employeeHoliday->authorized
            ) {
                continue;
            }

            $employeeHoliday->authorized = true;
            if ($employeeHoliday->save()) {
                $count++;
            }
        }

        if ($count > 0) {
            Tools::log()->info('authorized-records', ['%count%'=>$count]);
        }
        return true;
    }

    /**
     * Creates the view to list employees.
     *
     * @throws Exception
     */
    private function createViewEmployee(): void
    {
        $department = $this->codeModel->all(Department::tableName(), Department::primaryColumn(), 'name');

        $this->addView('ListEmployee', 'Employee', 'employees', 'fa-solid fa-id-card')
            // Search and Order By
            ->addSearchFields(['nombre', 'cifnif', 'insuranceid', 'credentialid'])
            ->addOrderBy(['nombre'], 'name', 1)
            ->addOrderBy(['credentialid'], 'credential')
            ->addOrderBy(['idcompany', 'nombre'], 'company')
            ->addOrderBy(['fechaalta'], 'discharge-date')
            // Filters
            ->addFilterSelect('idcompany', 'company', 'idcompany', $this->companyList)
            ->addFilterSelect('iddepartment', 'department', 'iddepartment', $department)
            ->addFilterSelectWhere('status', [
                ['label' => Tools::lang()->trans('only-active'), 'where' => [new DataBaseWhere('dischargedate', null, 'IS'), new DataBaseWhere('dischargedate', date('Y-m-d'), '>=', 'OR')]],
                ['label' => Tools::lang()->trans('only-suspended'), 'where' => [new DataBaseWhere('dischargedate', null, '!=')]],
                ['label' => Tools::lang()->trans('all'), 'where' => []]
            ]);

        $this->addButton('ListEmployee', [
            'type' => 'modal',
            'action' => 'discharge',
            'label' => 'discharge',
            'color' => 'warning',
            'icon' => 'fa-solid fa-sign-out-alt',
        ]);   
    }

    /**
     * Creates the view to list employees with documents about to expire.
     */
    private function createViewEmployeeExpireDocs(): void
    {
        $this->addView(self::VIEW_EXPIRE_DOCUMENTS, 'Join\EmployeeDocument', 'expired', 'fa-regular fa-calendar-times');
    }

    /**
     * Add the view to list employee holidays
     *
     * @throws Exception
     */
    private function createViewEmployeeHoliday(): void
    {
        $this->addView('ListEmployeeHoliday', 'Join\EmployeeHoliday', 'holidays', 'fa-solid fa-sun')
            // Search and Order By
            ->addSearchFields(['startdate', 'note'])
            ->addOrderBy(['holidays.authorized', 'holidays.startdate','startdate'], 'state', 1)
            ->addOrderBy(['holidays.startdate', 'employees.nombre'], 'date')
            ->addOrderBy(['employees.nombre', 'holidays.startdate'], 'name')
            ->addOrderBy(['holidays.idemployee'], 'employee')
            // Filters
            ->addFilterAutocomplete('employee', 'employee', 'idemployee', 'Employee', 'id', 'nombre')
            ->addFilterPeriod('date', 'date', 'startdate')
            ->addFilterSelectWhere('paid', [
                    ['label' => Tools::lang()->trans('all'), 'where' => []],
                    ['label' => Tools::lang()->trans('only-pending'), 'where' => [new DataBaseWhere('authorized', false)]],
                ]);

        $this->addButton('ListEmployeeHoliday', [
            'action' => 'authorized-holidays',
            'icon' => 'fa-solid fa-check-circle',
            'label' => 'authorized',
            'type' => 'action',
            'color' => 'success',
        ]); 
    }

    /**
     * Add the view to list employee vouchers
     */
    private function createViewEmployeeVoucher(): void
    {
        // View
        $this->addView('ListEmployeeVoucher', 'EmployeeVoucher', 'vouchers', 'fa-solid fa-hand-holding-usd')
            // Search and Order By
            ->addSearchFields(['name', 'CAST(amount AS CHAR(50))'])
            ->addOrderBy(['startdate'], 'date')
            ->addOrderBy(['name'], 'description')
            ->addOrderBy(['idemployee'], 'employee')
            // Filters
            ->addFilterAutocomplete('employee', 'employee', 'idemployee', 'Employee', 'id', 'nombre')
            ->addFilterPeriod('date', 'date', 'startdate')
            ->addFilterSelectWhere('paid', [
                    ['label' => Tools::lang()->trans('only-pending'), 'where' => [new DataBaseWhere('paid', false)]],
                    ['label' => Tools::lang()->trans('only-liquidated'), 'where' => [new DataBaseWhere('paid', true)]],
                    ['label' => Tools::lang()->trans('all'), 'where' => []]
                ]);
    }

    /**
     * Add the view to list payrolls
     */
    private function createViewPayRoll(): void
    {
        $this->addView('ListPayRoll', 'PayRoll', 'payrolls', 'fa-solid fa-file-invoice-dollar')
            // Search and Order By
            ->addSearchFields(['name', 'creationdate', 'startdate', 'enddate'])
            ->addOrderBy(['creationdate', 'idcompany'], 'date', 2)
            ->addOrderBy(['idcompany', 'creationdate'], 'company')
            ->addOrderBy(['name', 'idcompany'], 'name')
            ->addOrderBy(['id'], 'code')
            // Filters
            ->addFilterSelect('idcompany', 'company', 'idcompany', $this->companyList)
            ->addFilterPeriod('creationdate', 'date', 'creationdate');
    }

    /**
     * Discharge the selected employees.
     *
     * @return bool
     */
    private function execActionDischargeEmployee(): bool
    {
        $data = $this->request->request->all(); 
        if(empty($data['codes'])
         || empty($data['discharge_date'])
         || empty($data['discharge_description'])
         || false === $this->validateFormToken()
        ){
            return true;
        }

        $employee = new Employee();
        $ids = explode(',', $data['codes']);
        foreach ($ids as $idemployee) {
            if (false === $employee->load($idemployee)){
               continue;                
            }

            $employee->dischargeEmployee(
                $data['discharge_date'],
                $data['discharge_description']
            );
        }
        return true;
    }  
}
