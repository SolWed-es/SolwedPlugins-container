<?php
/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\HumanResources\Controller;

use FacturaScripts\Core\Lib\ExtendedController\ListController;

/**
 * Controller to list the items for the Training Course model.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class ListCourseTraining extends ListController
{
    private const VIEW_AREA = 'ListCourseArea';
    private const VIEW_COST = 'ListCourseCost';
    private const VIEW_COURSES = 'ListCourseTraining';
    private const VIEW_METHOD = 'ListCourseMethod';
    private const VIEW_OBJECTIVE = 'ListCourseObjective';

    /**
     * Returns basic page attributes
     *
     * @return array
     */
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['title'] = 'training-courses';
        $pageData['icon'] = 'fa-solid fa-graduation-cap';
        $pageData['menu'] = 'rrhh';
        return $pageData;
    }

    /**
     * Load views
     */
    protected function createViews()
    {
        $this->addView(self::VIEW_COURSES, 'CourseTraining', 'courses', 'fa-solid fa-book');
        $this->addView(self::VIEW_AREA, 'CourseArea', 'areas', 'fa-solid fa-circle-nodes');
        $this->addView(self::VIEW_COST, 'CourseCost', 'cost', 'fa-solid fa-hand-holding-dollar');
        $this->addView(self::VIEW_METHOD, 'CourseMethod', 'methods', 'fa-solid fa-person-dots-from-line');
        $this->addView(self::VIEW_OBJECTIVE, 'CourseObjective', 'objectives', 'fa-solid fa-arrow-down-up-across-line');
    }
}