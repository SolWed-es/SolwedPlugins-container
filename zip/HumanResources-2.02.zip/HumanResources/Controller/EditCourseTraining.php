<?php
/**
 * This file is part of HumanResources plugin for FacturaScripts.
 * FacturaScripts Copyright (C) 2015-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 * HumanResources Copyright (C) 2018-2025 Jose Antonio Cuello Principal <yopli2000@gmail.com>
 *
 * This program and its files are under the terms of the license specified in the LICENSE file.
 */
namespace FacturaScripts\Plugins\HumanResources\Controller;

use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Lib\ExtendedController\BaseView;
use FacturaScripts\Core\Lib\ExtendedController\EditController;

/**
 * Controller to edit Training Course.
 *
 * @author Jose Antonio Cuello Principal <yopli2000@gmail.com>
 */
class EditCourseTraining extends EditController
{
    private const VIEW_NOTES = 'EditCourseTrainingNote';
    private const VIEW_EMPLOYEES = 'EditEmployeeCourse';

    /**
     * Returns the model name
     */
    public function getModelClassName(): string
    {
        return 'CourseTraining';
    }

    /**
     * Returns basic page attributes
     *
     * @return array
     */
    public function getPageData(): array
    {
        $pageData = parent::getPageData();
        $pageData['title'] = 'course';
        $pageData['icon'] = 'fa-solid fa-book';
        $pageData['menu'] = 'rrhh';
        return $pageData;
    }

    /**
     * Create the view to display.
     */
    protected function createViews()
    {
        parent::createViews();
        $this->createViewsNotes();
        $this->createViewsEmployees();
        $this->setTabsPosition('left-bottom');
    }

    /**
     * Loads the data to display.
     *
     * @param string $viewName
     * @param BaseView $view
     */
    protected function loadData($viewName, $view)
    {
        switch ($viewName) {
            case self::VIEW_EMPLOYEES:
                $where = [ new DataBaseWhere('idcourse', $this->getModel()->id) ];
                $view->loadData('', $where);
                break;

            case self::VIEW_NOTES:
                $view->model = $this->getModel();
                break;

            default:
                parent::loadData($viewName, $view);
                break;
        }
    }

    /**
     * Create the view to manage employees assigned to the course.
     *
     * @return void
     */
    private function createViewsEmployees(): void
    {
        $this->addEditListView(self::VIEW_EMPLOYEES, 'EmployeeCourse', 'employees', 'fa-solid fa-id-card')
           ->setInLine(true)
            ->disableColumn('course');
    }

    /**
     * Create the view to manage notes about the course.
     *
     * @return void
     */
    private function createViewsNotes(): void
    {
        $this->addEditView(self::VIEW_NOTES, 'CourseTraining', 'notes', 'fa-solid fa-sticky-note')
            ->setSettings('btnDelete', false);
    }
}
