$(document).ready(function() {
    $('button.btn.btn-danger[onclick*="ListAttendance"][title="Eliminar"]').hide();
});