<?php
namespace FacturaScripts\Plugins\HumanResourcesSolwed\Model;

use FacturaScripts\Plugins\HumanResources\Model\Attendance as ParentAttendance;

class Attendance extends ParentAttendance
{        /**
    * joseferran localizacion
    * (latitude, longitude)
    *
    * @var string
    */
    public $localizacion;


}