﻿<?php
namespace FacturaScripts\Plugins\Vehiculos\Controller;

/**
 * Alias de compatibilidad hacia atrás para ListVehiculoAT
 */
class ListMaquinaAT extends ListVehiculoAT
{
    // Alias de compatibilidad
}