﻿<?php
namespace FacturaScripts\Plugins\Vehiculos\Controller;

/**
 * Alias de compatibilidad hacia atrás para EditVehiculoAT
 * Este controlador simplemente extiende de EditVehiculoAT
 */
class EditMaquinaAT extends EditVehiculoAT
{
    // Alias de compatibilidad - toda la lógica está en EditVehiculoAT
}