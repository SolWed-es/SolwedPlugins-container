﻿<?php
namespace FacturaScripts\Plugins\Vehiculos\Model;

/**
 * Alias de compatibilidad hacia atrás para VehiculoAT
 * Toda la lógica está en VehiculoAT
 */
class MaquinaAT extends VehiculoAT
{
    // Alias de compatibilidad
}