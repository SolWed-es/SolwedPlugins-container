# FechaVentas
Añade la columna fecha a las líneas de facturas, albaranes, pedidos y presupuestos de venta.
- https://facturascripts.com/plugins/fechaventas

## Licencia
ESTE PLUGIN NO ES SOFTWARE LIBRE. NO SE PERMITE SU DISTRIBUCIÓN SIN AUTORIZACIÓN.

## Nombre de carpeta
Como con todos los plugins, la carpeta se debe llamar igual que el plugin. En este caso **FechaVentas**.