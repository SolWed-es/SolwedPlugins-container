<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\FechaVentas\Mod;

use FacturaScripts\Core\Contract\SalesLineModInterface;
use FacturaScripts\Core\Model\Base\SalesDocument;
use FacturaScripts\Core\Model\Base\SalesDocumentLine;
use FacturaScripts\Core\Tools;

class SalesLineMod implements SalesLineModInterface
{
    public function apply(SalesDocument &$model, array &$lines, array $formData): void
    {
    }

    public function applyToLine(array $formData, SalesDocumentLine &$line, string $id): void
    {
        $line->fecha = $formData['fecha_' . $id] ?? null;
    }

    public function assets(): void
    {
    }

    public function getFastLine(SalesDocument $model, array $formData): ?SalesDocumentLine
    {
        return null;
    }

    public function map(array $lines, SalesDocument $model): array
    {
        return [];
    }

    public function newModalFields(): array
    {
        return [];
    }

    public function newFields(): array
    {
        return ['fecha'];
    }

    public function newTitles(): array
    {
        return ['fecha'];
    }

    public function renderField(string $idlinea, SalesDocumentLine $line, SalesDocument $model, string $field): ?string
    {
        if ($field === 'fecha') {
            return $this->fecha($idlinea, $line, $model);
        }

        return null;
    }

    public function renderTitle(SalesDocument $model, string $field): ?string
    {
        if ($field === 'fecha') {
            return $this->fechaTitle();
        }

        return null;
    }

    protected function fecha($idlinea, $line, $model): string
    {
        $attributes = $model->editable ?
            'name="fecha_' . $idlinea . '"' :
            'disabled=""';

        $fecha = is_null($line->fecha) ? date('Y-m-d') : date('Y-m-d', strtotime($line->fecha));
        return '<div class="col-sm col-lg-1 order-3">'
            . '<div class="d-lg-none mt-3 small">' . Tools::trans('date') . '</div>'
            . '<input type="date" ' . $attributes . ' value="' . $fecha . '" class="form-control form-control-sm border-0"/>'
            . '</div>';
    }

    protected function fechaTitle(): string
    {
        return '<div class="col-lg-1 order-3">' . Tools::trans('date') . '</div>';
    }
}
