<?php
/**
 * Copyright (C) 2024 Daniel Fernández Giménez <hola@danielfg.es>
 */

namespace FacturaScripts\Plugins\PortalCliente\Controller;

use FacturaScripts\Core\Lib\ExtendedController\BaseView;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Lib\ExportManager;
use FacturaScripts\Dinamic\Lib\PortalCatalogue;
use FacturaScripts\Dinamic\Lib\PortalDocShare;
use FacturaScripts\Dinamic\Lib\PortalViewController;
use FacturaScripts\Dinamic\Model\LineaFacturaCliente;
use FacturaScripts\Plugins\PortalCliente\Lib\PortalDocCommonTrait;
use FacturaScripts\Plugins\PortalCliente\Lib\PortalDocFilesTrait;
use FacturaScripts\Plugins\PortalCliente\Lib\PortalDocPaymentTrait;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class PortalFactura extends PortalViewController
{
    use PortalDocFilesTrait;
    use PortalDocPaymentTrait;
    use PortalDocCommonTrait;

    public function getImages(LineaFacturaCliente $line): string
    {
        $variant = $line->getVariante();
        $product = $line->getProducto();
        if (false === $variant->exists() || false === $product->exists()) {
            return '';
        }

        $images = $product->getImages();
        return PortalCatalogue::getGalleryImage($images, $variant->referencia);
    }

    public function getModelClassName(): string
    {
        return 'FacturaCliente';
    }

    public function getPageData(): array
    {
        $data = parent::getPageData();
        $data['menu'] = 'PortalCliente';
        $data['title'] = 'customer-invoice';
        $data['icon'] = 'fa-solid fa-file-invoice-dollar';
        return $data;
    }

    protected function createViews()
    {
        $model = $this->preloadModel();
        if (false === $model->exists()) {
            $this->error404();
            return;
        }

        $this->setContactPermissions($model);
        if (false === $this->permissions->allowAccess) {
            $this->error403();
            return;
        }

        parent::createViews();
        $this->addHtmlView('info', 'Tab/PortalInfoFactura', 'FacturaCliente', 'detail', 'fa-solid fa-info-circle');
        $this->createViewDocFiles();
        $this->createViewReceipt();
        $this->createViewsRefund();
    }

    protected function createViewReceipt(string $viewName = 'ListReciboCliente'): void
    {
        $this->addListView($viewName, 'ReciboCliente', 'receipts', 'fa-solid fa-dollar-sign')
            ->addOrderBy(['fecha'], 'date', 2)
            ->addOrderBy(['importe'], 'amount')
            ->addOrderBy(['vencimiento'], 'expiration')
            ->setSettings('btnNew', false)
            ->setSettings('btnDelete', false)
            ->setSettings('checkBoxes', false)
            ->setSettings('clickable', false)
            ->disableColumn('customer', true)
            ->disableColumn('invoice', true)
            ->disableColumn('expenses', true);
    }

    protected function createViewsRefund(string $viewName = 'ListPortalFactura'): void
    {
        $this->addListView($viewName, 'FacturaCliente', 'refunds', 'fa-solid fa-share-square')
            ->addOrderBy(['fecha', 'hora'], 'date', 2)
            ->addOrderBy(['total'], 'total')
            ->addSearchFields(['codigo', 'direccion', 'observaciones'])
            ->setSettings('btnNew', false)
            ->setSettings('btnDelete', false)
            ->setSettings('checkBoxes', false);
    }

    /**
     * @param string $action
     *
     * @return bool
     */
    protected function execPreviousAction($action)
    {
        return match ($action) {
            'pay' => $this->payAction(),
            'pay-paypal-link' => $this->payPaypalLinkAction(),
            'print' => $this->printAction(),
            default => parent::execPreviousAction($action),
        };

    }

    protected function getComposeUrlColumn(): string
    {
        return 'pc_uuid';
    }

    /**
     * @param string $viewName
     * @param BaseView $view
     */
    protected function loadData($viewName, $view)
    {
        switch ($viewName) {
            case 'docfiles':
                $view->cursor = $this->getModelDocFiles($this->views['main']->model);
                $view->count = count($view->cursor);
                $view->setSettings('active', $view->count > 0 && $this->contact->exists() && $this->contact->pc_allow_show_files);
                break;

            case 'ListPortalFactura':
                $where = [Where::column('idfacturarect', $this->views['main']->model->id())];
                $view->loadData('', $where);
                $view->setSettings('active', $view->count > 0);
                break;

            case 'ListReciboCliente':
                $where = [Where::column('idfactura', $this->views['main']->model->id())];
                $view->loadData('', $where);
                break;

            case self::MAIN_VIEW_NAME:
                parent::loadData($viewName, $view);
                $this->title = Tools::lang()->trans('invoice') . ' ' . $view->model->codigo;
                break;

            default:
                parent::loadData($viewName, $view);
                break;
        }
    }

    private function printAction(): bool
    {
        if (false === $this->permissions->allowAccess) {
            Tools::log()->warning('access-denied');
            return true;
        }

        $this->setTemplate(false);
        $exportManager = new ExportManager();
        $exportManager->newDoc($exportManager->defaultOption());
        $exportManager->addBusinessDocPage($this->preloadModel());
        $exportManager->show($this->response);
        return false;
    }

    private function setContactPermissions($model): void
    {
        // enlace de compartición
        $codeShare = $this->request->get('share');
        if ($codeShare && PortalDocShare::checkCode($model, $codeShare)) {
            $this->permissions->set(true, 1, false, false);
            return;
        }

        // anónimo
        if (false === $this->contact->exists()) {
            $this->permissions->set(false, 0, false, false);
            return;
        }

        // si no tiene permisos de ver
        if (false === $this->contact->pc_allow_show_invoice) {
            $this->permissions->set(false, 0, false, false);
            return;
        }

        // dirección de facturación o cliente
        if ($model->idcontactofact === $this->contact->idcontacto
            || $model->codcliente === $this->contact->codcliente) {
            $this->permissions->set(true, 1, false, false);
            return;
        }

        // no autorizado
        $this->permissions->set(false, 0, false, false);
    }

    private function tableColToNumber(string $name): string
    {
        return strtolower(FS_DB_TYPE) == 'postgresql' ?
            'CAST(' . $name . ' as integer)' :
            'CAST(' . $name . ' as unsigned)';
    }
}
