<?php
/**
 * Copyright (C) 2024 Daniel Fernández Giménez <hola@danielfg.es>
 */

namespace FacturaScripts\Plugins\PortalCliente\Model;

use FacturaScripts\Core\Template\ModelClass;
use FacturaScripts\Core\Template\ModelTrait;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\Contacto;
use FacturaScripts\Dinamic\Model\Variante;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class PortalCart extends ModelClass
{
    use ModelTrait;

    /** @var string */
    public $creation_date;

    /** @var int */
    public $id;

    /** @var int */
    public $idcontacto;

    /** @var int */
    public $idvariante;

    /** @var string */
    public $last_update;

    /** @var float */
    public $quantity;

    public function clear(): void
    {
        parent::clear();
        $this->quantity = 0.0;
    }

    public function getContact(): Contacto
    {
        $model = new Contacto();
        $model->load($this->idcontacto);
        return $model;
    }

    public function getVariant(): Variante
    {
        $model = new Variante();
        $model->load($this->idvariante);
        return $model;
    }

    public function install(): string
    {
        new Contacto();
        new Variante();
        return parent::install();
    }

    public static function primaryColumn(): string
    {
        return "id";
    }

    public static function tableName(): string
    {
        return "portal_carts";
    }

    public function test(): bool
    {
        $this->creation_date = $this->creation_date ?? Tools::dateTime();
        return parent::test();
    }

    public function url(string $type = 'auto', string $list = 'List'): string
    {
        if (false === empty($this->id)) {
            return 'EditContacto?activetab=ListPortalCartLine&code=' . $this->id;
        }

        if ($type === 'list') {
            return 'ListPortalCliente?activetab=ListPortalCart';
        }

        if ($type === 'edit') {
            return 'EditContacto?activetab=ListPortalCartLine&code=' . $this->idcontacto;
        }

        return parent::url($type, $list);
    }

    protected function saveUpdate(): bool
    {
        $this->last_update = Tools::dateTime();
        return parent::saveUpdate();
    }
}