<?php
/**
 * Copyright (C) 2024 Daniel Fernández Giménez <hola@danielfg.es>
 */

namespace FacturaScripts\Plugins\PortalCliente\Mod;

use FacturaScripts\Core\Contract\SalesModInterface;
use FacturaScripts\Core\Model\Base\SalesDocument;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Lib\Pay\PaypalApi;
use FacturaScripts\Dinamic\Lib\Pay\RedsysApi;
use FacturaScripts\Dinamic\Lib\Pay\StripeApi;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class SalesHeaderHTMLMod implements SalesModInterface
{

    public function apply(SalesDocument &$model, array $formData): void
    {
        $model->pc_paid = $formData['pc_paid'] ?? $model->pc_paid;
    }

    public function applyBefore(SalesDocument &$model, array $formData): void
    {
    }

    public function assets(): void
    {
    }

    public function newBtnFields(): array
    {
        return [];
    }

    public function newFields(): array
    {
        return [];
    }

    public function newModalFields(): array
    {
        return ['uuid', 'paymentOnline', 'paymentStripe', 'paymentPaypal', 'paymentRedsys'];
    }

    public function renderField(SalesDocument $model, string $field): ?string
    {
        return match ($field) {
            'uuid' => $this->uuid($model),
            'paymentOnline' => $this->paymentOnline($model),
            'paymentStripe' => $this->paymentStripe($model),
            'paymentPaypal' => $this->paymentPaypal($model),
            'paymentRedsys' => $this->paymentRedsys($model),
            default => null,
        };

    }

    private function paymentOnline(SalesDocument $model): string
    {
        $attributes = $model->editable ? '' : 'disabled';
        return '<div class="col-sm-6">'
            . '<div class="mb-3">'
            . Tools::lang()->trans('paid-online')
            . '<select name="pc_paid" class="form-select" ' . $attributes . '>'
            . '<option value="0" ' . ($model->pc_paid ? '' : 'selected') . '>'
            . Tools::lang()->trans('no')
            . '</option>'
            . '<option value="1" ' . ($model->pc_paid ? 'selected' : '') . '>'
            . Tools::lang()->trans('yes')
            . '</option>'
            . '</select>'
            . '</div>'
            . '</div>';
    }

    private function paymentPaypal(SalesDocument $model): string
    {
        if (empty($model->pc_payment_paypal)) {
            return '';
        }

        $link = $model->exists() && false === empty($model->pc_payment_paypal)
            ? '<a href="' . PaypalApi::urlDashboard($model->pc_payment_paypal) . '" target="_blank">'
            . Tools::lang()->trans('payment-paypal') . '</a>'
            : Tools::lang()->trans('payment-paypal');

        return '<div class="col-sm-6">'
            . '<div class="mb-3">'
            . $link
            . '<input type="text" value="' . $model->pc_payment_paypal . '" class="form-control" disabled>'
            . '</div>'
            . '</div>';
    }

    private function paymentRedsys(SalesDocument $model): string
    {
        if (empty($model->pc_payment_redsys)) {
            return '';
        }

        $link = $model->exists() && false === empty($model->pc_payment_redsys)
            ? '<a href="' . RedsysApi::urlDashboard($model->pc_payment_redsys) . '" target="_blank">'
            . Tools::lang()->trans('payment-redsys') . '</a>'
            : Tools::lang()->trans('payment-redsys');

        return '<div class="col-sm-6">'
            . '<div class="mb-3">'
            . $link
            . '<input type="text" value="' . $model->pc_payment_redsys . '" class="form-control" disabled>'
            . '</div>'
            . '</div>';
    }

    private function paymentStripe(SalesDocument $model): string
    {
        if (empty($model->pc_payment_intent_stripe)) {
            return '';
        }

        $link = $model->exists() && false === empty($model->pc_payment_intent_stripe)
            ? '<a href="' . StripeApi::urlDashboard($model->getCompany(), 'payments/' . $model->pc_payment_intent_stripe) . '" target="_blank">'
            . Tools::lang()->trans('payment-stripe') . '</a>'
            : Tools::lang()->trans('payment-stripe');

        return '<div class="col-sm-6">'
            . '<div class="mb-3">'
            . $link
            . '<input type="text" value="' . $model->pc_payment_intent_stripe . '" class="form-control" disabled>'
            . '</div>'
            . '</div>';
    }

    private function uuid(SalesDocument $model): string
    {
        if (empty($model->pc_uuid)) {
            return '';
        }

        return '<div class="col-sm-6">'
            . '<div class="mb-3">'
            . Tools::lang()->trans('uuid')
            . '<input type="text" value="' . $model->pc_uuid . '" class="form-control" disabled>'
            . '</div>'
            . '</div>';
    }
}