<?php
/**
 * Copyright (C) 2024 Daniel Fernández Giménez <hola@danielfg.es>
 */

namespace FacturaScripts\Plugins\PortalCliente\Extension\Controller;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class ListPedidoCliente
{
    use CommonListDocTrait;
}