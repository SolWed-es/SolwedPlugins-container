<?php
/**
 * Copyright (C) 2025 Daniel Fernández Giménez <hola@danielfg.es>
 */

namespace FacturaScripts\Plugins\PortalCliente\Extension\Model;

use Closure;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Model\PortalNote;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class Cliente
{
    public function delete(): Closure
    {
        return function () {
            $where = [Where::column('codcliente', $this->id())];
            foreach (PortalNote::all($where) as $ticket) {
                $ticket->delete();
            }
        };
    }
}