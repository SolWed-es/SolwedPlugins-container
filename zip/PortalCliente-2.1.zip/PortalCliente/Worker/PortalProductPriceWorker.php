<?php
/**
 * Copyright (C) 2024 Daniel Fernández Giménez <hola@danielfg.es>
 */

namespace FacturaScripts\Plugins\PortalCliente\Worker;

use FacturaScripts\Core\Model\WorkEvent;
use FacturaScripts\Core\Template\WorkerClass;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Model\Producto;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class PortalProductPriceWorker extends WorkerClass
{
    public function run(WorkEvent $event): bool
    {
        // obtenemos los productos sin precio mínimo y máximo
        $where = [
            Where::column('pc_price_min', null),
            Where::column('pc_price_max', null, 'IS', 'OR'),
        ];
        foreach (Producto::all($where) as $product) {
            $product->save();
        }

        return $this->done();
    }
}