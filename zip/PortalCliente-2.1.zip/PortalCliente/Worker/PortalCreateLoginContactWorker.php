<?php
/**
 * Copyright (C) 2024 Daniel Fernández Giménez <hola@danielfg.es>
 */

namespace FacturaScripts\Plugins\PortalCliente\Worker;

use FacturaScripts\Core\Model\WorkEvent;
use FacturaScripts\Core\Template\WorkerClass;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Model\Contacto;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class PortalCreateLoginContactWorker extends WorkerClass
{
    public function run(WorkEvent $event): bool
    {
        $where = [
            Where::column('pc_nick', null),
            Where::column('pc_nick', '', '=', 'OR')
        ];
        foreach (Contacto::all($where) as $contact) {
            $contact->save();
        }

        return $this->done();
    }
}