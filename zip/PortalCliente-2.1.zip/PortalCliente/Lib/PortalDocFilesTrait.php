<?php
/**
 * Copyright (C) 2024 Daniel Fernández Giménez <hola@danielfg.es>
 */

namespace FacturaScripts\Plugins\PortalCliente\Lib;

use FacturaScripts\Core\Model\Base\SalesDocument;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Model\AttachedFileRelation;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
trait PortalDocFilesTrait
{
    public function getContactDocFiles(): array
    {
        $contactFiles = [];

        // obtenemos los archivos del contacto, si existe
        if ($this->contact->exists()) {
            $whereContact = [Where::column('pc_show', true)];
            $whereContact[] = Where::column('model', 'Contacto');
            $whereContact[] = Where::column('modelid|modelcode', $this->contact->idcontacto);
            $contactFiles = AttachedFileRelation::all($whereContact, ['creationdate' => 'DESC']);
        }

        // si no hay cliente, devolvemos los archivos del contacto
        if (empty($this->contact->codcliente)) {
            return $contactFiles;
        }

        // obtenemos los archivos del cliente
        $whereClient = [Where::column('pc_show', true)];
        $whereClient[] = Where::column('model', 'Cliente');
        $whereClient[] = Where::column('modelid|modelcode', $this->contact->codcliente);
        $clientFiles = AttachedFileRelation::all($whereClient, ['creationdate' => 'DESC']);

        // unimos los dos arrays
        $result = array_merge($contactFiles, $clientFiles);

        // ordenamos el array por fecha de creación en php 8
        usort($result, fn($a, $b) => $a->creationdate <=> $b->creationdate);

        return $result;
    }

    public function getModelDocFiles(SalesDocument $docModel): array
    {
        // obtenemos los archivos del documento
        $where = [Where::column('model', $docModel->modelClassName()),];
        $where[] = is_numeric($docModel->id()) ?
            Where::column('modelid|modelcode', $docModel->id()) :
            Where::column('modelcode', $docModel->id());

        if ($docModel->pc_paid) {
            $where[] = Where::column('pc_show|pc_show_paid', true);
        } else {
            $where[] = Where::column('pc_show', true);
        }

        $files = AttachedFileRelation::all($where, ['creationdate' => 'DESC']);

        // recorremos las líneas del documento
        foreach ($docModel->getLines() as $line) {
            // si la línea no tiene referencia, pasamos a la siguiente
            if (empty($line->referencia)) {
                continue;
            }

            // obtenemos los archivos del producto
            $where = [
                Where::column('model', 'Producto'),
                Where::column('modelid|modelcode', $line->idproducto),
            ];
            if ($docModel->pc_paid) {
                $where[] = Where::column('pc_show|pc_show_paid', true);
            } else {
                $where[] = Where::column('pc_show', true);
            }
            $lineFiles = AttachedFileRelation::all($where, ['creationdate' => 'DESC']);
            $files = array_merge($files, $lineFiles);
        }

        return $files;
    }

    protected function createViewDocFiles(string $viewName = 'docfiles', string $template = 'Tab/PortalDocFiles'): void
    {
        $this->addHtmlView($viewName, $template, 'AttachedFileRelation', 'files', 'fa-solid fa-paperclip');
    }
}