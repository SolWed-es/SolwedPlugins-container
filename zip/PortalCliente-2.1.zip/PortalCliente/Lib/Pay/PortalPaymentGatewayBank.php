<?php
/**
 * Copyright (C) 2024 Daniel Fernández Giménez <hola@danielfg.es>
 */

namespace FacturaScripts\Plugins\PortalCliente\Lib\Pay;

use FacturaScripts\Core\Request;
use FacturaScripts\Core\Tools;
use FacturaScripts\Core\Model\Base\SalesDocument;
use FacturaScripts\Core\Where;
use FacturaScripts\Dinamic\Model\Contacto;
use FacturaScripts\Dinamic\Model\CuentaBanco;
use FacturaScripts\Plugins\PortalCliente\Contract\PortalPaymentGatewayInterface;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class PortalPaymentGatewayBank implements PortalPaymentGatewayInterface
{
    public function getHtml(SalesDocument $model, Contacto $contact): string
    {
        // obtenemos todas las cuentas de banco que se pueden mostrar en el portal
        // para la misma empresa del documento
        $where = [
            Where::column('pc_show', true),
            Where::column('idempresa', $model->idempresa),
        ];
        $bankAccounts = CuentaBanco::all($where, ['descripcion' => 'ASC']);

        // si no hay cuentas de banco, terminamos
        if (empty($bankAccounts)) {
            return '';
        }

        $html = '<div class="d-grid gap-2">'
            . '<button type="button" class="btn btn-primary mb-3 btn-spin-action" data-bs-toggle="modal" data-bs-target="#transferPayModal">'
            . '<i class="fa-solid fa-building-columns me-2"></i>'
            . Tools::lang()->trans('pay-by-bank-transfer')
            . '</button>'
            . '</div>'
            . '<div class="modal fade" id="transferPayModal" tabindex="-1" role="dialog" aria-labelledby="transferPayModalLabel" aria-hidden="true">'
            . '<div class="modal-dialog" role="document">'
            . '<div class="modal-content">'
            . '<div class="modal-header">'
            . '<h5 class="modal-title" id="transferPayModalLabel">' . Tools::lang()->trans('pay-by-bank-transfer') . '</h5>'
            . '<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar">'
            . '</button>'
            . '</div>'
            . '<div class="modal-body">'
            . '<p>' . Tools::lang()->trans('modal-bank-transfer-info') . '</p>';

        foreach ($bankAccounts as $bankAccount) {
            $html .= '<div class="mb-3 border bg-light p-2">'
                . '<div><strong>' . Tools::lang()->trans('titular') . ':</strong> ' . $model->getCompany()->nombre . '</div>'
                . '<div><strong>' . Tools::lang()->trans('iban') . ':</strong> ' . $bankAccount->iban . '</div>'
                . '<div><strong>' . Tools::lang()->trans('swift') . ':</strong> ' . $bankAccount->swift . '</div>'
                . '<div><strong>' . Tools::lang()->trans('concept') . ':</strong> ' . $model->codigo . '</div>'
                . '</div>';
        }

        $html .= '<p class="m-0">' . Tools::lang()->trans('modal-bank-transfer-desc', ['%email%' => $model->getCompany()->email]) . '</p>'
            . '</div>'
            . '<div class="modal-footer">'
            . '<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">' . Tools::lang()->trans('close') . '</button>'
            . '</div>'
            . '</div>'
            . '</div>'
            . '</div>';

        return $html;
    }

    public function isEnabled(): bool
    {
        return true;
    }

    public function name(): string
    {
        return 'transfer-bank';
    }

    public function payAction(SalesDocument &$model, Request $request): bool
    {
        return true;
    }
}
