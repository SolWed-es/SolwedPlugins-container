# PortalCliente
Añade un panel de gestión para clientes, para ver presupuestos, pedidos, facturas, pagar, comprar y más.
- https://facturascripts.com/plugins/portalcliente

## No es software libre
Este plugin no es software libre, no se permite su uso libre y/o distribución. Consultar el archivo **LICENSE** para más
detalles.

### Nombre de carpeta
Como con todos los plugins, la carpeta se debe llamar igual que el plugin. En este caso **PortalCliente**.