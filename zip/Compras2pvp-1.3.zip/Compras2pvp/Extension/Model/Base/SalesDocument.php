<?php
/**
 * Copyright (C) 2020-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\Compras2pvp\Extension\Model\Base;

use Closure;

/**
 * Description of SalesDocument
 *
 * @author Carlos Garcia Gomez <carlos@facturascripts.com>
 */
class SalesDocument
{
    public function getNewProductLine(): Closure
    {
        return function ($newLine, $variant, $product) {
            if ($variant->coste < 1 || $newLine->dtopor > 0) {
                return;
            }

            $newLine->dtopor = 100 * ($newLine->pvpunitario - $variant->coste) / $newLine->pvpunitario;
        };
    }
}
