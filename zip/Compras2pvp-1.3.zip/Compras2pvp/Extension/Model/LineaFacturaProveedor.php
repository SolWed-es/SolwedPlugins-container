<?php
/**
 * Copyright (C) 2020-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\Compras2pvp\Extension\Model;

use Closure;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Dinamic\Model\Variante;

class LineaFacturaProveedor
{
    public function save(): Closure
    {
        return function () {
            if (empty($this->referencia) || $this->cantidad < 1 || $this->pvpunitario < 1 || $this->dtopor < 1) {
                return;
            }

            // get the variant
            $variant = new Variante();
            $where = [new DataBaseWhere('referencia', $this->referencia)];
            if (false === $variant->loadWhere($where)) {
                return;
            }

            $variant->precio = $this->pvpunitario;
            $variant->coste = empty($this->cantidad) ? 0.0 : $this->pvptotal / $this->cantidad;
            $variant->save();
        };
    }
}