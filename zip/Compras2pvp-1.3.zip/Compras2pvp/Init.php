<?php
/**
 * Copyright (C) 2020-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\Compras2pvp;

use FacturaScripts\Core\Template\InitClass;

/**
 * Description of Init
 *
 * @author Carlos Garcia Gomez <carlos@facturascripts.com>
 */
class Init extends InitClass
{
    public function init(): void
    {
        $this->loadExtension(new Extension\Model\LineaAlbaranProveedor());
        $this->loadExtension(new Extension\Model\LineaFacturaProveedor());
        $this->loadExtension(new Extension\Model\Base\SalesDocument());
    }

    public function uninstall(): void
    {
    }

    public function update(): void
    {
    }
}
