# Compras2pvp
Guarda como precio de venta los precios de compra en albaranes o facturas. Además, establece un descuento máximo automático en las ventas de esos productos.

- https://facturascripts.com/plugins/compras2pvp

## Licencia
ESTE PLUGIN NO ES SOFTWARE LIBRE. NO SE PERMITE SU DISTRIBUCIÓN SIN AUTORIZACIÓN.

## Nombre de carpeta
Como con todos los plugins, la carpeta se debe llamar igual que el plugin. En este caso **Compras2pvp**.
