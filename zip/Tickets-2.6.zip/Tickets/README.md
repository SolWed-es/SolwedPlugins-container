# Tickets
Permite imprimir tickets de facturas, albaranes, pedidos y presupuestos.
- https://facturascripts.com/plugins/tickets

## Nombre de carpeta
Como con todos los plugins, la carpeta se debe llamar igual que el plugin. En este caso **Tickets**.