<?php
/**
 * Copyright (C) 2023-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\Etiquetas\CronJob;

use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Template\CronJobClass;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\Variante;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
final class AutoGenBarcode extends CronJobClass
{
    const JOB_NAME = 'auto-gen-barcode';
    const JOB_PERIOD = '1 days';

    public static function run(): void
    {
        echo "\n* JOB: " . self::JOB_NAME . ' ... ';

        // comprobamos si está activado el autogenerado de códigos de barras
        if (false === (bool)Tools::settings('default', 'autogenbarcodes', false)) {
            return;
        }

        // obtenemos las variantes sin código de barras
        $where = [new DataBaseWhere('codbarras', null),];
        foreach (Variante::all($where, [], 0, 1000) as $variant) {
            $variant->codbarras = $variant->generateEAN();
            $variant->tipocodbarras = 'EAN13';

            if (false === $variant->save()) {
                self::echo("\n- Error al generar el código de barras de la variante: " . $variant->referencia);
                continue;
            }

            self::echo("\n- Generado código de barras de la variante: " . $variant->referencia);
        }

        self::saveEcho();
    }
}
