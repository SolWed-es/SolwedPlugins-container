<?php
/**
 * Copyright (C) 2023-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\Etiquetas;

use FacturaScripts\Core\Template\CronClass;
use FacturaScripts\Plugins\Etiquetas\CronJob\AutoGenBarcode;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
final class Cron extends CronClass
{
    public function run(): void
    {
        $this->job(AutoGenBarcode::JOB_NAME)
            ->every(AutoGenBarcode::JOB_PERIOD)
            ->run(function () {
                AutoGenBarcode::run();
            });
    }
}
