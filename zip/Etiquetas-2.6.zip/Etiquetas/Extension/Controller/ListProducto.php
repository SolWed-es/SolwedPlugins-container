<?php
/**
 * Copyright (C) 2022-2025 Carlos Garcia Gomez <carlos@facturascripts.com>
 */

namespace FacturaScripts\Plugins\Etiquetas\Extension\Controller;

use Closure;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
use FacturaScripts\Core\Tools;
use FacturaScripts\Dinamic\Model\Variante;

/**
 * @author Daniel Fernández Giménez <hola@danielfg.es>
 */
class ListProducto
{
    public function createViews(): Closure
    {
        return function () {
            $this->addButton('ListProducto', [
                'action' => 'barcode',
                'color' => 'light',
                'confirm' => true,
                'icon' => 'fa-solid fa-barcode',
                'label' => 'generate-barcodes',
            ]);
        };
    }

    public function execPreviousAction(): Closure
    {
        return function ($action) {
            if ($action !== 'barcode') {
                return;
            }

            $codes = $this->request->getArray('codes');
            if (empty($codes)) {
                Tools::log()->warning('no-selected-item');
                return;
            }

            $num = 0;
            foreach ($codes as $id) {
                $modelVariant = new Variante();
                $where = [new DataBaseWhere('idproducto', $id)];
                foreach ($modelVariant->all($where, [], 0, 0) as $variant) {
                    if ($variant->codbarras) {
                        continue;
                    }

                    $variant->codbarras = $variant->generateEAN();
                    $variant->tipocodbarras = 'EAN13';

                    $where = [new DataBaseWhere('codbarras', $variant->codbarras)];
                    if ($modelVariant->count($where) > 0) {
                        // ya existe el código de barras, descartamos
                        continue;
                    }

                    if ($variant->save()) {
                        $num++;
                    }
                }
            }

            Tools::log()->notice('barcode-generate-ok', ['%num%' => $num]);
        };
    }
}
