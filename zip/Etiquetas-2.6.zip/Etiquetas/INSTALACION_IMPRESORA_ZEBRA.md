# Instalación y Configuración de Impresoras Zebra

Este documento describe cómo solucionar el error de permisos al usar impresoras Zebra USB con QZ Tray en Linux.

## Problema

Al intentar imprimir aparece el siguiente error:
```
Error al imprimir: javax.usb.UsbPlatformException: USB error 3: Can't open device
Bus 001 Device 005: ID 0a5f:0080: Access denied (insufficient permissions)
```

## Solución

### Opción 1: Usar reglas udev (Recomendado)

Las reglas udev otorgan permisos permanentes al dispositivo USB.

#### Paso 1: Instalar el archivo de reglas

```bash
# Copiar el archivo de reglas al directorio del sistema
sudo cp 99-zebra-printers.rules /etc/udev/rules.d/

# Verificar que se copió correctamente
ls -l /etc/udev/rules.d/99-zebra-printers.rules
```

#### Paso 2: Recargar las reglas

```bash
# Recargar las reglas udev
sudo udevadm control --reload-rules

# Aplicar las reglas a los dispositivos conectados
sudo udevadm trigger
```

#### Paso 3: Reconectar la impresora

Desconecta y vuelve a conectar la impresora USB, o reinicia el sistema.

#### Paso 4: Verificar permisos

```bash
# Listar dispositivos USB Zebra
lsusb | grep "0a5f"

# Verificar permisos del dispositivo (ejemplo para Bus 001 Device 005)
ls -l /dev/bus/usb/001/005
```

Deberías ver algo como:
```
crw-rw-rw- 1 root plugdev ... /dev/bus/usb/001/005
```

### Opción 2: Ejecutar QZ Tray como root (No recomendado)

Solo para pruebas temporales:

```bash
# Detener QZ Tray si está corriendo
# Ejecutar QZ Tray con sudo
sudo java -jar qz-tray.jar
```

**Nota**: Esta opción no es recomendable para uso en producción por razones de seguridad.

### Opción 3: Añadir usuario al grupo plugdev

```bash
# Añadir tu usuario al grupo plugdev
sudo usermod -a -G plugdev $USER

# Cerrar sesión y volver a iniciar sesión para que los cambios surtan efecto
```

Después de hacer esto, sigue los pasos de la Opción 1.

## Modelos de Impresoras Soportados

El archivo de reglas incluye los siguientes modelos Zebra:

- **GK420d** (0x0080)
- **GK420t** (0x0081)
- **GX420d** (0x0084)
- **ZD420** (0x0050)
- **ZD500** (0x0051, 0x0110)
- **ZP450** (0x008C)
- **GC420d** (0x00D1)
- **ZD410** (0x011C)
- **ZD620** (0x0141)
- **ZT411** (0x0172)

## Verificación de la Instalación

### 1. Verificar que QZ Tray puede ver el dispositivo

Abre la aplicación web y usa el botón "Escanear dispositivos USB". Deberías ver tu impresora Zebra listada.

### 2. Imprimir etiqueta de prueba

Usa el botón "Imprimir etiqueta de prueba" en el modal de configuración.

## Solución de Problemas

### El dispositivo no aparece después de aplicar las reglas

```bash
# Ver los logs de udev
sudo udevadm monitor --environment --udev

# Desconectar y reconectar la impresora mientras el monitor está activo
```

### Verificar el Product ID de tu impresora

```bash
# Listar todos los dispositivos USB con detalles
lsusb -v | grep -A 10 "Zebra"

# O más simple
lsusb | grep "0a5f"
```

Si tu impresora tiene un Product ID diferente, añade una línea adicional al archivo `99-zebra-printers.rules`:

```bash
SUBSYSTEM=="usb", ATTR{idVendor}=="0a5f", ATTR{idProduct}=="XXXX", MODE="0666", GROUP="plugdev"
```

Reemplaza `XXXX` con el Product ID de tu impresora (en minúsculas).

### QZ Tray no se conecta

1. Verifica que QZ Tray está corriendo:
   ```bash
   ps aux | grep qz-tray
   ```

2. Reinicia QZ Tray desde el menú del sistema.

3. Verifica que el navegador permite la conexión WebSocket a localhost.

## Seguridad

El archivo de reglas udev configura los dispositivos con modo `0666`, lo que permite acceso de lectura/escritura a todos los usuarios. Si necesitas mayor seguridad, puedes:

1. Cambiar `MODE="0666"` a `MODE="0660"` en el archivo de reglas.
2. Asegurarte de que solo usuarios de confianza están en el grupo `plugdev`.

## Referencias

- [Documentación de QZ Tray](https://qz.io/wiki/)
- [Guía de reglas udev](https://wiki.debian.org/udev)
- [Impresoras Zebra](https://www.zebra.com/)
